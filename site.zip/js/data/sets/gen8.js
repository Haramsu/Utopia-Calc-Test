var SETDEX_SS = {
  "Rattata": {
    "Youngster Chucky [Slot 1]": {
      "level": 5,
      "ability": "Guts",
      "moves": [
        "Tackle",
        "Focus Energy"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 1,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RATTATA:0",
      "originalSpeciesKey": "RATTATA:0",
      "trainerId": "YOUNGSTER:Chucky:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Zigzagoon": {
    "Youngster Chucky [Slot 2]": {
      "level": 6,
      "ability": "Quick Feet",
      "moves": [
        "Tackle",
        "Baby-Doll Eyes"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 1,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ZIGZAGOON:0",
      "originalSpeciesKey": "ZIGZAGOON:0",
      "trainerId": "YOUNGSTER:Chucky:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Poochyena": {
    "Lass Zoe [Slot 1]": {
      "level": 7,
      "ability": "Rattled",
      "moves": [
        "Bite",
        "Sand Attack"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 2,
      "gender": "M",
      "shiny": false,
      "speciesKey": "POOCHYENA:0",
      "originalSpeciesKey": "POOCHYENA:0",
      "trainerId": "LASS:Zoe:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic M Grunt #1 [Slot 1]": {
      "level": 17,
      "ability": "Rattled",
      "moves": [
        "Assurance",
        "Psychic Fangs",
        "Swagger [SWAGGER]"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 37,
      "gender": "F",
      "shiny": false,
      "speciesKey": "POOCHYENA:0",
      "originalSpeciesKey": "POOCHYENA:0",
      "trainerId": "GALACTIC_M:Grunt:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Houndour": {
    "Lass Zoe [Slot 2]": {
      "level": 8,
      "ability": "Early Bird",
      "moves": [
        "Bite",
        "Ember"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 2,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HOUNDOUR:0",
      "originalSpeciesKey": "HOUNDOUR:0",
      "trainerId": "LASS:Zoe:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Weedle": {
    "Bugcatcher Rick [Slot 1]": {
      "level": 8,
      "ability": "Shield Dust",
      "moves": [
        "Poison Sting",
        "Bug Bite"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 3,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WEEDLE:0",
      "originalSpeciesKey": "WEEDLE:0",
      "trainerId": "BUGCATCHER:Rick:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Caterpie": {
    "Bugcatcher Rick [Slot 2]": {
      "level": 9,
      "ability": "Shield Dust",
      "moves": [
        "Electroweb",
        "Bug Bite"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 3,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CATERPIE:0",
      "originalSpeciesKey": "CATERPIE:0",
      "trainerId": "BUGCATCHER:Rick:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Kricketot": {
    "Bugcatcher Doug [Slot 1]": {
      "level": 9,
      "ability": "Shed Skin",
      "moves": [
        "Bug Bite",
        "Growl"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 4,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KRICKETOT:0",
      "originalSpeciesKey": "KRICKETOT:0",
      "trainerId": "BUGCATCHER:Doug:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Grubbin": {
    "Bugcatcher Doug [Slot 2]": {
      "level": 10,
      "ability": "Swarm",
      "moves": [
        "Struggle Bug",
        "Bite",
        "Mud-Slap"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 4,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRUBBIN:0",
      "originalSpeciesKey": "GRUBBIN:0",
      "trainerId": "BUGCATCHER:Doug:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Pineco": {
    "Bugcatcher Kai [Slot 1]": {
      "level": 10,
      "ability": "Sturdy",
      "moves": [
        "Struggle Bug",
        "Rapid Spin",
        "Toxic"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 5,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PINECO:0",
      "originalSpeciesKey": "PINECO:0",
      "trainerId": "BUGCATCHER:Kai:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Scatterbug": {
    "Bugcatcher Kai [Slot 2]": {
      "level": 10,
      "ability": "Shield Dust",
      "moves": [
        "Bug Bite",
        "Stun Spore"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 5,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SCATTERBUG:0",
      "originalSpeciesKey": "SCATTERBUG:16",
      "trainerId": "BUGCATCHER:Kai:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Ledyba": {
    "Bugcatcher Kai [Slot 3]": {
      "level": 11,
      "ability": "Rattled",
      "moves": [
        "Mach Punch",
        "Gust",
        "Supersonic"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 5,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LEDYBA:0",
      "originalSpeciesKey": "LEDYBA:0",
      "trainerId": "BUGCATCHER:Kai:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Venonat": {
    "Bugcatcher Anthony [Slot 1]": {
      "level": 11,
      "ability": "Compound Eyes",
      "moves": [
        "Struggle Bug",
        "Acid Spray",
        "Confusion"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 6,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENONAT:0",
      "originalSpeciesKey": "VENONAT:0",
      "trainerId": "BUGCATCHER:Anthony:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Sewaddle": {
    "Bugcatcher Anthony [Slot 2]": {
      "level": 12,
      "ability": "Swarm",
      "moves": [
        "Bug Bite",
        "Razor Leaf"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 15,
        "at": 15,
        "df": 15,
        "sa": 15,
        "sd": 15,
        "sp": 15
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 6,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SEWADDLE:0",
      "originalSpeciesKey": "SEWADDLE:0",
      "trainerId": "BUGCATCHER:Anthony:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Bounsweet": {
    "Rival Gary #1 [Slot 1]": {
      "level": 12,
      "ability": "Sweet Veil",
      "moves": [
        "Trailblaze",
        "Zen Headbutt",
        "Charm"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 22,
        "at": 22,
        "df": 22,
        "sa": 22,
        "sd": 22,
        "sp": 22
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 7,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BOUNSWEET:0",
      "originalSpeciesKey": "BOUNSWEET:0",
      "trainerId": "RIVAL:Gary:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Pikipek": {
    "Rival Gary #1 [Slot 2]": {
      "level": 13,
      "ability": "Keen Eye",
      "moves": [
        "Aerial Ace",
        "Rock Smash"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 20,
        "at": 20,
        "df": 20,
        "sa": 20,
        "sd": 20,
        "sp": 20
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 7,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PIKIPEK:0",
      "originalSpeciesKey": "PIKIPEK:0",
      "trainerId": "RIVAL:Gary:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Eevee": {
    "Rival Gary #1 [Slot 3]": {
      "level": 14,
      "ability": "Anticipation",
      "moves": [
        "Quick Attack",
        "Mud-Slap",
        "Swift"
      ],
      "nature": "Modest",
      "item": "Oran Berry",
      "ivs": {
        "hp": 22,
        "at": 22,
        "df": 22,
        "sa": 22,
        "sd": 22,
        "sp": 22
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 7,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EEVEE:0",
      "originalSpeciesKey": "EEVEE:0",
      "trainerId": "RIVAL:Gary:0",
      "slot": 3,
      "doubles": false
    },
    "Rival Gary #2 [Slot 4]": {
      "level": 26,
      "ability": "Adaptability",
      "moves": [
        "Quick Attack",
        "Swift",
        "Alluring Voice",
        "Charm"
      ],
      "nature": "Modest",
      "item": "Berry Juice",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 8,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EEVEE:0",
      "originalSpeciesKey": "EEVEE:0",
      "trainerId": "RIVAL:Gary:1",
      "slot": 4,
      "doubles": false
    }
  },
  "Trumbeak": {
    "Rival Gary #2 [Slot 1]": {
      "level": 25,
      "ability": "Keen Eye",
      "moves": [
        "Dual Wingbeat",
        "Rock Blast",
        "Bullet Seed",
        "U-turn"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 8,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TRUMBEAK:0",
      "originalSpeciesKey": "TRUMBEAK:0",
      "trainerId": "RIVAL:Gary:1",
      "slot": 1,
      "doubles": false
    }
  },
  "Steenee": {
    "Rival Gary #2 [Slot 2]": {
      "level": 25,
      "ability": "Sweet Veil",
      "moves": [
        "Giga Drain",
        "Dazzling Gleam",
        "Zen Headbutt",
        "Triple Axel"
      ],
      "nature": "Naive",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 8,
      "gender": "F",
      "shiny": false,
      "speciesKey": "STEENEE:0",
      "originalSpeciesKey": "STEENEE:0",
      "trainerId": "RIVAL:Gary:1",
      "slot": 2,
      "doubles": false
    }
  },
  "Houndoom": {
    "Rival Gary #2 [Slot 3]": {
      "level": 25,
      "ability": "Flash Fire",
      "moves": [
        "Snarl",
        "Incinerate",
        "Psychic Fangs"
      ],
      "nature": "Bold",
      "item": "Oran Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 8,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HOUNDOOM:0",
      "originalSpeciesKey": "HOUNDOOM:0",
      "trainerId": "RIVAL:Gary:1",
      "slot": 3,
      "doubles": false
    },
    "Pokemontrainer Gary [Slot 3]": {
      "level": 50,
      "ability": "Early Bird",
      "moves": [
        "Crunch",
        "Flamethrower",
        "Sludge Bomb",
        "Reversal"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 11,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HOUNDOOM:0",
      "originalSpeciesKey": "HOUNDOOM:0",
      "trainerId": "POKEMONTRAINER:Gary:0",
      "slot": 3,
      "doubles": false
    },
    "Channeler Paula [Slot 1]": {
      "level": 40,
      "ability": "Early Bird",
      "moves": [
        "Sucker Punch",
        "Flamethrower",
        "Reversal",
        "Roar"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 148,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HOUNDOOM:0",
      "originalSpeciesKey": "HOUNDOOM:0",
      "trainerId": "CHANNELER:Paula:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Nidoqueen": {
    "Rival Gary #3 [Slot 1]": {
      "level": 53,
      "ability": "Sheer Force",
      "moves": [
        "Toxic Spikes",
        "Sludge Wave",
        "Earth Power",
        "Thunderbolt"
      ],
      "nature": "Bold",
      "item": "Black Sludge",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 9,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NIDOQUEEN:0",
      "originalSpeciesKey": "NIDOQUEEN:0",
      "trainerId": "RIVAL:Gary:2",
      "slot": 1,
      "doubles": false
    },
    "Rival Gary #4 [Slot 1]": {
      "level": 89,
      "ability": "Sheer Force",
      "moves": [
        "Toxic Spikes",
        "Sludge Wave",
        "Earth Power"
      ],
      "nature": "Bold",
      "item": "Black Sludge",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 10,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NIDOQUEEN:0",
      "originalSpeciesKey": "NIDOQUEEN:0",
      "trainerId": "RIVAL:Gary:3",
      "slot": 1,
      "doubles": false
    },
    "Hiker Bart [Slot 3]": {
      "level": 65,
      "ability": "Sheer Force",
      "moves": [
        "Sludge Bomb",
        "Earth Power",
        "Flamethrower"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 235,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NIDOQUEEN:0",
      "originalSpeciesKey": "NIDOQUEEN:0",
      "trainerId": "HIKER:Bart:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Tsareena": {
    "Rival Gary #3 [Slot 2]": {
      "level": 53,
      "ability": "Queenly Majesty",
      "moves": [
        "Trop Kick",
        "High Jump Kick",
        "Triple Axel",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Coba Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 9,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TSAREENA:0",
      "originalSpeciesKey": "TSAREENA:0",
      "trainerId": "RIVAL:Gary:2",
      "slot": 2,
      "doubles": false
    },
    "Rival Gary #4 [Slot 2]": {
      "level": 89,
      "ability": "Queenly Majesty",
      "moves": [
        "Trop Kick",
        "High Jump Kick",
        "Triple Axel",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Coba Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 10,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TSAREENA:0",
      "originalSpeciesKey": "TSAREENA:0",
      "trainerId": "RIVAL:Gary:3",
      "slot": 2,
      "doubles": false
    },
    "Pokemontrainer Gary [Slot 2]": {
      "level": 49,
      "ability": "Leaf Guard",
      "moves": [
        "Trop Kick",
        "High Jump Kick",
        "Triple Axel",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 11,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TSAREENA:0",
      "originalSpeciesKey": "TSAREENA:0",
      "trainerId": "POKEMONTRAINER:Gary:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic F Grunt #6 [Slot 3]": {
      "level": 75,
      "ability": "Queenly Majesty",
      "moves": [
        "Power Whip",
        "High Jump Kick",
        "Triple Axel",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Wide Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 282,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TSAREENA:0",
      "originalSpeciesKey": "TSAREENA:0",
      "trainerId": "GALACTIC_F:Grunt:21",
      "slot": 3,
      "doubles": false
    }
  },
  "Toucannon": {
    "Rival Gary #3 [Slot 3]": {
      "level": 53,
      "ability": "Skill Link",
      "moves": [
        "Brave Bird",
        "Overheat",
        "Rock Blast",
        "Bullet Seed"
      ],
      "nature": "Naive",
      "item": "Fire Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 9,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOUCANNON:0",
      "originalSpeciesKey": "TOUCANNON:0",
      "trainerId": "RIVAL:Gary:2",
      "slot": 3,
      "doubles": false
    },
    "Rival Gary #4 [Slot 5]": {
      "level": 89,
      "ability": "Skill Link",
      "moves": [
        "Brave Bird",
        "Overheat",
        "Rock Blast",
        "Bullet Seed"
      ],
      "nature": "Naive",
      "item": "Fire Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 10,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOUCANNON:0",
      "originalSpeciesKey": "TOUCANNON:0",
      "trainerId": "RIVAL:Gary:3",
      "slot": 5,
      "doubles": false
    },
    "Pokemonranger M Enzio [Slot 4]": {
      "level": 68,
      "ability": "Skill Link",
      "moves": [
        "Brave Bird",
        "Overheat",
        "Rock Blast",
        "Bullet Seed"
      ],
      "nature": "Naive",
      "item": "Fire Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 251,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOUCANNON:0",
      "originalSpeciesKey": "TOUCANNON:0",
      "trainerId": "POKEMONRANGER_M:Enzio:0",
      "slot": 4,
      "doubles": false
    },
    "Pokémon Ranger Dylan (DOUBLES) [Slot 1]": {
      "level": 47,
      "ability": "Skill Link",
      "moves": [
        "Boomburst",
        "Drill Peck",
        "Bullet Seed"
      ],
      "nature": "Hasty",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 177,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOUCANNON:0",
      "originalSpeciesKey": "TOUCANNON:0",
      "trainerId": "POKEMONRANGER_M:Dylan:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Sylveon": {
    "Rival Gary #3 [Slot 4]": {
      "level": 53,
      "ability": "Pixilate",
      "moves": [
        "Hyper Voice",
        "Shadow Ball",
        "Mystical Fire",
        "Calm Mind"
      ],
      "nature": "Modest",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 9,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SYLVEON:0",
      "originalSpeciesKey": "SYLVEON:0",
      "trainerId": "RIVAL:Gary:2",
      "slot": 4,
      "doubles": false
    },
    "Rival Gary #4 [Slot 4]": {
      "level": 89,
      "ability": "Pixilate",
      "moves": [
        "Hyper Voice",
        "Shadow Ball",
        "Mystical Fire",
        "Calm Mind"
      ],
      "nature": "Modest",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 10,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SYLVEON:0",
      "originalSpeciesKey": "SYLVEON:0",
      "trainerId": "RIVAL:Gary:3",
      "slot": 4,
      "doubles": false
    },
    "Lass Tina [Slot 1]": {
      "level": 33,
      "ability": "Cute Charm",
      "moves": [
        "Quick Attack",
        "Alluring Voice",
        "Magical Leaf",
        "Calm Mind"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 120,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SYLVEON:0",
      "originalSpeciesKey": "SYLVEON:0",
      "trainerId": "LASS:Tina:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Tibor (DOUBLES) [Slot 3]": {
      "level": 79,
      "ability": "Pixilate",
      "moves": [
        "Quick Attack",
        "Hyper Voice",
        "Protect"
      ],
      "nature": "Timid",
      "item": "Fairy Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 290,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SYLVEON:0",
      "originalSpeciesKey": "SYLVEON:0",
      "trainerId": "COOLTRAINER_M:Tibor:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Baxcalibur": {
    "Rival Gary #3 [Slot 5]": {
      "level": 53,
      "ability": "Thermal Exchange",
      "moves": [
        "Dragon Claw",
        "Icicle Crash",
        "Earthquake",
        "Dragon Dance"
      ],
      "nature": "Jolly",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 9,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BAXCALIBUR:0",
      "originalSpeciesKey": "BAXCALIBUR:0",
      "trainerId": "RIVAL:Gary:2",
      "slot": 5,
      "doubles": false
    },
    "Pokemontrainer Gary [Slot 1]": {
      "level": 48,
      "ability": "Inner Focus",
      "moves": [
        "Dragon Claw",
        "Icicle Crash",
        "High Horsepower",
        "Crunch"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 11,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BAXCALIBUR:0",
      "originalSpeciesKey": "BAXCALIBUR:0",
      "trainerId": "POKEMONTRAINER:Gary:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer F Lumina [Slot 3]": {
      "level": 67,
      "ability": "Inner Focus",
      "moves": [
        "Dragon Tail",
        "Icicle Crash",
        "Aqua Tail",
        "Crunch"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 259,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BAXCALIBUR:0",
      "originalSpeciesKey": "BAXCALIBUR:0",
      "trainerId": "COOLTRAINER_F:Lumina:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Houndoom [Mega Houndoom]": {
    "Rival Gary #3 [Slot 6]": {
      "level": 54,
      "ability": "Solar Power",
      "moves": [
        "Dark Pulse",
        "Flamethrower",
        "Scorching Sands",
        "Destiny Bond"
      ],
      "nature": "Timid",
      "item": "Houndoominite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 9,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HOUNDOOM:1",
      "originalSpeciesKey": "HOUNDOOM:0",
      "trainerId": "RIVAL:Gary:2",
      "slot": 6,
      "doubles": false
    }
  },
  "Roaring Moon": {
    "Rival Gary #4 [Slot 3]": {
      "level": 89,
      "ability": "Protosynthesis",
      "moves": [
        "Dragon Rush",
        "Throat Chop",
        "Roost"
      ],
      "nature": "Jolly",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 10,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROARINGMOON:0",
      "originalSpeciesKey": "ROARINGMOON:0",
      "trainerId": "RIVAL:Gary:3",
      "slot": 3,
      "doubles": false
    },
    "Galacticboss Cyrus #3 [Slot 2]": {
      "level": 77,
      "ability": "Protosynthesis",
      "moves": [
        "Scale Shot",
        "Night Slash",
        "Rock Slide"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 231,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROARINGMOON:0",
      "originalSpeciesKey": "ROARINGMOON:0",
      "trainerId": "GALACTICBOSS:Cyrus:2",
      "slot": 2,
      "doubles": false
    }
  },
  "Venusaur [Mega Venusaur]": {
    "Rival Gary #4 [Slot 6]": {
      "level": 90,
      "ability": "Thick Fat",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Earth Power",
        "Synthesis"
      ],
      "nature": "Bold",
      "item": "Venusaurite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 10,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENUSAUR:1",
      "originalSpeciesKey": "VENUSAUR:0",
      "trainerId": "RIVAL:Gary:3",
      "slot": 6,
      "doubles": false
    }
  },
  "Sandshrew": {
    "Ruinmaniac Dirk [Slot 1]": {
      "level": 12,
      "ability": "Sand Veil",
      "moves": [
        "Fury Swipes",
        "Mud-Slap",
        "Poison Sting"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 18,
        "at": 18,
        "df": 18,
        "sa": 18,
        "sd": 18,
        "sp": 18
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 12,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SANDSHREW:0",
      "originalSpeciesKey": "SANDSHREW:0",
      "trainerId": "RUINMANIAC:Dirk:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Onix": {
    "Ruinmaniac Dirk [Slot 2]": {
      "level": 13,
      "ability": "Sturdy",
      "moves": [
        "Rock Throw",
        "Sand Tomb",
        "Curse"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 18,
        "at": 18,
        "df": 18,
        "sa": 18,
        "sd": 18,
        "sp": 18
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 12,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ONIX:0",
      "originalSpeciesKey": "ONIX:0",
      "trainerId": "RUINMANIAC:Dirk:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Wooper": {
    "Ruinmaniac Dieter [Slot 1]": {
      "level": 12,
      "ability": "Water Absorb",
      "moves": [
        "Water Pulse",
        "Mud Shot",
        "Yawn"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 18,
        "at": 18,
        "df": 18,
        "sa": 18,
        "sd": 18,
        "sp": 18
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 13,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WOOPER:0",
      "originalSpeciesKey": "WOOPER:0",
      "trainerId": "RUINMANIAC:Dieter:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Dwebble": {
    "Ruinmaniac Dieter [Slot 2]": {
      "level": 13,
      "ability": "Shell Armor",
      "moves": [
        "Bug Bite",
        "Smack Down",
        "Flail"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 18,
        "at": 18,
        "df": 18,
        "sa": 18,
        "sd": 18,
        "sp": 18
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 13,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DWEBBLE:0",
      "originalSpeciesKey": "DWEBBLE:0",
      "trainerId": "RUINMANIAC:Dieter:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Mankey": {
    "Blackbelt Chucky [Slot 1]": {
      "level": 13,
      "ability": "Anger Point",
      "moves": [
        "Low Kick",
        "Assurance",
        "Scary Face"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 20,
        "at": 20,
        "df": 20,
        "sa": 20,
        "sd": 20,
        "sp": 20
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 14,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MANKEY:0",
      "originalSpeciesKey": "MANKEY:0",
      "trainerId": "BLACKBELT:Chucky:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Riolu": {
    "Blackbelt Chucky [Slot 2]": {
      "level": 14,
      "ability": "Inner Focus",
      "moves": [
        "Quick Attack",
        "Rock Smash",
        "Metal Claw"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 20,
        "at": 20,
        "df": 20,
        "sa": 20,
        "sd": 20,
        "sp": 20
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 14,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RIOLU:0",
      "originalSpeciesKey": "RIOLU:0",
      "trainerId": "BLACKBELT:Chucky:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Bonsly": {
    "Hiker Gerome [Slot 1]": {
      "level": 12,
      "ability": "Sturdy",
      "moves": [
        "Rock Throw",
        "Trailblaze",
        "Mimic"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 20,
        "at": 20,
        "df": 20,
        "sa": 20,
        "sd": 20,
        "sp": 20
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 15,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BONSLY:0",
      "originalSpeciesKey": "BONSLY:0",
      "trainerId": "HIKER:Gerome:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Roggenrola": {
    "Hiker Gerome [Slot 2]": {
      "level": 13,
      "ability": "Weak Armor",
      "moves": [
        "Smack Down",
        "Mud-Slap",
        "Sand Attack"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 20,
        "at": 20,
        "df": 20,
        "sa": 20,
        "sd": 20,
        "sp": 20
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 15,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ROGGENROLA:0",
      "originalSpeciesKey": "ROGGENROLA:0",
      "trainerId": "HIKER:Gerome:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Rockruff": {
    "Hiker Gerome [Slot 3]": {
      "level": 14,
      "ability": "Steadfast",
      "moves": [
        "Rock Throw",
        "Bite"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 20,
        "at": 20,
        "df": 20,
        "sa": 20,
        "sd": 20,
        "sp": 20
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 15,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ROCKRUFF:0",
      "originalSpeciesKey": "ROCKRUFF:0",
      "trainerId": "HIKER:Gerome:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Pancham": {
    "Blackbelt Tai [Slot 1]": {
      "level": 13,
      "ability": "Mold Breaker",
      "moves": [
        "Arm Thrust",
        "Payback",
        "Work Up"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 20,
        "at": 20,
        "df": 20,
        "sa": 20,
        "sd": 20,
        "sp": 20
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 16,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PANCHAM:0",
      "originalSpeciesKey": "PANCHAM:0",
      "trainerId": "BLACKBELT:Tai:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Clobbopus": {
    "Blackbelt Tai [Slot 2]": {
      "level": 14,
      "ability": "Limber",
      "moves": [
        "Brick Break",
        "Brine",
        "Work Up"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 20,
        "at": 20,
        "df": 20,
        "sa": 20,
        "sd": 20,
        "sp": 20
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 16,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLOBBOPUS:0",
      "originalSpeciesKey": "CLOBBOPUS:0",
      "trainerId": "BLACKBELT:Tai:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Geodude": {
    "Gym Leader Roark [Slot 1]": {
      "level": 15,
      "ability": "Sturdy",
      "moves": [
        "Stealth Rock",
        "Rock Tomb",
        "Bulldoze"
      ],
      "nature": "Careful",
      "item": "Lum Berry",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 17,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GEODUDE:0",
      "originalSpeciesKey": "GEODUDE:0",
      "trainerId": "LEADER_Roark:Roark:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Timburr": {
    "Gym Leader Roark [Slot 2]": {
      "level": 15,
      "ability": "Guts",
      "moves": [
        "Brick Break",
        "Rock Tomb",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "Oran Berry",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 17,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TIMBURR:0",
      "originalSpeciesKey": "TIMBURR:0",
      "trainerId": "LEADER_Roark:Roark:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Lileep": {
    "Gym Leader Roark [Slot 3]": {
      "level": 15,
      "ability": "Storm Drain",
      "moves": [
        "Mega Drain",
        "Ancient Power",
        "Acid",
        "Ingrain"
      ],
      "nature": "Serious",
      "item": "Quick Claw",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 17,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LILEEP:0",
      "originalSpeciesKey": "LILEEP:0",
      "trainerId": "LEADER_Roark:Roark:0",
      "slot": 3,
      "doubles": false
    },
    "Hiker Hugo [Slot 1]": {
      "level": 22,
      "ability": "Storm Drain",
      "moves": [
        "Ancient Power",
        "Giga Drain",
        "Brine",
        "Stockpile"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 65,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LILEEP:0",
      "originalSpeciesKey": "LILEEP:0",
      "trainerId": "HIKER:Hugo:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Farfetch'd [Galarian]": {
    "Gym Leader Roark [Slot 4]": {
      "level": 16,
      "ability": "Scrappy",
      "moves": [
        "Quick Attack",
        "Rock Smash",
        "Aerial Ace"
      ],
      "nature": "Impish",
      "item": "Oran Berry",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 17,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FARFETCHD:1",
      "originalSpeciesKey": "FARFETCHD:1",
      "trainerId": "LEADER_Roark:Roark:0",
      "slot": 4,
      "doubles": false
    },
    "Blackbelt Kojiro [Slot 1]": {
      "level": 35,
      "ability": "Scrappy",
      "moves": [
        "Rock Smash",
        "Dual Wingbeat",
        "Knock Off",
        "Work Up"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 118,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FARFETCHD:1",
      "originalSpeciesKey": "FARFETCHD:1",
      "trainerId": "BLACKBELT:Kojiro:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Yamper": {
    "Camper Bernie & Ernie [Slot 1]": {
      "level": 15,
      "ability": "Rattled",
      "moves": [
        "Spark",
        "Bite",
        "Attract"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 18,
      "gender": "F",
      "shiny": false,
      "speciesKey": "YAMPER:0",
      "originalSpeciesKey": "YAMPER:0",
      "trainerId": "UTOPIA_DUO:0:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Drowzee": {
    "Camper Bernie & Ernie [Slot 2]": {
      "level": 16,
      "ability": "Insomnia",
      "moves": [
        "Psybeam",
        "Draining Kiss",
        "Hypnosis"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 18,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DROWZEE:0",
      "originalSpeciesKey": "DROWZEE:0",
      "trainerId": "UTOPIA_DUO:0:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Grotle": {
    "Camper Bernie & Ernie [Slot 3]": {
      "level": 15,
      "ability": "Overgrow",
      "moves": [
        "Mega Drain",
        "Body Slam",
        "Leech Seed"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 18,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GROTLE:0",
      "originalSpeciesKey": "GROTLE:0",
      "trainerId": "UTOPIA_DUO:0:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Magnemite": {
    "Supernerd Tilo [Slot 1]": {
      "level": 22,
      "ability": "Sturdy",
      "moves": [
        "Magnet Bomb",
        "Shock Wave",
        "Supersonic"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 59,
      "gender": "",
      "shiny": false,
      "speciesKey": "MAGNEMITE:0",
      "originalSpeciesKey": "MAGNEMITE:0",
      "trainerId": "SUPERNERD:Tilo:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Tom (DOUBLES) [Slot 3]": {
      "level": 23,
      "ability": "Sturdy",
      "moves": [
        "Electro Ball",
        "Mirror Shot",
        "Confuse Ray",
        "Thunder Wave"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 53,
      "gender": "",
      "shiny": false,
      "speciesKey": "MAGNEMITE:0",
      "originalSpeciesKey": "MAGNEMITE:0",
      "trainerId": "HIKER:Tom:0",
      "slot": 3,
      "doubles": true
    },
    "Camper Bernie & Ernie [Slot 4]": {
      "level": 16,
      "ability": "Sturdy",
      "moves": [
        "Electro Ball",
        "Mirror Shot",
        "Confuse Ray"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 18,
      "gender": "",
      "shiny": false,
      "speciesKey": "MAGNEMITE:0",
      "originalSpeciesKey": "MAGNEMITE:0",
      "trainerId": "UTOPIA_DUO:0:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Diglett [Alolan]": {
    "Hiker Mark [Slot 1]": {
      "level": 15,
      "ability": "Tangling Hair",
      "moves": [
        "Sucker Punch",
        "Bulldoze",
        "Metal Claw"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 20,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DIGLETT:1",
      "originalSpeciesKey": "DIGLETT:1",
      "trainerId": "HIKER:Mark:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Staravia": {
    "Hiker Mark [Slot 2]": {
      "level": 16,
      "ability": "Intimidate",
      "moves": [
        "Aerial Ace",
        "Thief",
        "U-turn"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 20,
      "gender": "M",
      "shiny": false,
      "speciesKey": "STARAVIA:0",
      "originalSpeciesKey": "STARAVIA:0",
      "trainerId": "HIKER:Mark:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Lillipup": {
    "Youngster Toby [Slot 1]": {
      "level": 15,
      "ability": "Vital Spirit",
      "moves": [
        "Headbutt",
        "Thunder Fang",
        "Bite"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 21,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LILLIPUP:0",
      "originalSpeciesKey": "LILLIPUP:0",
      "trainerId": "YOUNGSTER:Toby:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Monferno": {
    "Youngster Toby [Slot 2]": {
      "level": 16,
      "ability": "Blaze",
      "moves": [
        "Mach Punch",
        "Flame Wheel",
        "Rock Tomb"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 21,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MONFERNO:0",
      "originalSpeciesKey": "MONFERNO:0",
      "trainerId": "YOUNGSTER:Toby:0",
      "slot": 2,
      "doubles": false
    },
    "Blackbelt Daisuke [Slot 2]": {
      "level": 34,
      "ability": "Blaze",
      "moves": [
        "Mach Punch",
        "Blaze Kick",
        "Drain Punch",
        "Encore"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 117,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MONFERNO:0",
      "originalSpeciesKey": "MONFERNO:0",
      "trainerId": "BLACKBELT:Daisuke:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Crabrawler": {
    "Crushgirl Ava [Slot 1]": {
      "level": 16,
      "ability": "Hyper Cutter",
      "moves": [
        "Brick Break",
        "Vise Grip",
        "Chilling Water",
        "Amnesia"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 22,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CRABRAWLER:0",
      "originalSpeciesKey": "CRABRAWLER:0",
      "trainerId": "CRUSHGIRL:Ava:0",
      "slot": 1,
      "doubles": false
    },
    "Biker Zeke [Slot 3]": {
      "level": 25,
      "ability": "Hyper Cutter",
      "moves": [
        "Rock Smash",
        "Reversal",
        "Liquidation",
        "Iron Defense"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 78,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CRABRAWLER:0",
      "originalSpeciesKey": "CRABRAWLER:0",
      "trainerId": "BIKER:Zeke:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Machop": {
    "Crushgirl Ava [Slot 2]": {
      "level": 17,
      "ability": "Guts",
      "moves": [
        "Low Kick",
        "Dual Chop",
        "Rock Tomb",
        "Knock Off"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 22,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MACHOP:0",
      "originalSpeciesKey": "MACHOP:0",
      "trainerId": "CRUSHGIRL:Ava:0",
      "slot": 2,
      "doubles": false
    },
    "Sailor Ernest [Slot 3]": {
      "level": 24,
      "ability": "Guts",
      "moves": [
        "Brick Break",
        "Thunder Punch",
        "Dual Chop",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 74,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MACHOP:0",
      "originalSpeciesKey": "MACHOP:0",
      "trainerId": "SAILOR:Ernest:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Bibarel": {
    "Gentleman Norbert [Slot 1]": {
      "level": 16,
      "ability": "Simple",
      "moves": [
        "Headbutt",
        "Water Pulse",
        "Bulldoze"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 23,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BIBAREL:0",
      "originalSpeciesKey": "BIBAREL:0",
      "trainerId": "GENTLEMAN:Norbert:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Slowpoke [Galarian]": {
    "Gentleman Norbert [Slot 2]": {
      "level": 16,
      "ability": "Own Tempo",
      "moves": [
        "Zen Headbutt",
        "Water Pulse",
        "Thunder Wave"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 23,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLOWPOKE:1",
      "originalSpeciesKey": "SLOWPOKE:1",
      "trainerId": "GENTLEMAN:Norbert:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Fletchinder": {
    "Gentleman Norbert [Slot 3]": {
      "level": 17,
      "ability": "Flame Body",
      "moves": [
        "Aerial Ace",
        "Flame Charge",
        "Quick Attack",
        "U-turn"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 23,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FLETCHINDER:0",
      "originalSpeciesKey": "FLETCHINDER:0",
      "trainerId": "GENTLEMAN:Norbert:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Clefairy": {
    "Lass Haley [Slot 1]": {
      "level": 16,
      "ability": "Cute Charm",
      "moves": [
        "Draining Kiss",
        "Water Pulse",
        "Magical Leaf",
        "Fake Tears"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 24,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFAIRY:0",
      "originalSpeciesKey": "CLEFAIRY:0",
      "trainerId": "LASS:Haley:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Blitzle": {
    "Lass Haley [Slot 2]": {
      "level": 17,
      "ability": "Sap Sipper",
      "moves": [
        "Spark",
        "Flame Charge",
        "Trailblaze"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 24,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BLITZLE:0",
      "originalSpeciesKey": "BLITZLE:0",
      "trainerId": "LASS:Haley:0",
      "slot": 2,
      "doubles": false
    },
    "Lass Saskia [Slot 2]": {
      "level": 22,
      "ability": "Heatproof",
      "moves": [
        "Low Kick",
        "Bite",
        "Spark",
        "Double Kick"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 52,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BLITZLE:0",
      "originalSpeciesKey": "BLITZLE:0",
      "trainerId": "LASS:Saskia:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Beautifly": {
    "Birdkeeper Harry [Slot 1]": {
      "level": 16,
      "ability": "Swarm",
      "moves": [
        "Bug Bite",
        "Air Cutter",
        "Mega Drain"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 25,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BEAUTIFLY:0",
      "originalSpeciesKey": "BEAUTIFLY:0",
      "trainerId": "BIRDKEEPER:Harry:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Swablu": {
    "Birdkeeper Harry [Slot 2]": {
      "level": 17,
      "ability": "Natural Cure",
      "moves": [
        "Dragon Breath",
        "Air Cutter",
        "Cotton Guard"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 25,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SWABLU:0",
      "originalSpeciesKey": "SWABLU:0",
      "trainerId": "BIRDKEEPER:Harry:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Haunter": {
    "Youngster Lucio [Slot 1]": {
      "level": 18,
      "ability": "Levitate",
      "moves": [
        "Night Shade",
        "Acid Spray",
        "Giga Drain",
        "Hypnosis"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 26,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HAUNTER:0",
      "originalSpeciesKey": "HAUNTER:0",
      "trainerId": "YOUNGSTER:Lucio:0",
      "slot": 1,
      "doubles": false
    },
    "Biker Rex [Slot 2]": {
      "level": 33,
      "ability": "Levitate",
      "moves": [
        "Disable",
        "Nightmare",
        "Dream Eater",
        "Toxic"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 111,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HAUNTER:0",
      "originalSpeciesKey": "HAUNTER:0",
      "trainerId": "BIKER:Rex:0",
      "slot": 2,
      "doubles": false
    },
    "Channeler Naomi [Slot 1]": {
      "level": 40,
      "ability": "Levitate",
      "moves": [
        "Hex",
        "Venoshock",
        "Toxic",
        "Will-O-Wisp"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 147,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HAUNTER:0",
      "originalSpeciesKey": "HAUNTER:0",
      "trainerId": "CHANNELER:Naomi:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Kirlia": {
    "Youngster Luca [Slot 1]": {
      "level": 16,
      "ability": "Trace",
      "moves": [
        "Psybeam",
        "Draining Kiss",
        "Magical Leaf"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 27,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KIRLIA:0",
      "originalSpeciesKey": "KIRLIA:0",
      "trainerId": "YOUNGSTER:Luca:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Minccino": {
    "Youngster Luca [Slot 2]": {
      "level": 17,
      "ability": "Cute Charm",
      "moves": [
        "Tail Slap",
        "Bullet Seed",
        "Sing"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 27,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MINCCINO:0",
      "originalSpeciesKey": "MINCCINO:0",
      "trainerId": "YOUNGSTER:Luca:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Kricketune": {
    "Camper Siegbert [Slot 1]": {
      "level": 16,
      "ability": "Technician",
      "moves": [
        "Pounce",
        "Aerial Ace",
        "Brick Break"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 28,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KRICKETUNE:0",
      "originalSpeciesKey": "KRICKETUNE:0",
      "trainerId": "CAMPER:Siegbert:0",
      "slot": 1,
      "doubles": false
    },
    "Lass Maggie [Slot 1]": {
      "level": 31,
      "ability": "Swarm",
      "moves": [
        "Giga Drain",
        "Hyper Voice",
        "X-Scissor",
        "Uproar"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 91,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KRICKETUNE:0",
      "originalSpeciesKey": "KRICKETUNE:0",
      "trainerId": "LASS:Maggie:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Grimer [Alolan]": {
    "Camper Siegbert [Slot 2]": {
      "level": 17,
      "ability": "Poison Touch",
      "moves": [
        "Sludge",
        "Mud Shot",
        "Acid Armor"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 28,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GRIMER:1",
      "originalSpeciesKey": "GRIMER:1",
      "trainerId": "CAMPER:Siegbert:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Snover": {
    "Cooltrainer F Lisa [Slot 1]": {
      "level": 18,
      "ability": "Snow Warning",
      "moves": [
        "Ice Shard",
        "Giga Drain",
        "Avalanche"
      ],
      "nature": "Bashful",
      "item": "Occa Berry",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 29,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SNOVER:0",
      "originalSpeciesKey": "SNOVER:0",
      "trainerId": "COOLTRAINER_F:Lisa:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Misdreavus": {
    "Cooltrainer F Lisa [Slot 2]": {
      "level": 18,
      "ability": "Levitate",
      "moves": [
        "Hex",
        "Charge Beam",
        "Icy Wind",
        "Will-O-Wisp"
      ],
      "nature": "Bold",
      "item": "Oran Berry",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 29,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MISDREAVUS:0",
      "originalSpeciesKey": "MISDREAVUS:0",
      "trainerId": "COOLTRAINER_F:Lisa:0",
      "slot": 2,
      "doubles": false
    },
    "Lass Isabelle [Slot 1]": {
      "level": 22,
      "ability": "Levitate",
      "moves": [
        "Hex",
        "Charge Beam",
        "Draining Kiss",
        "Will-O-Wisp"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 58,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MISDREAVUS:0",
      "originalSpeciesKey": "MISDREAVUS:0",
      "trainerId": "LASS:Isabelle:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Brionne": {
    "Cooltrainer F Lisa [Slot 3]": {
      "level": 19,
      "ability": "Torrent",
      "moves": [
        "Aqua Jet",
        "Bubble Beam",
        "Draining Kiss"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 29,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BRIONNE:0",
      "originalSpeciesKey": "BRIONNE:0",
      "trainerId": "COOLTRAINER_F:Lisa:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Krabby": {
    "Fisherman Scott [Slot 1]": {
      "level": 16,
      "ability": "Shell Armor",
      "moves": [
        "Razor Shell",
        "Brick Break",
        "Dig"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 30,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KRABBY:0",
      "originalSpeciesKey": "KRABBY:0",
      "trainerId": "FISHERMAN:Scott:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Staryu": {
    "Fisherman Scott [Slot 2]": {
      "level": 17,
      "ability": "Natural Cure",
      "moves": [
        "Water Pulse",
        "Psybeam",
        "Icy Wind",
        "Light Screen"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 30,
      "gender": "",
      "shiny": false,
      "speciesKey": "STARYU:0",
      "originalSpeciesKey": "STARYU:0",
      "trainerId": "FISHERMAN:Scott:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Marill": {
    "Fisherman Scott [Slot 3]": {
      "level": 18,
      "ability": "Sap Sipper",
      "moves": [
        "Chilling Water",
        "Play Rough",
        "Bulldoze"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 30,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MARILL:0",
      "originalSpeciesKey": "MARILL:0",
      "trainerId": "FISHERMAN:Scott:0",
      "slot": 3,
      "doubles": false
    },
    "Lass Aurelia [Slot 2]": {
      "level": 23,
      "ability": "Sap Sipper",
      "moves": [
        "Aqua Jet",
        "Liquidation",
        "Play Rough",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 72,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MARILL:0",
      "originalSpeciesKey": "MARILL:0",
      "trainerId": "LASS:Aurelia:0",
      "slot": 2,
      "doubles": false
    },
    "Supernerd Jake [Slot 1]": {
      "level": 30,
      "ability": "Huge Power",
      "moves": [
        "Aqua Jet",
        "Waterfall",
        "Play Rough"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 102,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MARILL:0",
      "originalSpeciesKey": "MARILL:0",
      "trainerId": "SUPERNERD:Jake:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Magikarp": {
    "Fisherman Raymond [Slot 1]": {
      "level": 17,
      "ability": "Rattled",
      "moves": [
        "Bounce",
        "Flail"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 31,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MAGIKARP:0",
      "originalSpeciesKey": "MAGIKARP:0",
      "trainerId": "FISHERMAN:Raymond:0",
      "slot": 1,
      "doubles": false
    },
    "Fisherman Raymond [Slot 2]": {
      "level": 18,
      "ability": "Rattled",
      "moves": [
        "Hydro Pump",
        "Flail"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 31,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MAGIKARP:0",
      "originalSpeciesKey": "MAGIKARP:0",
      "trainerId": "FISHERMAN:Raymond:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Ducklett": {
    "Fisherman Steven [Slot 1]": {
      "level": 17,
      "ability": "Keen Eye",
      "moves": [
        "Bubble Beam",
        "Air Slash",
        "Feather Dance"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 32,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DUCKLETT:0",
      "originalSpeciesKey": "DUCKLETT:0",
      "trainerId": "FISHERMAN:Steven:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Lombre": {
    "Fisherman Steven [Slot 2]": {
      "level": 18,
      "ability": "Own Tempo",
      "moves": [
        "Fake Out",
        "Water Pulse",
        "Mega Drain",
        "Knock Off"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 32,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LOMBRE:0",
      "originalSpeciesKey": "LOMBRE:0",
      "trainerId": "FISHERMAN:Steven:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Finneon": {
    "Fisherman Tully [Slot 1]": {
      "level": 16,
      "ability": "Swift Swim",
      "moves": [
        "Water Pulse",
        "Psybeam",
        "Swift",
        "Charm"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 33,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FINNEON:0",
      "originalSpeciesKey": "FINNEON:0",
      "trainerId": "FISHERMAN:Tully:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Buizel": {
    "Fisherman Tully [Slot 2]": {
      "level": 17,
      "ability": "Swift Swim",
      "moves": [
        "Aqua Jet",
        "Liquidation",
        "Low Kick",
        "Bulk Up"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 33,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BUIZEL:0",
      "originalSpeciesKey": "BUIZEL:0",
      "trainerId": "FISHERMAN:Tully:0",
      "slot": 2,
      "doubles": false
    },
    "Swimmer F Jenny [Slot 1]": {
      "level": 18,
      "ability": "Swift Swim",
      "moves": [
        "Water Pulse",
        "Aqua Jet",
        "Thief"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BUIZEL:0",
      "originalSpeciesKey": "BUIZEL:0",
      "trainerId": "SWIMMER_F:Jenny:0",
      "slot": 1,
      "doubles": false
    },
    "Swimmer Jenny & Aromalady Caroline [Slot 1]": {
      "level": 18,
      "ability": "Swift Swim",
      "moves": [
        "Water Pulse",
        "Aqua Jet",
        "Thief"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BUIZEL:0",
      "originalSpeciesKey": "BUIZEL:0",
      "trainerId": "UTOPIA_DUO:2:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Poliwhirl": {
    "Fisherman Tully [Slot 3]": {
      "level": 18,
      "ability": "Water Absorb",
      "moves": [
        "Bubble Beam",
        "Low Sweep",
        "Body Slam"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 25,
        "at": 25,
        "df": 25,
        "sa": 25,
        "sd": 25,
        "sp": 25
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 33,
      "gender": "M",
      "shiny": false,
      "speciesKey": "POLIWHIRL:0",
      "originalSpeciesKey": "POLIWHIRL:0",
      "trainerId": "FISHERMAN:Tully:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Growlithe [Hisuian]": {
    "Beauty April [Slot 1]": {
      "level": 29,
      "ability": "Intimidate",
      "moves": [
        "Fire Fang",
        "Crunch",
        "Rock Blast",
        "Agility"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 96,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GROWLITHE:1",
      "originalSpeciesKey": "GROWLITHE:1",
      "trainerId": "BEAUTY:April:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Elias & Kata [Slot 1]": {
      "level": 21,
      "ability": "Intimidate",
      "moves": [
        "Fire Fang",
        "Rock Blast",
        "Thunder Fang"
      ],
      "nature": "Jolly",
      "item": "Shuca Berry",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 34,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GROWLITHE:1",
      "originalSpeciesKey": "GROWLITHE:1",
      "trainerId": "UTOPIA_DUO:1:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Maractus": {
    "Picnicker Brooke [Slot 1]": {
      "level": 46,
      "ability": "Storm Drain",
      "moves": [
        "Giga Drain",
        "Scald",
        "Drain Punch",
        "Cotton Guard"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 173,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MARACTUS:0",
      "originalSpeciesKey": "MARACTUS:0",
      "trainerId": "PICNICKER:Brooke:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Elias & Kata [Slot 2]": {
      "level": 22,
      "ability": "Storm Drain",
      "moves": [
        "Giga Drain",
        "Water Pulse",
        "Sucker Punch"
      ],
      "nature": "Timid",
      "item": "Oran Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 34,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MARACTUS:0",
      "originalSpeciesKey": "MARACTUS:0",
      "trainerId": "UTOPIA_DUO:1:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Swoobat": {
    "Ace Trainer Elias & Kata [Slot 3]": {
      "level": 21,
      "ability": "Simple",
      "moves": [
        "Stored Power",
        "Air Cutter",
        "Swift",
        "Calm Mind"
      ],
      "nature": "Bold",
      "item": "Oran Berry",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 34,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SWOOBAT:0",
      "originalSpeciesKey": "SWOOBAT:0",
      "trainerId": "UTOPIA_DUO:1:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Mawile": {
    "Lass Amy [Slot 3]": {
      "level": 35,
      "ability": "Intimidate",
      "moves": [
        "Sucker Punch",
        "Iron Head",
        "Covet",
        "Ice Fang"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 119,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MAWILE:0",
      "originalSpeciesKey": "MAWILE:0",
      "trainerId": "LASS:Amy:0",
      "slot": 3,
      "doubles": false
    },
    "Ace Trainer Elias & Kata [Slot 4]": {
      "level": 22,
      "ability": "Hyper Cutter",
      "moves": [
        "Iron Head",
        "Play Rough",
        "Ice Fang"
      ],
      "nature": "Adamant",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 34,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MAWILE:0",
      "originalSpeciesKey": "MAWILE:0",
      "trainerId": "UTOPIA_DUO:1:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Zubat": {
    "Galactic F Grunt #1 [Slot 1]": {
      "level": 17,
      "ability": "Inner Focus",
      "moves": [
        "Poison Fang",
        "Aerial Ace",
        "Steel Wing",
        "Confuse Ray"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 36,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ZUBAT:0",
      "originalSpeciesKey": "ZUBAT:0",
      "trainerId": "GALACTIC_F:Grunt:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic Commander Jupiter [Slot 2]": {
      "level": 19,
      "ability": "Inner Focus",
      "moves": [
        "Venoshock",
        "Air Cutter",
        "Mega Drain",
        "Toxic"
      ],
      "nature": "Modest",
      "item": "Poison Barb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 41,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ZUBAT:0",
      "originalSpeciesKey": "ZUBAT:0",
      "trainerId": "JUPITER:Jupiter:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Zigzagoon [Galarian]": {
    "Galactic F Grunt #1 [Slot 2]": {
      "level": 18,
      "ability": "Quick Feet",
      "moves": [
        "Snarl",
        "Tail Slap",
        "Mud Shot",
        "Thunder Wave"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 36,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ZIGZAGOON:1",
      "originalSpeciesKey": "ZIGZAGOON:1",
      "trainerId": "GALACTIC_F:Grunt:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Pansear": {
    "Galactic M Grunt #1 [Slot 2]": {
      "level": 18,
      "ability": "Flash Fire",
      "moves": [
        "Incinerate",
        "Grass Knot",
        "Acrobatics"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 37,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PANSEAR:0",
      "originalSpeciesKey": "PANSEAR:0",
      "trainerId": "GALACTIC_M:Grunt:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Vigoroth": {
    "Galactic F Grunt #2 [Slot 1]": {
      "level": 16,
      "ability": "Vital Spirit",
      "moves": [
        "Fury Swipes",
        "Aerial Ace",
        "Throat Chop",
        "Bulk Up"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 38,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VIGOROTH:0",
      "originalSpeciesKey": "VIGOROTH:0",
      "trainerId": "GALACTIC_F:Grunt:1",
      "slot": 1,
      "doubles": false
    },
    "Pokemonranger M Douglas [Slot 4]": {
      "level": 23,
      "ability": "Vital Spirit",
      "moves": [
        "Strength",
        "Rock Smash",
        "Aerial Ace",
        "Slack Off"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 69,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VIGOROTH:0",
      "originalSpeciesKey": "VIGOROTH:0",
      "trainerId": "POKEMONRANGER_M:Douglas:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Ekans": {
    "Galactic F Grunt #2 [Slot 2]": {
      "level": 17,
      "ability": "Intimidate",
      "moves": [
        "Poison Tail",
        "Trailblaze",
        "Leech Life"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 38,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EKANS:0",
      "originalSpeciesKey": "EKANS:0",
      "trainerId": "GALACTIC_F:Grunt:1",
      "slot": 2,
      "doubles": false
    }
  },
  "Fuecoco": {
    "Galactic F Grunt #2 [Slot 3]": {
      "level": 18,
      "ability": "Blaze",
      "moves": [
        "Temper Flare",
        "Take Down",
        "Snarl"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 38,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FUECOCO:0",
      "originalSpeciesKey": "FUECOCO:0",
      "trainerId": "GALACTIC_F:Grunt:1",
      "slot": 3,
      "doubles": false
    }
  },
  "Flittle": {
    "Galactic M Grunt #2 [Slot 1]": {
      "level": 16,
      "ability": "Speed Boost",
      "moves": [
        "Psybeam",
        "Foul Play",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 39,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FLITTLE:0",
      "originalSpeciesKey": "FLITTLE:0",
      "trainerId": "GALACTIC_M:Grunt:1",
      "slot": 1,
      "doubles": false
    }
  },
  "Makuhita": {
    "Galactic M Grunt #2 [Slot 2]": {
      "level": 17,
      "ability": "Guts",
      "moves": [
        "Force Palm",
        "Thunder Punch",
        "Knock Off"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 39,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MAKUHITA:0",
      "originalSpeciesKey": "MAKUHITA:0",
      "trainerId": "GALACTIC_M:Grunt:1",
      "slot": 2,
      "doubles": false
    },
    "Crushgirl Sharon [Slot 1]": {
      "level": 21,
      "ability": "Thick Fat",
      "moves": [
        "Arm Thrust",
        "Payback",
        "Fake Out",
        "Sand Attack"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 61,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAKUHITA:0",
      "originalSpeciesKey": "MAKUHITA:0",
      "trainerId": "CRUSHGIRL:Sharon:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Quaxly": {
    "Galactic M Grunt #2 [Slot 3]": {
      "level": 18,
      "ability": "Torrent",
      "moves": [
        "Aqua Cutter",
        "Aqua Jet",
        "Wing Attack",
        "Low Kick"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 39,
      "gender": "M",
      "shiny": false,
      "speciesKey": "QUAXLY:0",
      "originalSpeciesKey": "QUAXLY:0",
      "trainerId": "GALACTIC_M:Grunt:1",
      "slot": 3,
      "doubles": false
    }
  },
  "Meowth [Alolan]": {
    "Galactic M Grunt #3 [Slot 1]": {
      "level": 16,
      "ability": "Technician",
      "moves": [
        "Snarl",
        "Chilling Water",
        "Icy Wind"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 40,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MEOWTH:1",
      "originalSpeciesKey": "MEOWTH:1",
      "trainerId": "GALACTIC_M:Grunt:2",
      "slot": 1,
      "doubles": false
    }
  },
  "Fidough": {
    "Galactic M Grunt #3 [Slot 2]": {
      "level": 17,
      "ability": "Own Tempo",
      "moves": [
        "Play Rough",
        "Ice Fang",
        "Dig",
        "Charm"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 40,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FIDOUGH:0",
      "originalSpeciesKey": "FIDOUGH:0",
      "trainerId": "GALACTIC_M:Grunt:2",
      "slot": 2,
      "doubles": false
    },
    "Camper Matti [Slot 1]": {
      "level": 23,
      "ability": "Own Tempo",
      "moves": [
        "Covet",
        "Headbutt",
        "Charm",
        "Fire Fang"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 71,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FIDOUGH:0",
      "originalSpeciesKey": "FIDOUGH:0",
      "trainerId": "CAMPER:Matti:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Sprigatito": {
    "Galactic M Grunt #3 [Slot 3]": {
      "level": 18,
      "ability": "Overgrow",
      "moves": [
        "Bullet Seed",
        "Bite",
        "Shadow Claw"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 28,
        "at": 28,
        "df": 28,
        "sa": 28,
        "sd": 28,
        "sp": 28
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 40,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SPRIGATITO:0",
      "originalSpeciesKey": "SPRIGATITO:0",
      "trainerId": "GALACTIC_M:Grunt:2",
      "slot": 3,
      "doubles": false
    }
  },
  "Luxio": {
    "Galactic Commander Jupiter [Slot 1]": {
      "level": 19,
      "ability": "Intimidate",
      "moves": [
        "Thunder Fang",
        "Ice Fang",
        "Psychic Fangs"
      ],
      "nature": "Jolly",
      "item": "Oran Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 41,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LUXIO:0",
      "originalSpeciesKey": "LUXIO:0",
      "trainerId": "JUPITER:Jupiter:0",
      "slot": 1,
      "doubles": false
    },
    "Gentleman Olaf [Slot 3]": {
      "level": 28,
      "ability": "Intimidate",
      "moves": [
        "Spark",
        "Play Rough",
        "Volt Switch",
        "Thunder Wave"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 81,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LUXIO:0",
      "originalSpeciesKey": "LUXIO:0",
      "trainerId": "GENTLEMAN:Olaf:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Capsakid": {
    "Galactic Commander Jupiter [Slot 3]": {
      "level": 19,
      "ability": "Insomnia",
      "moves": [
        "Magical Leaf",
        "Incinerate",
        "Snarl",
        "Will-O-Wisp"
      ],
      "nature": "Timid",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 41,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CAPSAKID:0",
      "originalSpeciesKey": "CAPSAKID:0",
      "trainerId": "JUPITER:Jupiter:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Skuntank": {
    "Galactic Commander Jupiter [Slot 4]": {
      "level": 20,
      "ability": "Aftermath",
      "moves": [
        "Poison Jab",
        "Brutal Swing",
        "Screech"
      ],
      "nature": "Serious",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 41,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SKUNTANK:0",
      "originalSpeciesKey": "SKUNTANK:0",
      "trainerId": "JUPITER:Jupiter:0",
      "slot": 4,
      "doubles": false
    },
    "Tamer Edgar [Slot 2]": {
      "level": 37,
      "ability": "Keen Eye",
      "moves": [
        "Poison Jab",
        "Crunch",
        "Double-Edge",
        "Screech"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 135,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SKUNTANK:0",
      "originalSpeciesKey": "SKUNTANK:0",
      "trainerId": "TAMER:Edgar:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #8 [Slot 1]": {
      "level": 48,
      "ability": "Aftermath",
      "moves": [
        "Sludge Bomb",
        "Dark Pulse",
        "Flamethrower",
        "Hyper Beam"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 205,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SKUNTANK:0",
      "originalSpeciesKey": "SKUNTANK:0",
      "trainerId": "GALACTIC_M:Grunt:7",
      "slot": 1,
      "doubles": false
    }
  },
  "Skiddo": {
    "Beauty Angela [Slot 1]": {
      "level": 18,
      "ability": "Sap Sipper",
      "moves": [
        "Horn Leech",
        "Wild Charge",
        "Stomping Tantrum",
        "Milk Drink"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 42,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SKIDDO:0",
      "originalSpeciesKey": "SKIDDO:0",
      "trainerId": "BEAUTY:Angela:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Ivysaur": {
    "Beauty Angela [Slot 2]": {
      "level": 19,
      "ability": "Overgrow",
      "moves": [
        "Giga Drain",
        "Venoshock",
        "Toxic"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 42,
      "gender": "M",
      "shiny": false,
      "speciesKey": "IVYSAUR:0",
      "originalSpeciesKey": "IVYSAUR:0",
      "trainerId": "BEAUTY:Angela:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Chewtle": {
    "Swimmer F Jenny [Slot 2]": {
      "level": 19,
      "ability": "Shell Armor",
      "moves": [
        "Waterfall",
        "Skitter Smack",
        "Headbutt",
        "Bite"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CHEWTLE:0",
      "originalSpeciesKey": "CHEWTLE:0",
      "trainerId": "SWIMMER_F:Jenny:0",
      "slot": 2,
      "doubles": false
    },
    "Swimmer Jenny & Aromalady Caroline [Slot 2]": {
      "level": 19,
      "ability": "Shell Armor",
      "moves": [
        "Waterfall",
        "Skitter Smack",
        "Headbutt",
        "Bite"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CHEWTLE:0",
      "originalSpeciesKey": "CHEWTLE:0",
      "trainerId": "UTOPIA_DUO:2:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Mantyke": {
    "Swimmer F Jenny [Slot 3]": {
      "level": 20,
      "ability": "Swift Swim",
      "moves": [
        "Bubble Beam",
        "Air Slash",
        "Icy Wind",
        "Roost"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MANTYKE:0",
      "originalSpeciesKey": "MANTYKE:0",
      "trainerId": "SWIMMER_F:Jenny:0",
      "slot": 3,
      "doubles": false
    },
    "Swimmer Jenny & Aromalady Caroline [Slot 3]": {
      "level": 20,
      "ability": "Swift Swim",
      "moves": [
        "Bubble Beam",
        "Air Slash",
        "Icy Wind",
        "Roost"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MANTYKE:0",
      "originalSpeciesKey": "MANTYKE:0",
      "trainerId": "UTOPIA_DUO:2:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Cacnea": {
    "Aromalady Caroline [Slot 1]": {
      "level": 18,
      "ability": "Water Absorb",
      "moves": [
        "Grassy Glide",
        "Payback",
        "Bulldoze"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 44,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CACNEA:0",
      "originalSpeciesKey": "CACNEA:0",
      "trainerId": "AROMALADY:Caroline:0",
      "slot": 1,
      "doubles": false
    },
    "Swimmer Jenny & Aromalady Caroline [Slot 4]": {
      "level": 18,
      "ability": "Water Absorb",
      "moves": [
        "Grassy Glide",
        "Payback",
        "Bulldoze"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CACNEA:0",
      "originalSpeciesKey": "CACNEA:0",
      "trainerId": "UTOPIA_DUO:2:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Morelull": {
    "Aromalady Caroline [Slot 2]": {
      "level": 19,
      "ability": "Effect Spore",
      "moves": [
        "Mega Drain",
        "Dazzling Gleam",
        "Spore"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 44,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MORELULL:0",
      "originalSpeciesKey": "MORELULL:0",
      "trainerId": "AROMALADY:Caroline:0",
      "slot": 2,
      "doubles": false
    },
    "Swimmer Jenny & Aromalady Caroline [Slot 5]": {
      "level": 19,
      "ability": "Effect Spore",
      "moves": [
        "Mega Drain",
        "Dazzling Gleam",
        "Spore"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MORELULL:0",
      "originalSpeciesKey": "MORELULL:0",
      "trainerId": "UTOPIA_DUO:2:0",
      "slot": 5,
      "doubles": true
    }
  },
  "Bramblin": {
    "Aromalady Caroline [Slot 3]": {
      "level": 20,
      "ability": "Wind Rider",
      "moves": [
        "Trailblaze",
        "Shadow Claw",
        "Pounce"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 44,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRAMBLIN:0",
      "originalSpeciesKey": "BRAMBLIN:0",
      "trainerId": "AROMALADY:Caroline:0",
      "slot": 3,
      "doubles": false
    },
    "Swimmer Jenny & Aromalady Caroline [Slot 6]": {
      "level": 20,
      "ability": "Wind Rider",
      "moves": [
        "Trailblaze",
        "Shadow Claw",
        "Pounce"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 43,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRAMBLIN:0",
      "originalSpeciesKey": "BRAMBLIN:0",
      "trainerId": "UTOPIA_DUO:2:0",
      "slot": 6,
      "doubles": true
    }
  },
  "Shellos [East Sea]": {
    "Swimmer F Lindsay [Slot 1]": {
      "level": 18,
      "ability": "Sand Force",
      "moves": [
        "Stealth Rock",
        "Water Pulse",
        "Mud Shot",
        "Recover"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 45,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SHELLOS:1",
      "originalSpeciesKey": "SHELLOS:1",
      "trainerId": "SWIMMER_F:Lindsay:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Skrelp": {
    "Swimmer F Lindsay [Slot 2]": {
      "level": 19,
      "ability": "Poison Point",
      "moves": [
        "Poison Tail",
        "Chilling Water",
        "Scale Shot"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 45,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SKRELP:0",
      "originalSpeciesKey": "SKRELP:0",
      "trainerId": "SWIMMER_F:Lindsay:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Goldeen": {
    "Swimmer F Lindsay [Slot 3]": {
      "level": 20,
      "ability": "Swift Swim",
      "moves": [
        "Whirlpool",
        "Poison Jab",
        "Smart Strike"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 45,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GOLDEEN:0",
      "originalSpeciesKey": "GOLDEEN:0",
      "trainerId": "SWIMMER_F:Lindsay:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Toedscool": {
    "Gym Leader Gardenia [Slot 1]": {
      "level": 21,
      "ability": "Mycelium Might",
      "moves": [
        "Mud Shot",
        "Giga Drain",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Modest",
      "item": "Berry Juice",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 46,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TOEDSCOOL:0",
      "originalSpeciesKey": "TOEDSCOOL:0",
      "trainerId": "LEADER_Gardenia:Gardenia:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Wiglett": {
    "Gym Leader Gardenia [Slot 2]": {
      "level": 21,
      "ability": "Gooey",
      "moves": [
        "Liquidation",
        "Aqua Jet",
        "Stomping Tantrum",
        "Facade"
      ],
      "nature": "Adamant",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 46,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WIGLETT:0",
      "originalSpeciesKey": "WIGLETT:0",
      "trainerId": "LEADER_Gardenia:Gardenia:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Voltorb [Hisuian]": {
    "Gym Leader Gardenia [Slot 3]": {
      "level": 21,
      "ability": "Static",
      "moves": [
        "Charge Beam",
        "Giga Drain",
        "Foul Play",
        "Hidden Power"
      ],
      "nature": "Bold",
      "item": "Oran Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 30
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 46,
      "gender": "",
      "shiny": false,
      "speciesKey": "VOLTORB:1",
      "originalSpeciesKey": "VOLTORB:1",
      "trainerId": "LEADER_Gardenia:Gardenia:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Clauncher": {
    "Gym Leader Gardenia [Slot 4]": {
      "level": 21,
      "ability": "Mega Launcher",
      "moves": [
        "Water Pulse",
        "Aqua Jet",
        "Aura Sphere",
        "Dark Pulse"
      ],
      "nature": "Timid",
      "item": "Salac Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 46,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLAUNCHER:0",
      "originalSpeciesKey": "CLAUNCHER:0",
      "trainerId": "LEADER_Gardenia:Gardenia:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Gloom": {
    "Gym Leader Gardenia [Slot 5]": {
      "level": 22,
      "ability": "Stench",
      "moves": [
        "Mega Drain",
        "Acid Spray",
        "Leech Seed"
      ],
      "nature": "Calm",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 46,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GLOOM:0",
      "originalSpeciesKey": "GLOOM:0",
      "trainerId": "LEADER_Gardenia:Gardenia:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Fearow": {
    "Birdkeeper Boris [Slot 1]": {
      "level": 20,
      "ability": "Keen Eye",
      "moves": [
        "Take Down",
        "Dual Wingbeat",
        "Steel Wing",
        "Focus Energy"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 47,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FEAROW:0",
      "originalSpeciesKey": "FEAROW:0",
      "trainerId": "BIRDKEEPER:Boris:0",
      "slot": 1,
      "doubles": false
    },
    "Engineer Ricky [Slot 2]": {
      "level": 23,
      "ability": "Sniper",
      "moves": [
        "Fury Attack",
        "Aerial Ace",
        "Assurance",
        "Feather Dance"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 67,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FEAROW:0",
      "originalSpeciesKey": "FEAROW:0",
      "trainerId": "ENGINEER:Ricky:0",
      "slot": 2,
      "doubles": false
    },
    "Biker Spike [Slot 2]": {
      "level": 33,
      "ability": "Moxie",
      "moves": [
        "Feather Dance",
        "Steel Wing",
        "False Swipe",
        "Take Down"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 110,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FEAROW:0",
      "originalSpeciesKey": "FEAROW:0",
      "trainerId": "BIKER:Spike:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #18 [Slot 4]": {
      "level": 73,
      "ability": "Sniper",
      "moves": [
        "Double-Edge",
        "Drill Peck",
        "Drill Run",
        "Assurance"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 279,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FEAROW:0",
      "originalSpeciesKey": "FEAROW:0",
      "trainerId": "GALACTIC_M:Grunt:18",
      "slot": 4,
      "doubles": false
    }
  },
  "Noctowl": {
    "Birdkeeper Boris [Slot 2]": {
      "level": 21,
      "ability": "Keen Eye",
      "moves": [
        "Psybeam",
        "Air Slash",
        "Night Shade",
        "Roost"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 47,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NOCTOWL:0",
      "originalSpeciesKey": "NOCTOWL:0",
      "trainerId": "BIRDKEEPER:Boris:0",
      "slot": 2,
      "doubles": false
    },
    "Scientist Reed [Slot 2]": {
      "level": 34,
      "ability": "Keen Eye",
      "moves": [
        "Extrasensory",
        "Air Slash",
        "Hyper Voice",
        "Roost"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 124,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NOCTOWL:0",
      "originalSpeciesKey": "NOCTOWL:0",
      "trainerId": "SCIENTIST:Reed:0",
      "slot": 2,
      "doubles": false
    },
    "Gentleman Bernarnd [Slot 2]": {
      "level": 47,
      "ability": "Tinted Lens",
      "moves": [
        "Hyper Voice",
        "Air Slash",
        "Heat Wave",
        "Hypnosis"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 178,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NOCTOWL:0",
      "originalSpeciesKey": "NOCTOWL:0",
      "trainerId": "GENTLEMAN:Bernarnd:0",
      "slot": 2,
      "doubles": false
    },
    "Psychic F Summer [Slot 4]": {
      "level": 65,
      "ability": "Tinted Lens",
      "moves": [
        "Hyper Voice",
        "Hurricane",
        "Heat Wave",
        "Hypnosis"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 234,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NOCTOWL:0",
      "originalSpeciesKey": "NOCTOWL:0",
      "trainerId": "PSYCHIC_F:Summer:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Tranquill": {
    "Birdkeeper Boris [Slot 3]": {
      "level": 22,
      "ability": "Super Luck",
      "moves": [
        "Round",
        "Quick Attack",
        "Air Cutter",
        "Swagger [SWAGGER]"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 47,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TRANQUILL:0",
      "originalSpeciesKey": "TRANQUILL:0",
      "trainerId": "BIRDKEEPER:Boris:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Cubone": {
    "Hiker Jackson [Slot 1]": {
      "level": 21,
      "ability": "Battle Armor",
      "moves": [
        "Earth Power",
        "Flamethrower",
        "Ice Beam"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 48,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CUBONE:0",
      "originalSpeciesKey": "CUBONE:0",
      "trainerId": "HIKER:Jackson:0",
      "slot": 1,
      "doubles": false
    },
    "Lass Stacy [Slot 1]": {
      "level": 21,
      "ability": "Battle Armor",
      "moves": [
        "Rock Tomb",
        "Bone Club",
        "Swift",
        "Dig"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 60,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CUBONE:0",
      "originalSpeciesKey": "CUBONE:0",
      "trainerId": "LASS:Stacy:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Nosepass": {
    "Hiker Jackson [Slot 2]": {
      "level": 22,
      "ability": "Magnet Pull",
      "moves": [
        "Rock Blast",
        "Spark",
        "Ice Punch",
        "Thunder Wave"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 48,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NOSEPASS:0",
      "originalSpeciesKey": "NOSEPASS:0",
      "trainerId": "HIKER:Jackson:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Frigibax": {
    "Lass Amber [Slot 1]": {
      "level": 21,
      "ability": "Thermal Exchange",
      "moves": [
        "Dragon Tail",
        "Ice Fang",
        "Body Slam",
        "Leer"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 49,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FRIGIBAX:0",
      "originalSpeciesKey": "FRIGIBAX:0",
      "trainerId": "LASS:Amber:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Inkay": {
    "Lass Amber [Slot 2]": {
      "level": 22,
      "ability": "Suction Cups",
      "moves": [
        "Payback",
        "Psybeam",
        "Hypnosis",
        "Pluck"
      ],
      "nature": "Brave",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 49,
      "gender": "F",
      "shiny": false,
      "speciesKey": "INKAY:0",
      "originalSpeciesKey": "INKAY:0",
      "trainerId": "LASS:Amber:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Swadloon": {
    "Bugcatcher Daniel [Slot 1]": {
      "level": 20,
      "ability": "Swarm",
      "moves": [
        "Bug Bite",
        "Thunder Fang",
        "Psychic Fangs",
        "Charm"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 50,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SWADLOON:0",
      "originalSpeciesKey": "SWADLOON:0",
      "trainerId": "BUGCATCHER:Daniel:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Whirlipede": {
    "Bugcatcher Daniel [Slot 2]": {
      "level": 21,
      "ability": "Speed Boost",
      "moves": [
        "Bug Bite",
        "Poison Jab",
        "Iron Defense",
        "Protect"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 50,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WHIRLIPEDE:0",
      "originalSpeciesKey": "WHIRLIPEDE:0",
      "trainerId": "BUGCATCHER:Daniel:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Vivillon [Garden Pattern]": {
    "Bugcatcher Daniel [Slot 3]": {
      "level": 22,
      "ability": "Shield Dust",
      "moves": [
        "Struggle Bug",
        "Air Cutter",
        "Psybeam",
        "Stun Spore"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 50,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VIVILLON:3",
      "originalSpeciesKey": "VIVILLON:3",
      "trainerId": "BUGCATCHER:Daniel:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Jigglypuff": {
    "Lass Sabrina [Slot 1]": {
      "level": 21,
      "ability": "Cute Charm",
      "moves": [
        "Magical Leaf",
        "Wake-Up Slap",
        "Thunder Wave",
        "Covet"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 51,
      "gender": "F",
      "shiny": false,
      "speciesKey": "JIGGLYPUFF:0",
      "originalSpeciesKey": "JIGGLYPUFF:0",
      "trainerId": "LASS:Sabrina:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Wooloo": {
    "Lass Sabrina [Slot 2]": {
      "level": 22,
      "ability": "Fluffy",
      "moves": [
        "Copycat",
        "Double Kick",
        "Attract",
        "Headbutt"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 51,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WOOLOO:0",
      "originalSpeciesKey": "WOOLOO:0",
      "trainerId": "LASS:Sabrina:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Raticate [Alolan]": {
    "Lass Sabrina [Slot 3]": {
      "level": 23,
      "ability": "Hustle",
      "moves": [
        "Pursuit",
        "Assurance",
        "Fury Swipes",
        "Take Down"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 51,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RATICATE:1",
      "originalSpeciesKey": "RATICATE:1",
      "trainerId": "LASS:Sabrina:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic F Grunt #3 [Slot 3]": {
      "level": 35,
      "ability": "Thick Fat",
      "moves": [
        "Crunch",
        "Pursuit",
        "Super Fang",
        "Zen Headbutt"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 127,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RATICATE:1",
      "originalSpeciesKey": "RATICATE:1",
      "trainerId": "GALACTIC_F:Grunt:2",
      "slot": 3,
      "doubles": false
    }
  },
  "Ponyta": {
    "Lass Saskia [Slot 1]": {
      "level": 21,
      "ability": "Flash Fire",
      "moves": [
        "Ember",
        "Stomp",
        "Fire Spin",
        "Flame Wheel"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 52,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PONYTA:0",
      "originalSpeciesKey": "PONYTA:0",
      "trainerId": "LASS:Saskia:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Salandit": {
    "Lass Saskia [Slot 3]": {
      "level": 23,
      "ability": "Corrosion",
      "moves": [
        "Sweet Scent",
        "Venom Drench",
        "Flame Burst",
        "Dragon Breath"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 52,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SALANDIT:0",
      "originalSpeciesKey": "SALANDIT:0",
      "trainerId": "LASS:Saskia:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Meditite": {
    "Blackbelt Mike [Slot 4]": {
      "level": 23,
      "ability": "Telepathy",
      "moves": [
        "Low Kick",
        "Psybeam",
        "Grass Knot",
        "Calm Mind"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 63,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MEDITITE:0",
      "originalSpeciesKey": "MEDITITE:0",
      "trainerId": "BLACKBELT:Mike:0",
      "slot": 4,
      "doubles": false
    },
    "Crushgirl Mel [Slot 1]": {
      "level": 31,
      "ability": "Pure Power",
      "moves": [
        "Fake Out",
        "Brick Break",
        "Rock Tomb",
        "Zen Headbutt"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 92,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MEDITITE:0",
      "originalSpeciesKey": "MEDITITE:0",
      "trainerId": "CRUSHGIRL:Mel:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Tom (DOUBLES) [Slot 1]": {
      "level": 22,
      "ability": "Telepathy",
      "moves": [
        "Force Palm",
        "Zen Headbutt",
        "Rock Tomb",
        "Fake Out"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 53,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MEDITITE:0",
      "originalSpeciesKey": "MEDITITE:0",
      "trainerId": "HIKER:Tom:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Hippopotas": {
    "Hiker Tom (DOUBLES) [Slot 2]": {
      "level": 22,
      "ability": "Sand Force",
      "moves": [
        "Bulldoze",
        "Rock Tomb",
        "Crunch",
        "Curse"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 53,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HIPPOPOTAS:0",
      "originalSpeciesKey": "HIPPOPOTAS:0",
      "trainerId": "HIKER:Tom:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Nacli": {
    "Hiker Benjamin [Slot 1]": {
      "level": 21,
      "ability": "Purifying Salt",
      "moves": [
        "Stealth Rock",
        "Smack Down",
        "Stomping Tantrum",
        "Recover"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 54,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NACLI:0",
      "originalSpeciesKey": "NACLI:0",
      "trainerId": "HIKER:Benjamin:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Magby": {
    "Hiker Benjamin [Slot 2]": {
      "level": 22,
      "ability": "Flame Body",
      "moves": [
        "Burning Jealousy",
        "Thunder Punch",
        "Low Kick",
        "Smokescreen"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 54,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAGBY:0",
      "originalSpeciesKey": "MAGBY:0",
      "trainerId": "HIKER:Benjamin:0",
      "slot": 2,
      "doubles": false
    },
    "Pokemonbreeder Beatrix [Slot 2]": {
      "level": 22,
      "ability": "Flame Body",
      "moves": [
        "Fire Punch",
        "Low Kick",
        "Thunder Punch",
        "Smokescreen"
      ],
      "nature": "Lonely",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 73,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MAGBY:0",
      "originalSpeciesKey": "MAGBY:0",
      "trainerId": "POKEMONBREEDER:Beatrix:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Sandygast": {
    "Hiker Benjamin [Slot 3]": {
      "level": 23,
      "ability": "Water Compaction",
      "moves": [
        "Night Shade",
        "Mud Shot",
        "Mega Drain",
        "Shore Up"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 54,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SANDYGAST:0",
      "originalSpeciesKey": "SANDYGAST:0",
      "trainerId": "HIKER:Benjamin:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Bayleef": {
    "Pokemaniac Jim [Slot 1]": {
      "level": 22,
      "ability": "Overgrow",
      "moves": [
        "Giga Drain",
        "Ancient Power",
        "Leech Seed",
        "Fake Tears"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 55,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BAYLEEF:0",
      "originalSpeciesKey": "BAYLEEF:0",
      "trainerId": "POKEMANIAC:Jim:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Cranidos": {
    "Pokemaniac Jim [Slot 2]": {
      "level": 23,
      "ability": "Mold Breaker",
      "moves": [
        "Rock Slide",
        "Zen Headbutt",
        "Assurance",
        "Take Down"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 55,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CRANIDOS:0",
      "originalSpeciesKey": "CRANIDOS:0",
      "trainerId": "POKEMANIAC:Jim:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Corvisquire": {
    "Pokemonranger M Russell [Slot 1]": {
      "level": 21,
      "ability": "Unnerve",
      "moves": [
        "Pluck",
        "Power Trip",
        "Reversal",
        "Hone Claws"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 56,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CORVISQUIRE:0",
      "originalSpeciesKey": "CORVISQUIRE:0",
      "trainerId": "POKEMONRANGER_M:Russell:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Axew": {
    "Pokemonranger M Russell [Slot 2]": {
      "level": 22,
      "ability": "Mold Breaker",
      "moves": [
        "Breaking Swipe",
        "Brick Break",
        "Bite",
        "Focus Energy"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 56,
      "gender": "F",
      "shiny": false,
      "speciesKey": "AXEW:0",
      "originalSpeciesKey": "AXEW:0",
      "trainerId": "POKEMONRANGER_M:Russell:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Spinda": {
    "Pokemonranger M Russell [Slot 3]": {
      "level": 23,
      "ability": "Contrary",
      "moves": [
        "Metronome",
        "Sucker Punch"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 56,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SPINDA:0",
      "originalSpeciesKey": "SPINDA:0",
      "trainerId": "POKEMONRANGER_M:Russell:0",
      "slot": 3,
      "doubles": false
    },
    "Gambler Reggie [Slot 3]": {
      "level": 48,
      "ability": "Contrary",
      "moves": [
        "Dizzy Punch",
        "Psycho Boost",
        "Hypnosis"
      ],
      "nature": "Serious",
      "item": "Chople Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 181,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SPINDA:0",
      "originalSpeciesKey": "SPINDA:0",
      "trainerId": "GAMBLER:Reggie:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Voltorb": {
    "Supernerd Elias [Slot 1]": {
      "level": 22,
      "ability": "Static",
      "moves": [
        "Charge Beam",
        "Signal Beam",
        "Light Screen",
        "Explosion"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 57,
      "gender": "",
      "shiny": false,
      "speciesKey": "VOLTORB:0",
      "originalSpeciesKey": "VOLTORB:0",
      "trainerId": "SUPERNERD:Elias:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Solosis": {
    "Supernerd Elias [Slot 2]": {
      "level": 22,
      "ability": "Magic Guard",
      "moves": [
        "Psyshock",
        "Night Shade",
        "Reflect",
        "Recover"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 57,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SOLOSIS:0",
      "originalSpeciesKey": "SOLOSIS:0",
      "trainerId": "SUPERNERD:Elias:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Watchog": {
    "Supernerd Elias [Slot 3]": {
      "level": 23,
      "ability": "Keen Eye",
      "moves": [
        "Hyper Fang",
        "Crunch",
        "Low Kick",
        "Mean Look"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 57,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WATCHOG:0",
      "originalSpeciesKey": "WATCHOG:0",
      "trainerId": "SUPERNERD:Elias:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Vulpix [Alolan]": {
    "Lass Isabelle [Slot 2]": {
      "level": 22,
      "ability": "Snow Cloak",
      "moves": [
        "Aurora Beam",
        "Extrasensory",
        "Chilling Water",
        "Charm"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 58,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VULPIX:1",
      "originalSpeciesKey": "VULPIX:1",
      "trainerId": "LASS:Isabelle:0",
      "slot": 2,
      "doubles": false
    },
    "Lass Brooke [Slot 1]": {
      "level": 30,
      "ability": "Snow Warning",
      "moves": [
        "Freeze-Dry",
        "Draining Kiss",
        "Confuse Ray",
        "Aurora Veil"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 99,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VULPIX:1",
      "originalSpeciesKey": "VULPIX:1",
      "trainerId": "LASS:Brooke:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Tentacool": {
    "Lass Isabelle [Slot 3]": {
      "level": 23,
      "ability": "Clear Body",
      "moves": [
        "Bubble Beam",
        "Poison Jab",
        "Knock Off",
        "Acid Armor"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 58,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TENTACOOL:0",
      "originalSpeciesKey": "TENTACOOL:0",
      "trainerId": "LASS:Isabelle:0",
      "slot": 3,
      "doubles": false
    },
    "Sailor Ernest [Slot 2]": {
      "level": 24,
      "ability": "Clear Body",
      "moves": [
        "Bubble Beam",
        "Venoshock",
        "Knock Off",
        "Toxic"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 74,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TENTACOOL:0",
      "originalSpeciesKey": "TENTACOOL:0",
      "trainerId": "SAILOR:Ernest:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Slugma": {
    "Supernerd Tilo [Slot 2]": {
      "level": 23,
      "ability": "Flame Body",
      "moves": [
        "Incinerate",
        "Ancient Power",
        "Mud Shot",
        "Pain Split"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 59,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLUGMA:0",
      "originalSpeciesKey": "SLUGMA:0",
      "trainerId": "SUPERNERD:Tilo:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Sinistea": {
    "Lass Stacy [Slot 2]": {
      "level": 22,
      "ability": "Cursed Body",
      "moves": [
        "Astonish",
        "Confusion",
        "Mega Drain",
        "Sucker Punch"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 60,
      "gender": "",
      "shiny": false,
      "speciesKey": "SINISTEA:0",
      "originalSpeciesKey": "SINISTEA:0",
      "trainerId": "LASS:Stacy:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Gligar": {
    "Lass Stacy [Slot 3]": {
      "level": 22,
      "ability": "Hyper Cutter",
      "moves": [
        "Mud Bomb",
        "Feint Attack",
        "Metal Claw",
        "Aerial Ace"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 60,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GLIGAR:0",
      "originalSpeciesKey": "GLIGAR:0",
      "trainerId": "LASS:Stacy:0",
      "slot": 3,
      "doubles": false
    },
    "Hiker Eduard [Slot 1]": {
      "level": 21,
      "ability": "Hyper Cutter",
      "moves": [
        "Bulldoze",
        "Aerial Ace",
        "Fire Fang",
        "Knock Off"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 68,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GLIGAR:0",
      "originalSpeciesKey": "GLIGAR:0",
      "trainerId": "HIKER:Eduard:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Kecleon": {
    "Lass Stacy [Slot 4]": {
      "level": 23,
      "ability": "Color Change",
      "moves": [
        "Cut",
        "Shadow Sneak",
        "Night Slash",
        "Slash"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 60,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KECLEON:0",
      "originalSpeciesKey": "KECLEON:0",
      "trainerId": "LASS:Stacy:0",
      "slot": 4,
      "doubles": false
    },
    "Hiker Jerry [Slot 1]": {
      "level": 32,
      "ability": "Protean",
      "moves": [
        "Slash",
        "Ancient Power",
        "Fake Out",
        "Low Kick"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 93,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KECLEON:0",
      "originalSpeciesKey": "KECLEON:0",
      "trainerId": "HIKER:Jerry:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Breloom": {
    "Crushgirl Sharon [Slot 2]": {
      "level": 22,
      "ability": "Effect Spore",
      "moves": [
        "Mach Punch",
        "Force Palm",
        "Rock Tomb",
        "Stun Spore"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 61,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BRELOOM:0",
      "originalSpeciesKey": "BRELOOM:0",
      "trainerId": "CRUSHGIRL:Sharon:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #12 [Slot 1]": {
      "level": 72,
      "ability": "Technician",
      "moves": [
        "Mach Punch",
        "Bullet Seed",
        "Rock Tomb",
        "Spore"
      ],
      "nature": "Adamant",
      "item": "Coba Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 272,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRELOOM:0",
      "originalSpeciesKey": "BRELOOM:0",
      "trainerId": "GALACTIC_M:Grunt:11",
      "slot": 1,
      "doubles": false
    }
  },
  "Scraggy": {
    "Crushgirl Sharon [Slot 3]": {
      "level": 22,
      "ability": "Moxie",
      "moves": [
        "Crunch",
        "Drain Punch",
        "Ice Punch"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 61,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SCRAGGY:0",
      "originalSpeciesKey": "SCRAGGY:0",
      "trainerId": "CRUSHGIRL:Sharon:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Sudowoodo": {
    "Ruinmaniac Detlef [Slot 1]": {
      "level": 22,
      "ability": "Sturdy",
      "moves": [
        "Sucker Punch",
        "Rock Tomb",
        "Bullet Seed"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 62,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SUDOWOODO:0",
      "originalSpeciesKey": "SUDOWOODO:0",
      "trainerId": "RUINMANIAC:Detlef:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Michael [Slot 1]": {
      "level": 46,
      "ability": "Sturdy",
      "moves": [
        "Stone Edge",
        "Earthquake",
        "Explosion",
        "Flail"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 176,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SUDOWOODO:0",
      "originalSpeciesKey": "SUDOWOODO:0",
      "trainerId": "HIKER:Michael:0",
      "slot": 1,
      "doubles": false
    },
    "Rocker Leroy [Slot 3]": {
      "level": 66,
      "ability": "Rock Head",
      "moves": [
        "Head Smash",
        "Wood Hammer",
        "Double-Edge",
        "Submission"
      ],
      "nature": "Adamant",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 240,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SUDOWOODO:0",
      "originalSpeciesKey": "SUDOWOODO:0",
      "trainerId": "ROCKER:Leroy:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Carkol": {
    "Ruinmaniac Detlef [Slot 2]": {
      "level": 23,
      "ability": "Heatproof",
      "moves": [
        "Ancient Power",
        "Incinerate",
        "Iron Head"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 62,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CARKOL:0",
      "originalSpeciesKey": "CARKOL:0",
      "trainerId": "RUINMANIAC:Detlef:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Pawmo": {
    "Blackbelt Mike [Slot 1]": {
      "level": 21,
      "ability": "Iron Fist",
      "moves": [
        "Thunder Punch",
        "Low Sweep",
        "Crunch",
        "Quick Attack"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 63,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PAWMO:0",
      "originalSpeciesKey": "PAWMO:0",
      "trainerId": "BLACKBELT:Mike:0",
      "slot": 1,
      "doubles": false
    },
    "Gentleman Brent [Slot 1]": {
      "level": 29,
      "ability": "Natural Cure",
      "moves": [
        "Discharge",
        "Super Fang",
        "Knock Off",
        "Substitute"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 97,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PAWMO:0",
      "originalSpeciesKey": "PAWMO:0",
      "trainerId": "GENTLEMAN:Brent:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Croagunk": {
    "Blackbelt Mike [Slot 2]": {
      "level": 22,
      "ability": "Poison Touch",
      "moves": [
        "Venoshock",
        "Brick Break",
        "Foul Play",
        "Sucker Punch"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 63,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CROAGUNK:0",
      "originalSpeciesKey": "CROAGUNK:0",
      "trainerId": "BLACKBELT:Mike:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic F Grunt #3 [Slot 1]": {
      "level": 34,
      "ability": "Poison Touch",
      "moves": [
        "Fake Out",
        "Gunk Shot",
        "Venoshock",
        "Brick Break"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 127,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CROAGUNK:0",
      "originalSpeciesKey": "CROAGUNK:0",
      "trainerId": "GALACTIC_F:Grunt:2",
      "slot": 1,
      "doubles": false
    }
  },
  "Stufful": {
    "Blackbelt Mike [Slot 3]": {
      "level": 22,
      "ability": "Fluffy",
      "moves": [
        "Strength",
        "Brick Break",
        "Ice Punch",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 63,
      "gender": "F",
      "shiny": false,
      "speciesKey": "STUFFUL:0",
      "originalSpeciesKey": "STUFFUL:0",
      "trainerId": "BLACKBELT:Mike:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Numel": {
    "Picnicker Denise [Slot 1]": {
      "level": 21,
      "ability": "Simple",
      "moves": [
        "Incinerate",
        "Scorching Sands",
        "Stealth Rock",
        "Amnesia"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 64,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NUMEL:0",
      "originalSpeciesKey": "NUMEL:0",
      "trainerId": "PICNICKER:Denise:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Wailmer": {
    "Picnicker Denise [Slot 2]": {
      "level": 22,
      "ability": "Oblivious",
      "moves": [
        "Water Pulse",
        "Brine",
        "Icy Wind",
        "Roar"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 64,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WAILMER:0",
      "originalSpeciesKey": "WAILMER:0",
      "trainerId": "PICNICKER:Denise:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Butterfree": {
    "Picnicker Denise [Slot 3]": {
      "level": 22,
      "ability": "Compound Eyes",
      "moves": [
        "Bug Bite",
        "Air Slash",
        "Draining Kiss",
        "Double Team"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 64,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BUTTERFREE:0",
      "originalSpeciesKey": "BUTTERFREE:0",
      "trainerId": "PICNICKER:Denise:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Skwovet": {
    "Picnicker Denise [Slot 4]": {
      "level": 23,
      "ability": "Cheek Pouch",
      "moves": [
        "Body Slam",
        "Bullet Seed",
        "Thief",
        "Curse"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 64,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SKWOVET:0",
      "originalSpeciesKey": "SKWOVET:0",
      "trainerId": "PICNICKER:Denise:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Anorith": {
    "Hiker Hugo [Slot 2]": {
      "level": 22,
      "ability": "Battle Armor",
      "moves": [
        "Rock Tomb",
        "Bug Bite",
        "Crush Claw",
        "Screech"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 65,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ANORITH:0",
      "originalSpeciesKey": "ANORITH:0",
      "trainerId": "HIKER:Hugo:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Shieldon": {
    "Hiker Hugo [Slot 3]": {
      "level": 23,
      "ability": "Sturdy",
      "moves": [
        "Ancient Power",
        "Hard Press",
        "Stomping Tantrum",
        "Iron Defense"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 65,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SHIELDON:0",
      "originalSpeciesKey": "SHIELDON:0",
      "trainerId": "HIKER:Hugo:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Girafarig": {
    "Burglar Lazze [Slot 1]": {
      "level": 21,
      "ability": "Inner Focus",
      "moves": [
        "Hyper Voice",
        "Psybeam",
        "Reflect",
        "Light Screen"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 66,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GIRAFARIG:0",
      "originalSpeciesKey": "GIRAFARIG:0",
      "trainerId": "BURGLAR:Lazze:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer F Serena [Slot 4]": {
      "level": 42,
      "ability": "Inner Focus",
      "moves": [
        "Hyper Voice",
        "Psyshield Bash",
        "Energy Ball",
        "Nasty Plot"
      ],
      "nature": "Jolly",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 157,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GIRAFARIG:0",
      "originalSpeciesKey": "GIRAFARIG:0",
      "trainerId": "COOLTRAINER_F:Serena:0",
      "slot": 4,
      "doubles": false
    },
    "Psychic M Neagle [Slot 1]": {
      "level": 48,
      "ability": "Inner Focus",
      "moves": [
        "Body Slam",
        "Psyshield Bash",
        "High Horsepower",
        "Dazzling Gleam"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 191,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GIRAFARIG:0",
      "originalSpeciesKey": "GIRAFARIG:0",
      "trainerId": "PSYCHIC_M:Neagle:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Colette (DOUBLES) [Slot 2]": {
      "level": 79,
      "ability": "Early Bird",
      "moves": [
        "Boomburst",
        "Dazzling Gleam",
        "High Horsepower"
      ],
      "nature": "Quiet",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 0
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 287,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GIRAFARIG:0",
      "originalSpeciesKey": "GIRAFARIG:0",
      "trainerId": "COOLTRAINER_F:Colette:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Koffing": {
    "Burglar Lazze [Slot 2]": {
      "level": 22,
      "ability": "Levitate",
      "moves": [
        "Sludge",
        "Psybeam",
        "Will-O-Wisp",
        "Explosion"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 66,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KOFFING:0",
      "originalSpeciesKey": "KOFFING:0",
      "trainerId": "BURGLAR:Lazze:0",
      "slot": 2,
      "doubles": false
    },
    "Juggler Blake [Slot 1]": {
      "level": 29,
      "ability": "Levitate",
      "moves": [
        "Sludge",
        "Venoshock",
        "Flamethrower",
        "Self-Destruct"
      ],
      "nature": "Lax",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 95,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KOFFING:0",
      "originalSpeciesKey": "KOFFING:0",
      "trainerId": "JUGGLER:Blake:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Golbat": {
    "Burglar Lazze [Slot 3]": {
      "level": 22,
      "ability": "Inner Focus",
      "moves": [
        "Poison Fang",
        "Air Slash",
        "Leech Life",
        "Roost"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 66,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GOLBAT:0",
      "originalSpeciesKey": "GOLBAT:0",
      "trainerId": "BURGLAR:Lazze:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic F Grunt #3 [Slot 2]": {
      "level": 35,
      "ability": "Shadow Tag",
      "moves": [
        "Poison Fang",
        "Air Slash",
        "Giga Drain",
        "Leech Life"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 127,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GOLBAT:0",
      "originalSpeciesKey": "GOLBAT:0",
      "trainerId": "GALACTIC_F:Grunt:2",
      "slot": 2,
      "doubles": false
    }
  },
  "Mightyena": {
    "Burglar Lazze [Slot 4]": {
      "level": 23,
      "ability": "Intimidate",
      "moves": [
        "Sucker Punch",
        "Crunch",
        "Fire Fang",
        "Thunder Fang"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 66,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MIGHTYENA:0",
      "originalSpeciesKey": "MIGHTYENA:0",
      "trainerId": "BURGLAR:Lazze:0",
      "slot": 4,
      "doubles": false
    },
    "Biker Axel [Slot 1]": {
      "level": 33,
      "ability": "Intimidate",
      "moves": [
        "Poison Fang",
        "Crunch",
        "Play Rough",
        "Yawn"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 108,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MIGHTYENA:0",
      "originalSpeciesKey": "MIGHTYENA:0",
      "trainerId": "BIKER:Axel:0",
      "slot": 1,
      "doubles": false
    },
    "Tamer Edgar [Slot 4]": {
      "level": 38,
      "ability": "Strong Jaw",
      "moves": [
        "Crunch",
        "Psychic Fangs",
        "Thunder Fang",
        "Fire Fang"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 135,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MIGHTYENA:0",
      "originalSpeciesKey": "MIGHTYENA:0",
      "trainerId": "TAMER:Edgar:0",
      "slot": 4,
      "doubles": false
    },
    "Biker Richie [Slot 1]": {
      "level": 47,
      "ability": "Strong Jaw",
      "moves": [
        "Yawn",
        "Sucker Punch",
        "Psychic Fangs",
        "Super Fang"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 185,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MIGHTYENA:0",
      "originalSpeciesKey": "MIGHTYENA:0",
      "trainerId": "BIKER:Richie:0",
      "slot": 1,
      "doubles": false
    },
    "Juggler Santino [Slot 1]": {
      "level": 66,
      "ability": "Intimidate",
      "moves": [
        "Yawn",
        "Sucker Punch",
        "Psychic Fangs",
        "Super Fang"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 249,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MIGHTYENA:0",
      "originalSpeciesKey": "MIGHTYENA:0",
      "trainerId": "JUGGLER:Santino:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Flaaffy": {
    "Engineer Ricky [Slot 1]": {
      "level": 23,
      "ability": "Static",
      "moves": [
        "Growl",
        "Cotton Spore",
        "Shock Wave",
        "Thunder Punch"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 67,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FLAAFFY:0",
      "originalSpeciesKey": "FLAAFFY:0",
      "trainerId": "ENGINEER:Ricky:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Meowth [Galarian]": {
    "Hiker Eduard [Slot 2]": {
      "level": 22,
      "ability": "Tough Claws",
      "moves": [
        "Metal Claw",
        "Trailblaze",
        "Brick Break",
        "Amnesia"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 68,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MEOWTH:2",
      "originalSpeciesKey": "MEOWTH:2",
      "trainerId": "HIKER:Eduard:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Phantump": {
    "Hiker Eduard [Slot 3]": {
      "level": 22,
      "ability": "Natural Cure",
      "moves": [
        "Horn Leech",
        "Shadow Claw",
        "Skitter Smack",
        "Leech Seed"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 68,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PHANTUMP:0",
      "originalSpeciesKey": "PHANTUMP:0",
      "trainerId": "HIKER:Eduard:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Amaura": {
    "Hiker Eduard [Slot 4]": {
      "level": 23,
      "ability": "Refrigerate",
      "moves": [
        "Ancient Power",
        "Freeze-Dry",
        "Mud Shot",
        "Thunder Wave"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 68,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AMAURA:0",
      "originalSpeciesKey": "AMAURA:0",
      "trainerId": "HIKER:Eduard:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Farfetch'd": {
    "Pokemonranger M Douglas [Slot 1]": {
      "level": 21,
      "ability": "Keen Eye",
      "moves": [
        "Slash",
        "Aerial Ace",
        "Cut",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 69,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FARFETCHD:0",
      "originalSpeciesKey": "FARFETCHD:0",
      "trainerId": "POKEMONRANGER_M:Douglas:0",
      "slot": 1,
      "doubles": false
    },
    "Tamer Vincent [Slot 2]": {
      "level": 35,
      "ability": "Technician",
      "moves": [
        "Body Slam",
        "Dual Wingbeat",
        "Leaf Blade",
        "Sand Attack"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 126,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FARFETCHD:0",
      "originalSpeciesKey": "FARFETCHD:0",
      "trainerId": "TAMER:Vincent:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Stunfisk": {
    "Pokemonranger M Douglas [Slot 2]": {
      "level": 22,
      "ability": "Static",
      "moves": [
        "Mud Shot",
        "Electroweb",
        "Muddy Water",
        "Sucker Punch"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 69,
      "gender": "M",
      "shiny": false,
      "speciesKey": "STUNFISK:0",
      "originalSpeciesKey": "STUNFISK:0",
      "trainerId": "POKEMONRANGER_M:Douglas:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Nuzleaf": {
    "Pokemonranger M Douglas [Slot 3]": {
      "level": 22,
      "ability": "Pickpocket",
      "moves": [
        "Bullet Seed",
        "Foul Play",
        "Brick Break",
        "Substitute"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 69,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NUZLEAF:0",
      "originalSpeciesKey": "NUZLEAF:0",
      "trainerId": "POKEMONRANGER_M:Douglas:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Dratini": {
    "Youngster Rex [Slot 1]": {
      "level": 23,
      "ability": "Shed Skin",
      "moves": [
        "Wrap",
        "Water Pulse",
        "Breaking Swipe",
        "Safeguard"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 70,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRATINI:0",
      "originalSpeciesKey": "DRATINI:0",
      "trainerId": "YOUNGSTER:Rex:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Bagon": {
    "Youngster Rex [Slot 2]": {
      "level": 23,
      "ability": "Rock Head",
      "moves": [
        "Headbutt",
        "Scary Face",
        "Fire Fang",
        "Crunch"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 70,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BAGON:0",
      "originalSpeciesKey": "BAGON:0",
      "trainerId": "YOUNGSTER:Rex:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Tinkatink": {
    "Camper Matti [Slot 2]": {
      "level": 23,
      "ability": "Mold Breaker",
      "moves": [
        "Metal Claw",
        "Covet",
        "Rock Smash",
        "Smack Down"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 71,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TINKATINK:0",
      "originalSpeciesKey": "TINKATINK:0",
      "trainerId": "CAMPER:Matti:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Mr. Mime": {
    "Lass Aurelia [Slot 1]": {
      "level": 22,
      "ability": "Filter",
      "moves": [
        "Psybeam",
        "Dazzling Gleam",
        "Grass Knot",
        "Charm"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 72,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MRMIME:0",
      "originalSpeciesKey": "MRMIME:0",
      "trainerId": "LASS:Aurelia:0",
      "slot": 1,
      "doubles": false
    },
    "Juggler Blake [Slot 2]": {
      "level": 30,
      "ability": "Technician",
      "moves": [
        "Fake Out",
        "Psybeam",
        "Magical Leaf",
        "Copycat"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 95,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MRMIME:0",
      "originalSpeciesKey": "MRMIME:0",
      "trainerId": "JUGGLER:Blake:0",
      "slot": 2,
      "doubles": false
    },
    "Ace Trainer Niel (DOUBLES) [Slot 4]": {
      "level": 79,
      "ability": "Filter",
      "moves": [
        "Psychic",
        "Dazzling Gleam",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 289,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MRMIME:0",
      "originalSpeciesKey": "MRMIME:0",
      "trainerId": "COOLTRAINER_M:Niel:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Elekid": {
    "Pokemonbreeder Beatrix [Slot 1]": {
      "level": 22,
      "ability": "Static",
      "moves": [
        "Shock Wave",
        "Trailblaze",
        "Fire Punch",
        "Light Screen"
      ],
      "nature": "Mild",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 73,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ELEKID:0",
      "originalSpeciesKey": "ELEKID:0",
      "trainerId": "POKEMONBREEDER:Beatrix:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Happiny": {
    "Pokemonbreeder Beatrix [Slot 3]": {
      "level": 23,
      "ability": "Serene Grace",
      "moves": [
        "Metronome",
        "Covet",
        "Thunder Wave"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 73,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HAPPINY:0",
      "originalSpeciesKey": "HAPPINY:0",
      "trainerId": "POKEMONBREEDER:Beatrix:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Qwilfish": {
    "Sailor Ernest [Slot 1]": {
      "level": 23,
      "ability": "Poison Point",
      "moves": [
        "Toxic Spikes",
        "Poison Jab",
        "Aqua Tail"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 74,
      "gender": "F",
      "shiny": false,
      "speciesKey": "QWILFISH:0",
      "originalSpeciesKey": "QWILFISH:0",
      "trainerId": "SAILOR:Ernest:0",
      "slot": 1,
      "doubles": false
    },
    "Juggler Shawn [Slot 2]": {
      "level": 37,
      "ability": "Intimidate",
      "moves": [
        "Waterfall",
        "Poison Tail",
        "Payback",
        "Toxic"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 138,
      "gender": "M",
      "shiny": false,
      "speciesKey": "QWILFISH:0",
      "originalSpeciesKey": "QWILFISH:0",
      "trainerId": "JUGGLER:Shawn:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Carvanha": {
    "Sailor Ernest [Slot 4]": {
      "level": 25,
      "ability": "Rough Skin",
      "moves": [
        "Aqua Jet",
        "Waterfall",
        "Crunch",
        "Focus Energy"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 74,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CARVANHA:0",
      "originalSpeciesKey": "CARVANHA:0",
      "trainerId": "SAILOR:Ernest:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Tirtouga": {
    "Sailor Eugene [Slot 1]": {
      "level": 23,
      "ability": "Sturdy",
      "moves": [
        "Aqua Jet",
        "Rock Slide",
        "Zen Headbutt",
        "Rain Dance"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 75,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TIRTOUGA:0",
      "originalSpeciesKey": "TIRTOUGA:0",
      "trainerId": "SAILOR:Eugene:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Dewpider": {
    "Sailor Eugene [Slot 2]": {
      "level": 24,
      "ability": "Water Bubble",
      "moves": [
        "Bubble Beam",
        "Bug Buzz",
        "Giga Drain",
        "Aqua Ring"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 75,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DEWPIDER:0",
      "originalSpeciesKey": "DEWPIDER:0",
      "trainerId": "SAILOR:Eugene:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Mienfoo": {
    "Sailor Eugene [Slot 3]": {
      "level": 25,
      "ability": "Inner Focus",
      "moves": [
        "Force Palm",
        "Poison Jab",
        "Aerial Ace",
        "U-turn"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 75,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MIENFOO:0",
      "originalSpeciesKey": "MIENFOO:0",
      "trainerId": "SAILOR:Eugene:0",
      "slot": 3,
      "doubles": false
    },
    "Blackbelt Ryuu [Slot 1]": {
      "level": 33,
      "ability": "Regenerator",
      "moves": [
        "Vacuum Wave",
        "Aura Sphere",
        "Dual Chop",
        "U-turn"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 115,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MIENFOO:0",
      "originalSpeciesKey": "MIENFOO:0",
      "trainerId": "BLACKBELT:Ryuu:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Smeargle": {
    "Painter Celina [Slot 1]": {
      "level": 23,
      "ability": "Own Tempo",
      "moves": [
        "Ceaseless Edge",
        "Spore"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 76,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SMEARGLE:0",
      "originalSpeciesKey": "SMEARGLE:0",
      "trainerId": "PAINTER:Celina:0",
      "slot": 1,
      "doubles": false
    },
    "Painter Celina [Slot 2]": {
      "level": 24,
      "ability": "Own Tempo",
      "moves": [
        "Sucker Punch",
        "Tail Slap",
        "Spore"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 76,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SMEARGLE:0",
      "originalSpeciesKey": "SMEARGLE:0",
      "trainerId": "PAINTER:Celina:0",
      "slot": 2,
      "doubles": false
    },
    "Painter Celina [Slot 3]": {
      "level": 25,
      "ability": "Own Tempo",
      "moves": [
        "Substitute",
        "Leech Seed",
        "Protect",
        "Encore"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 76,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SMEARGLE:0",
      "originalSpeciesKey": "SMEARGLE:0",
      "trainerId": "PAINTER:Celina:0",
      "slot": 3,
      "doubles": false
    },
    "Ace Trainer Rolan (DOUBLES) [Slot 3]": {
      "level": 80,
      "ability": "Moody",
      "moves": [
        "Psywave",
        "Dark Void",
        "Protect"
      ],
      "nature": "Jolly",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 285,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SMEARGLE:0",
      "originalSpeciesKey": "SMEARGLE:0",
      "trainerId": "COOLTRAINER_M:Rolan:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Ponyta [Galarian]": {
    "Picnicker Heidi [Slot 1]": {
      "level": 23,
      "ability": "Pastel Veil",
      "moves": [
        "Psybeam",
        "Dazzling Gleam",
        "Mystical Fire",
        "Protect"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 77,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PONYTA:1",
      "originalSpeciesKey": "PONYTA:1",
      "trainerId": "PICNICKER:Heidi:0",
      "slot": 1,
      "doubles": false
    },
    "Pokemonranger F Kara [Slot 2]": {
      "level": 35,
      "ability": "Pastel Veil",
      "moves": [
        "Zen Headbutt",
        "Dazzling Gleam",
        "Mystical Fire",
        "Charm"
      ],
      "nature": "Mild",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 122,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PONYTA:1",
      "originalSpeciesKey": "PONYTA:1",
      "trainerId": "POKEMONRANGER_F:Kara:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Togetic": {
    "Picnicker Heidi [Slot 2]": {
      "level": 24,
      "ability": "Serene Grace",
      "moves": [
        "Draining Kiss",
        "Air Slash",
        "Psychic",
        "Flamethrower"
      ],
      "nature": "Lonely",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 77,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOGETIC:0",
      "originalSpeciesKey": "TOGETIC:0",
      "trainerId": "PICNICKER:Heidi:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Flapple": {
    "Picnicker Heidi [Slot 3]": {
      "level": 25,
      "ability": "Gluttony",
      "moves": [
        "Giga Drain",
        "Dragon Breath",
        "Acid Spray",
        "Leech Seed"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 77,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FLAPPLE:0",
      "originalSpeciesKey": "FLAPPLE:0",
      "trainerId": "PICNICKER:Heidi:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic M Grunt #8 [Slot 3]": {
      "level": 50,
      "ability": "Ripen",
      "moves": [
        "Grav Apple",
        "Dragon Rush",
        "Dual Wingbeat",
        "Recycle"
      ],
      "nature": "Jolly",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 205,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FLAPPLE:0",
      "originalSpeciesKey": "FLAPPLE:0",
      "trainerId": "GALACTIC_M:Grunt:7",
      "slot": 3,
      "doubles": false
    }
  },
  "Grimer": {
    "Biker Zeke [Slot 1]": {
      "level": 24,
      "ability": "Poison Touch",
      "moves": [
        "Sludge",
        "Mud Shot",
        "Hex",
        "Toxic"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 78,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRIMER:0",
      "originalSpeciesKey": "GRIMER:0",
      "trainerId": "BIKER:Zeke:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Minun": {
    "Biker Zeke [Slot 2]": {
      "level": 25,
      "ability": "Static",
      "moves": [
        "Electro Ball",
        "Alluring Voice",
        "Grass Knot",
        "Nuzzle"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 78,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MINUN:0",
      "originalSpeciesKey": "MINUN:0",
      "trainerId": "BIKER:Zeke:0",
      "slot": 2,
      "doubles": false
    },
    "Picnicker Hailey [Slot 1]": {
      "level": 46,
      "ability": "Static",
      "moves": [
        "Nuzzle",
        "Thunderbolt",
        "Signal Beam",
        "Encore"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 168,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MINUN:0",
      "originalSpeciesKey": "MINUN:0",
      "trainerId": "PICNICKER:Hailey:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Varoom": {
    "Biker Zeke [Slot 4]": {
      "level": 26,
      "ability": "Filter",
      "moves": [
        "Iron Head",
        "Toxic",
        "Substitute",
        "Protect"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 78,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VAROOM:0",
      "originalSpeciesKey": "VAROOM:0",
      "trainerId": "BIKER:Zeke:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Pelipper": {
    "Sailor Max [Slot 1]": {
      "level": 26,
      "ability": "Keen Eye",
      "moves": [
        "Air Cutter",
        "Brine",
        "Icy Wind",
        "Roost"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 79,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PELIPPER:0",
      "originalSpeciesKey": "PELIPPER:0",
      "trainerId": "SAILOR:Max:0",
      "slot": 1,
      "doubles": false
    },
    "Birdkeeper Burak [Slot 2]": {
      "level": 49,
      "ability": "Hydration",
      "moves": [
        "Muddy Water",
        "Hurricane",
        "Ice Beam"
      ],
      "nature": "Timid",
      "item": "Wacan Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 184,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PELIPPER:0",
      "originalSpeciesKey": "PELIPPER:0",
      "trainerId": "BIRDKEEPER:Burak:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Emolga": {
    "Sailor Max [Slot 2]": {
      "level": 27,
      "ability": "Lightning Rod",
      "moves": [
        "Quick Attack",
        "Electro Ball",
        "Air Cutter",
        "Encore"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 79,
      "gender": "F",
      "shiny": false,
      "speciesKey": "EMOLGA:0",
      "originalSpeciesKey": "EMOLGA:0",
      "trainerId": "SAILOR:Max:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Oricorio [Pom-Pom Style]": {
    "Sailor Max [Slot 3]": {
      "level": 28,
      "ability": "Dancer",
      "moves": [
        "Air Cutter",
        "Alluring Voice",
        "Teeter Dance"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 79,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORICORIO:1",
      "originalSpeciesKey": "ORICORIO:1",
      "trainerId": "SAILOR:Max:0",
      "slot": 3,
      "doubles": false
    },
    "Aromalady Swaylie [Slot 3]": {
      "level": 14,
      "ability": "Dancer",
      "moves": [
        "Thunder Shock"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 88,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORICORIO:1",
      "originalSpeciesKey": "ORICORIO:1",
      "trainerId": "AROMALADY:Swaylie:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Pachirisu": {
    "Rocker Ricky [Slot 1]": {
      "level": 26,
      "ability": "Prankster",
      "moves": [
        "Nuzzle",
        "Super Fang",
        "Grass Knot",
        "Light Screen"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 80,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PACHIRISU:0",
      "originalSpeciesKey": "PACHIRISU:0",
      "trainerId": "ROCKER:Ricky:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Bellibolt": {
    "Rocker Ricky [Slot 2]": {
      "level": 27,
      "ability": "Electromorphosis",
      "moves": [
        "Wild Charge",
        "Muddy Water",
        "Reflect"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 80,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BELLIBOLT:0",
      "originalSpeciesKey": "BELLIBOLT:0",
      "trainerId": "ROCKER:Ricky:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Graveler [Alolan]": {
    "Rocker Ricky [Slot 3]": {
      "level": 27,
      "ability": "Magnet Pull",
      "moves": [
        "Rock Tomb",
        "Thunder Punch",
        "Bulldoze"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 80,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRAVELER:1",
      "originalSpeciesKey": "GRAVELER:1",
      "trainerId": "ROCKER:Ricky:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Helioptile": {
    "Rocker Ricky [Slot 4]": {
      "level": 28,
      "ability": "Dry Skin",
      "moves": [
        "Parabolic Charge",
        "Grass Knot",
        "Thunder Wave",
        "Attract"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 80,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HELIOPTILE:0",
      "originalSpeciesKey": "HELIOPTILE:0",
      "trainerId": "ROCKER:Ricky:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Dedenne": {
    "Gentleman Olaf [Slot 1]": {
      "level": 27,
      "ability": "Cheek Pouch",
      "moves": [
        "Parabolic Charge",
        "Dazzling Gleam",
        "Thief",
        "Charm"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 81,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DEDENNE:0",
      "originalSpeciesKey": "DEDENNE:0",
      "trainerId": "GENTLEMAN:Olaf:0",
      "slot": 1,
      "doubles": false
    },
    "Youngster Adam [Slot 1]": {
      "level": 47,
      "ability": "Volt Absorb",
      "moves": [
        "Thunderbolt",
        "Dazzling Gleam",
        "Super Fang",
        "Electric Terrain"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 198,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DEDENNE:0",
      "originalSpeciesKey": "DEDENNE:0",
      "trainerId": "YOUNGSTER:Adam:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Morpeko": {
    "Gentleman Olaf [Slot 2]": {
      "level": 27,
      "ability": "Hunger Switch",
      "moves": [
        "Thunder Fang",
        "Crunch",
        "Psychic Fangs"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 81,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MORPEKO:0",
      "originalSpeciesKey": "MORPEKO:0",
      "trainerId": "GENTLEMAN:Olaf:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #14 [Slot 1]": {
      "level": 72,
      "ability": "Hunger Switch",
      "moves": [
        "Aura Wheel",
        "Seed Bomb",
        "Stomping Tantrum",
        "Super Fang"
      ],
      "nature": "Jolly",
      "item": "Shuca Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 274,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MORPEKO:0",
      "originalSpeciesKey": "MORPEKO:0",
      "trainerId": "GALACTIC_M:Grunt:13",
      "slot": 1,
      "doubles": false
    }
  },
  "Pincurchin": {
    "Gym Leader Surge #1 [Slot 1]": {
      "level": 29,
      "ability": "Electric Surge",
      "moves": [
        "Discharge",
        "Liquidation",
        "Pain Split",
        "Toxic Spikes"
      ],
      "nature": "Relaxed",
      "item": "Terrain Extender",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 82,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PINCURCHIN:0",
      "originalSpeciesKey": "PINCURCHIN:0",
      "trainerId": "LEADER_Surge:Surge:0",
      "slot": 1,
      "doubles": false
    },
    "Gym Leader Surge #2 (DOUBLES) [Slot 1]": {
      "level": 29,
      "ability": "Electric Surge",
      "moves": [
        "Discharge",
        "Liquidation",
        "Pain Split",
        "Toxic Spikes"
      ],
      "nature": "Relaxed",
      "item": "Terrain Extender",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 83,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PINCURCHIN:0",
      "originalSpeciesKey": "PINCURCHIN:0",
      "trainerId": "LEADER_Surge:Surge:1",
      "slot": 1,
      "doubles": true
    },
    "Haramsu Haramsu [Slot 1]": {
      "level": 42,
      "ability": "Electric Surge",
      "moves": [
        "Spikes",
        "Rising Voltage",
        "Hydro Pump",
        "Self-Destruct"
      ],
      "nature": "Quiet",
      "item": "Terrain Extender",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 152,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PINCURCHIN:0",
      "originalSpeciesKey": "PINCURCHIN:0",
      "trainerId": "HARAMSU:Haramsu:0",
      "slot": 1,
      "doubles": false
    },
    "Pokemonranger M Auron [Slot 1]": {
      "level": 95,
      "ability": "Electric Surge",
      "moves": [
        "Zing Zap",
        "Liquidation",
        "Throat Chop",
        "Reversal"
      ],
      "nature": "Relaxed",
      "item": "Terrain Extender",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 308,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PINCURCHIN:0",
      "originalSpeciesKey": "PINCURCHIN:0",
      "trainerId": "POKEMONRANGER_M:Auron:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Lanturn": {
    "Gym Leader Surge #1 [Slot 2]": {
      "level": 29,
      "ability": "Volt Absorb",
      "moves": [
        "Scald",
        "Electro Ball",
        "Agility"
      ],
      "nature": "Modest",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 82,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LANTURN:0",
      "originalSpeciesKey": "LANTURN:0",
      "trainerId": "LEADER_Surge:Surge:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Surge #2 (DOUBLES) [Slot 2]": {
      "level": 29,
      "ability": "Volt Absorb",
      "moves": [
        "Scald",
        "Electro Ball",
        "Agility"
      ],
      "nature": "Modest",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 83,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LANTURN:0",
      "originalSpeciesKey": "LANTURN:0",
      "trainerId": "LEADER_Surge:Surge:1",
      "slot": 2,
      "doubles": true
    },
    "Cooltrainer M Chad [Slot 2]": {
      "level": 35,
      "ability": "Volt Absorb",
      "moves": [
        "Bubble Beam",
        "Discharge",
        "Signal Beam",
        "Agility"
      ],
      "nature": "Modest",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 107,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LANTURN:0",
      "originalSpeciesKey": "LANTURN:0",
      "trainerId": "COOLTRAINER_M:Chad:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Cramorant": {
    "Gym Leader Surge #1 [Slot 3]": {
      "level": 29,
      "ability": "Gulp Missile",
      "moves": [
        "Drill Peck",
        "Surf",
        "Whirlpool",
        "Belch"
      ],
      "nature": "Hasty",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 82,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CRAMORANT:0",
      "originalSpeciesKey": "CRAMORANT:0",
      "trainerId": "LEADER_Surge:Surge:0",
      "slot": 3,
      "doubles": false
    },
    "Gym Leader Surge #2 (DOUBLES) [Slot 3]": {
      "level": 29,
      "ability": "Gulp Missile",
      "moves": [
        "Drill Peck",
        "Surf",
        "Whirlpool",
        "Belch"
      ],
      "nature": "Hasty",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 83,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CRAMORANT:0",
      "originalSpeciesKey": "CRAMORANT:0",
      "trainerId": "LEADER_Surge:Surge:1",
      "slot": 3,
      "doubles": true
    },
    "Biker Axel [Slot 2]": {
      "level": 34,
      "ability": "Gulp Missile",
      "moves": [
        "Wing Attack",
        "Air Cutter",
        "Whirlpool",
        "Thrash"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 108,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CRAMORANT:0",
      "originalSpeciesKey": "CRAMORANT:0",
      "trainerId": "BIKER:Axel:0",
      "slot": 2,
      "doubles": false
    },
    "Birdkeeper Burak [Slot 1]": {
      "level": 48,
      "ability": "Gulp Missile",
      "moves": [
        "Acrobatics",
        "Liquidation",
        "Throat Chop",
        "Roost"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 184,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CRAMORANT:0",
      "originalSpeciesKey": "CRAMORANT:0",
      "trainerId": "BIRDKEEPER:Burak:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Rotom [Fan Rotom]": {
    "Gym Leader Surge #1 [Slot 4]": {
      "level": 29,
      "ability": "Motor Drive",
      "moves": [
        "Discharge",
        "Air Slash",
        "Hex",
        "Will-O-Wisp"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 82,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROTOM:4",
      "originalSpeciesKey": "ROTOM:4",
      "trainerId": "LEADER_Surge:Surge:0",
      "slot": 4,
      "doubles": false
    },
    "Gym Leader Surge #2 (DOUBLES) [Slot 4]": {
      "level": 29,
      "ability": "Speed Boost",
      "moves": [
        "Electro Ball",
        "Air Slash",
        "Hex",
        "Will-O-Wisp"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 83,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROTOM:4",
      "originalSpeciesKey": "ROTOM:4",
      "trainerId": "LEADER_Surge:Surge:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Manectric": {
    "Gym Leader Surge #1 [Slot 5]": {
      "level": 30,
      "ability": "Intimidate",
      "moves": [
        "Wild Charge",
        "Ice Fang",
        "Flamethrower",
        "Howl"
      ],
      "nature": "Serious",
      "item": "Shuca Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 82,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MANECTRIC:0",
      "originalSpeciesKey": "MANECTRIC:0",
      "trainerId": "LEADER_Surge:Surge:0",
      "slot": 5,
      "doubles": false
    },
    "Gym Leader Surge #2 (DOUBLES) [Slot 5]": {
      "level": 30,
      "ability": "Intimidate",
      "moves": [
        "Wild Charge",
        "Ice Fang",
        "Flamethrower",
        "Howl"
      ],
      "nature": "Serious",
      "item": "Shuca Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 83,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MANECTRIC:0",
      "originalSpeciesKey": "MANECTRIC:0",
      "trainerId": "LEADER_Surge:Surge:1",
      "slot": 5,
      "doubles": true
    },
    "Galactic F Grunt #4 [Slot 1]": {
      "level": 72,
      "ability": "Static",
      "moves": [
        "Thunderbolt",
        "Flamethrower",
        "Ice Fang",
        "Crunch"
      ],
      "nature": "Naive",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 276,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MANECTRIC:0",
      "originalSpeciesKey": "MANECTRIC:0",
      "trainerId": "GALACTIC_F:Grunt:15",
      "slot": 1,
      "doubles": false
    }
  },
  "Combusken": {
    "Casual Casual [Slot 1]": {
      "level": 28,
      "ability": "Speed Boost",
      "moves": [
        "Fire Punch",
        "Brick Break",
        "Thunder Punch",
        "Bulk Up"
      ],
      "nature": "Adamant",
      "item": "Chesto Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 84,
      "gender": "M",
      "shiny": false,
      "speciesKey": "COMBUSKEN:0",
      "originalSpeciesKey": "COMBUSKEN:0",
      "trainerId": "CASUAL:Casual:0",
      "slot": 1,
      "doubles": false
    },
    "Blackbelt Daisuke [Slot 1]": {
      "level": 33,
      "ability": "Speed Boost",
      "moves": [
        "Quick Attack",
        "Flamethrower",
        "Sky Uppercut",
        "Protect"
      ],
      "nature": "Hardy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 117,
      "gender": "M",
      "shiny": false,
      "speciesKey": "COMBUSKEN:0",
      "originalSpeciesKey": "COMBUSKEN:0",
      "trainerId": "BLACKBELT:Daisuke:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Klink": {
    "Casual Casual [Slot 2]": {
      "level": 28,
      "ability": "Clear Body",
      "moves": [
        "Gear Grind",
        "Wild Charge",
        "Shift Gear",
        "Screech"
      ],
      "nature": "Relaxed",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 84,
      "gender": "",
      "shiny": false,
      "speciesKey": "KLINK:0",
      "originalSpeciesKey": "KLINK:0",
      "trainerId": "CASUAL:Casual:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Servine": {
    "Casual Casual [Slot 3]": {
      "level": 28,
      "ability": "Contrary",
      "moves": [
        "Giga Drain",
        "Aerial Ace",
        "Knock Off",
        "Glare"
      ],
      "nature": "Timid",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 84,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SERVINE:0",
      "originalSpeciesKey": "SERVINE:0",
      "trainerId": "CASUAL:Casual:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Masquerain": {
    "Casual Casual [Slot 4]": {
      "level": 28,
      "ability": "Intimidate",
      "moves": [
        "Silver Wind",
        "Air Cutter",
        "Scald",
        "Roost"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 84,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MASQUERAIN:0",
      "originalSpeciesKey": "MASQUERAIN:0",
      "trainerId": "CASUAL:Casual:0",
      "slot": 4,
      "doubles": false
    },
    "Galactic M Grunt #10 [Slot 1]": {
      "level": 48,
      "ability": "Intimidate",
      "moves": [
        "Bug Buzz",
        "Air Slash",
        "Scald",
        "Stun Spore"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 207,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MASQUERAIN:0",
      "originalSpeciesKey": "MASQUERAIN:0",
      "trainerId": "GALACTIC_M:Grunt:9",
      "slot": 1,
      "doubles": false
    },
    "Toni Toni [Slot 1]": {
      "level": 68,
      "ability": "Intimidate",
      "moves": [
        "Bug Buzz",
        "Hydro Pump",
        "Sticky Web"
      ],
      "nature": "Timid",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 245,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MASQUERAIN:0",
      "originalSpeciesKey": "MASQUERAIN:0",
      "trainerId": "TONI:Toni:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Azumarill": {
    "Casual Casual [Slot 5]": {
      "level": 29,
      "ability": "Thick Fat",
      "moves": [
        "Aqua Jet",
        "Liquidation",
        "Play Rough"
      ],
      "nature": "Adamant",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 84,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AZUMARILL:0",
      "originalSpeciesKey": "AZUMARILL:0",
      "trainerId": "CASUAL:Casual:0",
      "slot": 5,
      "doubles": false
    },
    "Galactic F Grunt #6 [Slot 2]": {
      "level": 74,
      "ability": "Huge Power",
      "moves": [
        "Aqua Jet",
        "Aqua Tail",
        "Play Rough",
        "Ice Punch"
      ],
      "nature": "Jolly",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 282,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AZUMARILL:0",
      "originalSpeciesKey": "AZUMARILL:0",
      "trainerId": "GALACTIC_F:Grunt:21",
      "slot": 2,
      "doubles": false
    },
    "Ace Trainer Nikola (DOUBLES) [Slot 3]": {
      "level": 79,
      "ability": "Huge Power",
      "moves": [
        "Aqua Jet",
        "Waterfall",
        "Play Rough",
        "Belly Drum"
      ],
      "nature": "Adamant",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 288,
      "gender": "F",
      "shiny": false,
      "speciesKey": "AZUMARILL:0",
      "originalSpeciesKey": "AZUMARILL:0",
      "trainerId": "COOLTRAINER_F:Nikola:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Sableye": {
    "Channeler Ruth [Slot 1]": {
      "level": 40,
      "ability": "Magic Guard",
      "moves": [
        "Foul Play",
        "Night Shade",
        "Will-O-Wisp",
        "Recover"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 146,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SABLEYE:0",
      "originalSpeciesKey": "SABLEYE:0",
      "trainerId": "CHANNELER:Ruth:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Tyranitar": {},
  "Shedinja": {},
  "Urshifu": {},
  "Oricorio": {
    "Aromalady Swaylie [Slot 1]": {
      "level": 65,
      "ability": "Dancer",
      "moves": [
        "Revelation Dance",
        "Quiver Dance"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 88,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORICORIO:0",
      "originalSpeciesKey": "ORICORIO:0",
      "trainerId": "AROMALADY:Swaylie:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Oricorio [Sensu Style]": {
    "Aromalady Swaylie [Slot 2]": {
      "level": 100,
      "ability": "Dancer",
      "moves": [
        "Revelation Dance"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 88,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORICORIO:3",
      "originalSpeciesKey": "ORICORIO:3",
      "trainerId": "AROMALADY:Swaylie:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #16 [Slot 1]": {
      "level": 72,
      "ability": "Dancer",
      "moves": [
        "Revelation Dance",
        "Air Slash",
        "Teeter Dance",
        "Calm Mind"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 277,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORICORIO:3",
      "originalSpeciesKey": "ORICORIO:3",
      "trainerId": "GALACTIC_M:Grunt:16",
      "slot": 1,
      "doubles": false
    }
  },
  "Pangoro": {
    "Blackbelt Pat [Slot 1]": {
      "level": 32,
      "ability": "Scrappy",
      "moves": [
        "Darkest Lariat",
        "Bullet Punch"
      ],
      "nature": "Careful",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 0,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 89,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PANGORO:0",
      "originalSpeciesKey": "PANGORO:0",
      "trainerId": "BLACKBELT:Pat:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Hitmonlee": {
    "Blackbelt Pat [Slot 2]": {
      "level": 58,
      "ability": "Limber",
      "moves": [
        "High Jump Kick"
      ],
      "nature": "Adamant",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 89,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HITMONLEE:0",
      "originalSpeciesKey": "HITMONLEE:0",
      "trainerId": "BLACKBELT:Pat:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Sandslash [Alolan]": {
    "Burglar Ghost [Slot 1]": {
      "level": 36,
      "ability": "Slush Rush",
      "moves": [
        "Iron Head",
        "Night Slash"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 90,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SANDSLASH:1",
      "originalSpeciesKey": "SANDSLASH:1",
      "trainerId": "BURGLAR:Ghost:0",
      "slot": 1,
      "doubles": false
    },
    "Pokemaniac Lowell [Slot 2]": {
      "level": 47,
      "ability": "Slush Rush",
      "moves": [
        "Ice Shard",
        "Icicle Crash",
        "Iron Head",
        "Earthquake"
      ],
      "nature": "Jolly",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 167,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SANDSLASH:1",
      "originalSpeciesKey": "SANDSLASH:1",
      "trainerId": "POKEMANIAC:Lowell:0",
      "slot": 2,
      "doubles": false
    },
    "Gentleman Heath [Slot 2]": {
      "level": 67,
      "ability": "Slush Rush",
      "moves": [
        "Triple Axel",
        "Iron Head",
        "Earthquake",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 257,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SANDSLASH:1",
      "originalSpeciesKey": "SANDSLASH:1",
      "trainerId": "GENTLEMAN:Heath:0",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Lorelei #1 [Slot 2]": {
      "level": 99,
      "ability": "Slush Rush",
      "moves": [
        "Icicle Crash",
        "Iron Head",
        "Earthquake",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 310,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SANDSLASH:1",
      "originalSpeciesKey": "SANDSLASH:1",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:0",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Lorelei #2 (DOUBLES) [Slot 3]": {
      "level": 99,
      "ability": "Slush Rush",
      "moves": [
        "Icicle Crash",
        "Iron Head",
        "Stomping Tantrum",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 311,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SANDSLASH:1",
      "originalSpeciesKey": "SANDSLASH:1",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:1",
      "slot": 3,
      "doubles": true
    }
  },
  "Snorlax": {
    "Burglar Ghost [Slot 2]": {
      "level": 45,
      "ability": "Gluttony",
      "moves": [
        "Body Slam",
        "Bite",
        "Curse"
      ],
      "nature": "Quiet",
      "item": "Liechi Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 90,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SNORLAX:0",
      "originalSpeciesKey": "SNORLAX:0",
      "trainerId": "BURGLAR:Ghost:0",
      "slot": 2,
      "doubles": false
    },
    "Hiker Walts [Slot 3]": {
      "level": 49,
      "ability": "Gluttony",
      "moves": [
        "Body Slam",
        "Earthquake",
        "Sleep Talk",
        "Rest"
      ],
      "nature": "Impish",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 192,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SNORLAX:0",
      "originalSpeciesKey": "SNORLAX:0",
      "trainerId": "HIKER:Walts:0",
      "slot": 3,
      "doubles": false
    },
    "Ruinmaniac Vince [Slot 1]": {
      "level": 65,
      "ability": "Immunity",
      "moves": [
        "Body Slam",
        "Earthquake",
        "Heat Crash",
        "Curse"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 241,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SNORLAX:0",
      "originalSpeciesKey": "SNORLAX:0",
      "trainerId": "RUINMANIAC:Vince:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Tavarius (DOUBLES) [Slot 3]": {
      "level": 79,
      "ability": "Gluttony",
      "moves": [
        "Body Slam",
        "High Horsepower",
        "Crunch",
        "Recycle"
      ],
      "nature": "Impish",
      "item": "Starf Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 286,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SNORLAX:0",
      "originalSpeciesKey": "SNORLAX:0",
      "trainerId": "COOLTRAINER_M:Tavarius:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Kingler": {
    "Lass Maggie [Slot 2]": {
      "level": 32,
      "ability": "Hyper Cutter",
      "moves": [
        "Brick Break",
        "Protect",
        "Slash",
        "Night Slash"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 91,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KINGLER:0",
      "originalSpeciesKey": "KINGLER:0",
      "trainerId": "LASS:Maggie:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #14 [Slot 3]": {
      "level": 73,
      "ability": "Hyper Cutter",
      "moves": [
        "Crabhammer",
        "High Horsepower",
        "X-Scissor",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 274,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KINGLER:0",
      "originalSpeciesKey": "KINGLER:0",
      "trainerId": "GALACTIC_M:Grunt:13",
      "slot": 3,
      "doubles": false
    }
  },
  "Loudred": {
    "Lass Maggie [Slot 3]": {
      "level": 33,
      "ability": "Soundproof",
      "moves": [
        "Fire Punch",
        "Thunder Punch",
        "Ice Punch",
        "Take Down"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 91,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LOUDRED:0",
      "originalSpeciesKey": "LOUDRED:0",
      "trainerId": "LASS:Maggie:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Machoke": {
    "Crushgirl Mel [Slot 2]": {
      "level": 32,
      "ability": "Guts",
      "moves": [
        "Thunder Punch",
        "Fire Punch",
        "Rock Tomb",
        "Scary Face"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 92,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MACHOKE:0",
      "originalSpeciesKey": "MACHOKE:0",
      "trainerId": "CRUSHGIRL:Mel:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Gurdurr": {
    "Crushgirl Mel [Slot 3]": {
      "level": 33,
      "ability": "Guts",
      "moves": [
        "Wake-Up Slap",
        "Chip Away",
        "Payback",
        "Rock Slide"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 92,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GURDURR:0",
      "originalSpeciesKey": "GURDURR:0",
      "trainerId": "CRUSHGIRL:Mel:0",
      "slot": 3,
      "doubles": false
    },
    "Blackbelt Ryuu [Slot 2]": {
      "level": 34,
      "ability": "Iron Fist",
      "moves": [
        "Mach Punch",
        "Drain Punch",
        "Thunder Punch",
        "Ice Punch"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 115,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GURDURR:0",
      "originalSpeciesKey": "GURDURR:0",
      "trainerId": "BLACKBELT:Ryuu:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Golett": {
    "Hiker Jerry [Slot 2]": {
      "level": 32,
      "ability": "Iron Fist",
      "moves": [
        "Night Shade",
        "Bulldoze",
        "Shadow Punch",
        "Mega Punch"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 93,
      "gender": "",
      "shiny": false,
      "speciesKey": "GOLETT:0",
      "originalSpeciesKey": "GOLETT:0",
      "trainerId": "HIKER:Jerry:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Pignite": {
    "Hiker Jerry [Slot 3]": {
      "level": 33,
      "ability": "Blaze",
      "moves": [
        "Submission",
        "Flame Charge",
        "Heavy Slam",
        "Heat Crash"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 93,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PIGNITE:0",
      "originalSpeciesKey": "PIGNITE:0",
      "trainerId": "HIKER:Jerry:0",
      "slot": 3,
      "doubles": false
    },
    "Blackbelt Daisuke [Slot 3]": {
      "level": 35,
      "ability": "Blaze",
      "moves": [
        "Flame Charge",
        "Jump Kick",
        "Stomping Tantrum",
        "Bulk Up"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 117,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PIGNITE:0",
      "originalSpeciesKey": "PIGNITE:0",
      "trainerId": "BLACKBELT:Daisuke:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Hakamo-o": {
    "Hiker Jerry [Slot 4]": {
      "level": 34,
      "ability": "Bulletproof",
      "moves": [
        "Dragon Tail",
        "Scary Face",
        "Counter",
        "Dragon Claw"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 93,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HAKAMOO:0",
      "originalSpeciesKey": "HAKAMOO:0",
      "trainerId": "HIKER:Jerry:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Xatu": {
    "Birdkeeper Allen [Slot 1]": {
      "level": 29,
      "ability": "Magic Bounce",
      "moves": [
        "Ominous Wind",
        "Dazzling Gleam",
        "Thunder Wave",
        "Reflect"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 94,
      "gender": "F",
      "shiny": false,
      "speciesKey": "XATU:0",
      "originalSpeciesKey": "XATU:0",
      "trainerId": "BIRDKEEPER:Allen:0",
      "slot": 1,
      "doubles": false
    },
    "Pokemonranger M Derek [Slot 1]": {
      "level": 58,
      "ability": "Magic Bounce",
      "moves": [
        "Extrasensory",
        "Drill Peck",
        "Heat Wave",
        "Light Screen"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 223,
      "gender": "F",
      "shiny": false,
      "speciesKey": "XATU:0",
      "originalSpeciesKey": "XATU:0",
      "trainerId": "POKEMONRANGER_M:Derek:0",
      "slot": 1,
      "doubles": false
    },
    "Ruinmaniac Harold [Slot 3]": {
      "level": 66,
      "ability": "Magic Bounce",
      "moves": [
        "Air Slash",
        "Confuse Ray",
        "Thunder Wave",
        "Substitute"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 242,
      "gender": "F",
      "shiny": false,
      "speciesKey": "XATU:0",
      "originalSpeciesKey": "XATU:0",
      "trainerId": "RUINMANIAC:Harold:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Flamigo": {
    "Birdkeeper Allen [Slot 2]": {
      "level": 30,
      "ability": "Tangled Feet",
      "moves": [
        "Dual Wingbeat",
        "Low Sweep",
        "Thief"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 94,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FLAMIGO:0",
      "originalSpeciesKey": "FLAMIGO:0",
      "trainerId": "BIRDKEEPER:Allen:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #6 [Slot 3]": {
      "level": 37,
      "ability": "Tangled Feet",
      "moves": [
        "Dual Wingbeat",
        "Reversal",
        "Pounce",
        "Roost"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 130,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FLAMIGO:0",
      "originalSpeciesKey": "FLAMIGO:0",
      "trainerId": "GALACTIC_M:Grunt:5",
      "slot": 3,
      "doubles": false
    }
  },
  "Hypno": {
    "Juggler Blake [Slot 3]": {
      "level": 31,
      "ability": "Insomnia",
      "moves": [
        "Psyshock",
        "Wake-Up Slap",
        "Hypnosis"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 95,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HYPNO:0",
      "originalSpeciesKey": "HYPNO:0",
      "trainerId": "JUGGLER:Blake:0",
      "slot": 3,
      "doubles": false
    },
    "Channeler Evelyn (DOUBLES) [Slot 2]": {
      "level": 40,
      "ability": "Inner Focus",
      "moves": [
        "Future Sight",
        "Dazzling Gleam",
        "Hypnosis",
        "Nightmare"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 150,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HYPNO:0",
      "originalSpeciesKey": "HYPNO:0",
      "trainerId": "CHANNELER:Evelyn:0",
      "slot": 2,
      "doubles": true
    },
    "Galactic M Grunt #19 (DOUBLES) [Slot 3]": {
      "level": 73,
      "ability": "Inner Focus",
      "moves": [
        "Psychic",
        "Dazzling Gleam",
        "Dark Void",
        "Calm Mind"
      ],
      "nature": "Bold",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 280,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HYPNO:0",
      "originalSpeciesKey": "HYPNO:0",
      "trainerId": "GALACTIC_M:Grunt:19",
      "slot": 3,
      "doubles": true
    }
  },
  "Slurpuff": {
    "Beauty April [Slot 2]": {
      "level": 30,
      "ability": "Sweet Veil",
      "moves": [
        "Draining Kiss",
        "Energy Ball",
        "Sticky Web",
        "Wish"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 96,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SLURPUFF:0",
      "originalSpeciesKey": "SLURPUFF:0",
      "trainerId": "BEAUTY:April:0",
      "slot": 2,
      "doubles": false
    },
    "Haramsu Haramsu [Slot 2]": {
      "level": 42,
      "ability": "Unburden",
      "moves": [
        "Dazzling Gleam",
        "Thunderbolt",
        "Sticky Web"
      ],
      "nature": "Timid",
      "item": "Electric Seed",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 152,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLURPUFF:0",
      "originalSpeciesKey": "SLURPUFF:0",
      "trainerId": "HARAMSU:Haramsu:0",
      "slot": 2,
      "doubles": false
    },
    "Pokemonbreeder Mariah [Slot 2]": {
      "level": 49,
      "ability": "Unburden",
      "moves": [
        "Hyper Voice",
        "Dazzling Gleam",
        "Endeavor",
        "Play Rough"
      ],
      "nature": "Naive",
      "item": "Salac Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 189,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLURPUFF:0",
      "originalSpeciesKey": "SLURPUFF:0",
      "trainerId": "POKEMONBREEDER:Mariah:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #15 [Slot 1]": {
      "level": 71,
      "ability": "Unburden",
      "moves": [
        "Sticky Web",
        "Dazzling Gleam",
        "Flamethrower",
        "Psychic"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 275,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLURPUFF:0",
      "originalSpeciesKey": "SLURPUFF:0",
      "trainerId": "GALACTIC_M:Grunt:14",
      "slot": 1,
      "doubles": false
    }
  },
  "Lopunny": {
    "Beauty April [Slot 3]": {
      "level": 31,
      "ability": "Cute Charm",
      "moves": [
        "Dizzy Punch",
        "Play Rough",
        "Charm"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 96,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LOPUNNY:0",
      "originalSpeciesKey": "LOPUNNY:0",
      "trainerId": "BEAUTY:April:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Eldegoss": {
    "Gentleman Brent [Slot 2]": {
      "level": 30,
      "ability": "Cotton Down",
      "moves": [
        "Leaf Tornado",
        "Hyper Voice",
        "Cotton Spore",
        "Synthesis"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 97,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ELDEGOSS:0",
      "originalSpeciesKey": "ELDEGOSS:0",
      "trainerId": "GENTLEMAN:Brent:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Dragonair": {
    "Gentleman Brent [Slot 3]": {
      "level": 31,
      "ability": "Shed Skin",
      "moves": [
        "Breaking Swipe",
        "Aqua Tail",
        "Rest"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 97,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAGONAIR:0",
      "originalSpeciesKey": "DRAGONAIR:0",
      "trainerId": "GENTLEMAN:Brent:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Hitmonchan": {
    "Blackbelt Ryan [Slot 1]": {
      "level": 30,
      "ability": "Inner Focus",
      "moves": [
        "Mach Punch",
        "Sky Uppercut",
        "Dizzy Punch"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 98,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HITMONCHAN:0",
      "originalSpeciesKey": "HITMONCHAN:0",
      "trainerId": "BLACKBELT:Ryan:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Granbull": {
    "Blackbelt Ryan [Slot 2]": {
      "level": 31,
      "ability": "Intimidate",
      "moves": [
        "Play Rough",
        "Reversal",
        "Crunch",
        "Roar"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 98,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GRANBULL:0",
      "originalSpeciesKey": "GRANBULL:0",
      "trainerId": "BLACKBELT:Ryan:0",
      "slot": 2,
      "doubles": false
    },
    "Blackbelt Kenn [Slot 2]": {
      "level": 34,
      "ability": "Intimidate",
      "moves": [
        "Play Rough",
        "Reversal",
        "Crunch",
        "Earthquake"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 114,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GRANBULL:0",
      "originalSpeciesKey": "GRANBULL:0",
      "trainerId": "BLACKBELT:Kenn:0",
      "slot": 2,
      "doubles": false
    },
    "Rocker Axel [Slot 2]": {
      "level": 39,
      "ability": "Intimidate",
      "moves": [
        "Play Rough",
        "Close Combat",
        "Fire Fang",
        "Thunder Wave"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 143,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRANBULL:0",
      "originalSpeciesKey": "GRANBULL:0",
      "trainerId": "ROCKER:Axel:0",
      "slot": 2,
      "doubles": false
    },
    "Aromalady Eileen [Slot 1]": {
      "level": 48,
      "ability": "Intimidate",
      "moves": [
        "Play Rough",
        "Dynamic Punch",
        "Payback",
        "Roar"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 203,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GRANBULL:0",
      "originalSpeciesKey": "GRANBULL:0",
      "trainerId": "AROMALADY:Eileen:0",
      "slot": 1,
      "doubles": false
    },
    "Juggler Seymour [Slot 3]": {
      "level": 67,
      "ability": "Intimidate",
      "moves": [
        "Play Rough",
        "Close Combat",
        "Earthquake"
      ],
      "nature": "Careful",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 253,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRANBULL:0",
      "originalSpeciesKey": "GRANBULL:0",
      "trainerId": "JUGGLER:Seymour:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Frillish": {
    "Lass Brooke [Slot 2]": {
      "level": 31,
      "ability": "Cursed Body",
      "moves": [
        "Brine",
        "Whirlpool",
        "Hex",
        "Will-O-Wisp"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 99,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FRILLISH:0",
      "originalSpeciesKey": "FRILLISH:0",
      "trainerId": "LASS:Brooke:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Piloswine": {
    "Lass Brooke [Slot 3]": {
      "level": 30,
      "ability": "Thick Fat",
      "moves": [
        "Ice Shard",
        "Avalanche",
        "Bulldoze"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 99,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PILOSWINE:0",
      "originalSpeciesKey": "PILOSWINE:0",
      "trainerId": "LASS:Brooke:0",
      "slot": 3,
      "doubles": false
    },
    "Gentleman Bernarnd [Slot 3]": {
      "level": 48,
      "ability": "Thick Fat",
      "moves": [
        "Icicle Spear",
        "Earthquake",
        "Curse",
        "Rest"
      ],
      "nature": "Careful",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 178,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PILOSWINE:0",
      "originalSpeciesKey": "PILOSWINE:0",
      "trainerId": "GENTLEMAN:Bernarnd:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Orbeetle": {
    "Psychic M Ethan [Slot 1]": {
      "level": 31,
      "ability": "Compound Eyes",
      "moves": [
        "Bug Buzz",
        "Psyshock",
        "Infestation"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 100,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORBEETLE:0",
      "originalSpeciesKey": "ORBEETLE:0",
      "trainerId": "PSYCHIC_M:Ethan:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic M Grunt #11 [Slot 1]": {
      "level": 48,
      "ability": "Compound Eyes",
      "moves": [
        "Bug Buzz",
        "Psychic",
        "Reflect",
        "Recover"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 208,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORBEETLE:0",
      "originalSpeciesKey": "ORBEETLE:0",
      "trainerId": "GALACTIC_M:Grunt:10",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Aaron #1 [Slot 1]": {
      "level": 99,
      "ability": "Swarm",
      "moves": [
        "Bug Buzz",
        "Psyshock",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Timid",
      "item": "Light Clay",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 314,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ORBEETLE:0",
      "originalSpeciesKey": "ORBEETLE:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:0",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Aaron #2 (DOUBLES) [Slot 2]": {
      "level": 99,
      "ability": "Swarm",
      "moves": [
        "Bug Buzz",
        "Giga Drain",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Timid",
      "item": "Light Clay",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 315,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ORBEETLE:0",
      "originalSpeciesKey": "ORBEETLE:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:1",
      "slot": 2,
      "doubles": true
    },
    "Galactic M Grunt #19 (DOUBLES) [Slot 2]": {
      "level": 72,
      "ability": "Compound Eyes",
      "moves": [
        "Bug Buzz",
        "Psychic",
        "Hypnosis",
        "Recover"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 280,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORBEETLE:0",
      "originalSpeciesKey": "ORBEETLE:0",
      "trainerId": "GALACTIC_M:Grunt:19",
      "slot": 2,
      "doubles": true
    }
  },
  "Grumpig": {
    "Psychic M Ethan [Slot 2]": {
      "level": 32,
      "ability": "Thick Fat",
      "moves": [
        "Extrasensory",
        "Power Gem",
        "Night Shade",
        "Nasty Plot"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 100,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GRUMPIG:0",
      "originalSpeciesKey": "GRUMPIG:0",
      "trainerId": "PSYCHIC_M:Ethan:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer F Serena [Slot 2]": {
      "level": 41,
      "ability": "Thick Fat",
      "moves": [
        "Extrasensory",
        "Future Sight",
        "Dazzling Gleam",
        "Thunder Wave"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 157,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRUMPIG:0",
      "originalSpeciesKey": "GRUMPIG:0",
      "trainerId": "COOLTRAINER_F:Serena:0",
      "slot": 2,
      "doubles": false
    },
    "Pokemonranger M Derek [Slot 2]": {
      "level": 58,
      "ability": "Thick Fat",
      "moves": [
        "Extrasensory",
        "Focus Blast",
        "Power Gem",
        "Reflect"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 223,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRUMPIG:0",
      "originalSpeciesKey": "GRUMPIG:0",
      "trainerId": "POKEMONRANGER_M:Derek:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Porygon": {
    "Scientist Isaac [Slot 1]": {
      "level": 30,
      "ability": "Download",
      "moves": [
        "Swift",
        "Icy Wind",
        "Charge Beam",
        "Recover"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 101,
      "gender": "",
      "shiny": false,
      "speciesKey": "PORYGON:0",
      "originalSpeciesKey": "PORYGON:0",
      "trainerId": "SCIENTIST:Isaac:0",
      "slot": 1,
      "doubles": false
    },
    "Youngster Petey [Slot 2]": {
      "level": 58,
      "ability": "Download",
      "moves": [
        "Recover",
        "Tri Attack",
        "Thunder Wave",
        "Thunderbolt"
      ],
      "nature": "Modest",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 226,
      "gender": "",
      "shiny": false,
      "speciesKey": "PORYGON:0",
      "originalSpeciesKey": "PORYGON:0",
      "trainerId": "YOUNGSTER:Petey:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Arbok": {
    "Scientist Isaac [Slot 2]": {
      "level": 31,
      "ability": "Intimidate",
      "moves": [
        "Poison Fang",
        "Ice Fang",
        "Crunch",
        "Coil"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 101,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARBOK:0",
      "originalSpeciesKey": "ARBOK:0",
      "trainerId": "SCIENTIST:Isaac:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Koga #1 [Slot 2]": {
      "level": 39,
      "ability": "Sheer Force",
      "moves": [
        "Poison Jab",
        "Crunch",
        "Ice Fang"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 139,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARBOK:0",
      "originalSpeciesKey": "ARBOK:0",
      "trainerId": "LEADER_Koga:Koga:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Koga #2 (DOUBLES) [Slot 2]": {
      "level": 39,
      "ability": "Sheer Force",
      "moves": [
        "Poison Jab",
        "Crunch",
        "Ice Fang"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 140,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARBOK:0",
      "originalSpeciesKey": "ARBOK:0",
      "trainerId": "LEADER_Koga:Koga:1",
      "slot": 2,
      "doubles": true
    },
    "Galactic M Grunt #11 [Slot 2]": {
      "level": 49,
      "ability": "Intimidate",
      "moves": [
        "Sucker Punch",
        "Gunk Shot",
        "Stomping Tantrum"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 208,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ARBOK:0",
      "originalSpeciesKey": "ARBOK:0",
      "trainerId": "GALACTIC_M:Grunt:10",
      "slot": 2,
      "doubles": false
    },
    "Galactic F Grunt #4 [Slot 2]": {
      "level": 72,
      "ability": "Sheer Force",
      "moves": [
        "Sucker Punch",
        "Gunk Shot",
        "Ice Fang",
        "Coil"
      ],
      "nature": "Jolly",
      "item": "Black Sludge",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 276,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARBOK:0",
      "originalSpeciesKey": "ARBOK:0",
      "trainerId": "GALACTIC_F:Grunt:15",
      "slot": 2,
      "doubles": false
    }
  },
  "Klang": {
    "Scientist Isaac [Slot 3]": {
      "level": 32,
      "ability": "Levitate",
      "moves": [
        "Gear Grind",
        "Wild Charge",
        "Assurance"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 101,
      "gender": "",
      "shiny": false,
      "speciesKey": "KLANG:0",
      "originalSpeciesKey": "KLANG:0",
      "trainerId": "SCIENTIST:Isaac:0",
      "slot": 3,
      "doubles": false
    },
    "Picnicker Candice [Slot 4]": {
      "level": 47,
      "ability": "Levitate",
      "moves": [
        "Gear Grind",
        "Wild Charge",
        "Power Gem",
        "Shift Gear"
      ],
      "nature": "Serious",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 164,
      "gender": "",
      "shiny": false,
      "speciesKey": "KLANG:0",
      "originalSpeciesKey": "KLANG:0",
      "trainerId": "PICNICKER:Candice:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Muk [Alolan]": {
    "Supernerd Jake [Slot 2]": {
      "level": 31,
      "ability": "Poison Touch",
      "moves": [
        "Poison Jab",
        "Knock Off",
        "Disable",
        "Toxic"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 102,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MUK:1",
      "originalSpeciesKey": "MUK:1",
      "trainerId": "SUPERNERD:Jake:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic Commander Mars [Slot 4]": {
      "level": 37,
      "ability": "Poison Touch",
      "moves": [
        "Poison Jab",
        "Knock Off",
        "Acid Armor"
      ],
      "nature": "Careful",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 132,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MUK:1",
      "originalSpeciesKey": "MUK:1",
      "trainerId": "MARS:Mars:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Dodrio": {
    "Supernerd Jake [Slot 3]": {
      "level": 32,
      "ability": "Tangled Feet",
      "moves": [
        "Body Slam",
        "Drill Peck",
        "Pursuit"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 102,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DODRIO:0",
      "originalSpeciesKey": "DODRIO:0",
      "trainerId": "SUPERNERD:Jake:0",
      "slot": 3,
      "doubles": false
    },
    "Biker Rob [Slot 3]": {
      "level": 48,
      "ability": "Early Bird",
      "moves": [
        "Drill Peck",
        "Drill Run",
        "Stomping Tantrum",
        "Mirror Move"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 186,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DODRIO:0",
      "originalSpeciesKey": "DODRIO:0",
      "trainerId": "BIKER:Rob:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic M Grunt #9 [Slot 1]": {
      "level": 48,
      "ability": "Rock Head",
      "moves": [
        "Double-Edge",
        "Brave Bird",
        "Jump Kick",
        "Pursuit"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 206,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DODRIO:0",
      "originalSpeciesKey": "DODRIO:0",
      "trainerId": "GALACTIC_M:Grunt:8",
      "slot": 1,
      "doubles": false
    }
  },
  "Sunflora": {
    "Aromalady Casey [Slot 1]": {
      "level": 31,
      "ability": "Chlorophyll",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Grass Whistle",
        "Synthesis"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 103,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SUNFLORA:0",
      "originalSpeciesKey": "SUNFLORA:0",
      "trainerId": "AROMALADY:Casey:0",
      "slot": 1,
      "doubles": false
    },
    "Gentleman Phillip [Slot 2]": {
      "level": 46,
      "ability": "Chlorophyll",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Earth Power",
        "Synthesis"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 180,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SUNFLORA:0",
      "originalSpeciesKey": "SUNFLORA:0",
      "trainerId": "GENTLEMAN:Phillip:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Weepinbell": {
    "Aromalady Casey [Slot 2]": {
      "level": 32,
      "ability": "Chlorophyll",
      "moves": [
        "Bullet Seed",
        "Sludge Bomb",
        "Knock Off",
        "Stun Spore"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 103,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WEEPINBELL:0",
      "originalSpeciesKey": "WEEPINBELL:0",
      "trainerId": "AROMALADY:Casey:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Illumise": {
    "Aromalady Casey [Slot 3]": {
      "level": 33,
      "ability": "Prankster",
      "moves": [
        "Infestation",
        "Draining Kiss",
        "Moonlight",
        "Encore"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 103,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ILLUMISE:0",
      "originalSpeciesKey": "ILLUMISE:0",
      "trainerId": "AROMALADY:Casey:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Beedrill": {
    "Bugcatcher Liam [Slot 1]": {
      "level": 32,
      "ability": "Sniper",
      "moves": [
        "Pin Missile",
        "Poison Jab",
        "Pluck",
        "Focus Energy"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 104,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BEEDRILL:0",
      "originalSpeciesKey": "BEEDRILL:0",
      "trainerId": "BUGCATCHER:Liam:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Larvesta": {
    "Bugcatcher Liam [Slot 2]": {
      "level": 33,
      "ability": "Flame Body",
      "moves": [
        "Bug Bite",
        "Flame Charge",
        "Wild Charge"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 104,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LARVESTA:0",
      "originalSpeciesKey": "LARVESTA:0",
      "trainerId": "BUGCATCHER:Liam:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Rhydon": {
    "Dawn Dawn #1 [Slot 1]": {
      "level": 33,
      "ability": "Rock Head",
      "moves": [
        "Stealth Rock",
        "Rock Tomb",
        "Bulldoze"
      ],
      "nature": "Careful",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 105,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RHYDON:0",
      "originalSpeciesKey": "RHYDON:0",
      "trainerId": "DAWN:Dawn:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Crawdaunt": {
    "Dawn Dawn #1 [Slot 2]": {
      "level": 33,
      "ability": "Adaptability",
      "moves": [
        "Aqua Jet",
        "Razor Shell",
        "Knock Off",
        "X-Scissor"
      ],
      "nature": "Adamant",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 105,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CRAWDAUNT:0",
      "originalSpeciesKey": "CRAWDAUNT:0",
      "trainerId": "DAWN:Dawn:0",
      "slot": 2,
      "doubles": false
    },
    "Dawn Dawn #2 [Slot 1]": {
      "level": 69,
      "ability": "Adaptability",
      "moves": [
        "Aqua Jet",
        "Crabhammer",
        "Knock Off",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 106,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CRAWDAUNT:0",
      "originalSpeciesKey": "CRAWDAUNT:0",
      "trainerId": "DAWN:Dawn:1",
      "slot": 1,
      "doubles": false
    },
    "Swimmer2 M Dean [Slot 1]": {
      "level": 45,
      "ability": "Shell Armor",
      "moves": [
        "Fling",
        "Aqua Jet",
        "Crunch",
        "Superpower"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 162,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CRAWDAUNT:0",
      "originalSpeciesKey": "CRAWDAUNT:0",
      "trainerId": "SWIMMER2_M:Dean:0",
      "slot": 1,
      "doubles": false
    },
    "Ruinmaniac Vince [Slot 2]": {
      "level": 65,
      "ability": "Adaptability",
      "moves": [
        "Aqua Jet",
        "Crabhammer",
        "Knock Off",
        "Close Combat"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 241,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CRAWDAUNT:0",
      "originalSpeciesKey": "CRAWDAUNT:0",
      "trainerId": "RUINMANIAC:Vince:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Clefable": {
    "Dawn Dawn #1 [Slot 3]": {
      "level": 33,
      "ability": "Magic Guard",
      "moves": [
        "Draining Kiss",
        "Flamethrower",
        "Calm Mind"
      ],
      "nature": "Bold",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 105,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFABLE:0",
      "originalSpeciesKey": "CLEFABLE:0",
      "trainerId": "DAWN:Dawn:0",
      "slot": 3,
      "doubles": false
    },
    "Dawn Dawn #2 [Slot 3]": {
      "level": 69,
      "ability": "Magic Guard",
      "moves": [
        "Fire Blast",
        "Thunderbolt",
        "Lovely Kiss",
        "Calm Mind"
      ],
      "nature": "Bold",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 106,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFABLE:0",
      "originalSpeciesKey": "CLEFABLE:0",
      "trainerId": "DAWN:Dawn:1",
      "slot": 3,
      "doubles": false
    },
    "Picnicker Sophie [Slot 1]": {
      "level": 39,
      "ability": "Magic Guard",
      "moves": [
        "Stealth Rock",
        "Moonblast",
        "Fire Blast",
        "Thunderbolt"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 141,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFABLE:0",
      "originalSpeciesKey": "CLEFABLE:0",
      "trainerId": "PICNICKER:Sophie:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Jerome [Slot 2]": {
      "level": 49,
      "ability": "Magic Guard",
      "moves": [
        "Draining Kiss",
        "Thunderbolt",
        "Mystical Fire",
        "Ice Beam"
      ],
      "nature": "Timid",
      "item": "Pixie Plate",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 197,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFABLE:0",
      "originalSpeciesKey": "CLEFABLE:0",
      "trainerId": "HIKER:Jerome:0",
      "slot": 2,
      "doubles": false
    },
    "Pokemaniac Boone [Slot 2]": {
      "level": 63,
      "ability": "Magic Guard",
      "moves": [
        "Moonblast",
        "Flamethrower",
        "Focus Blast",
        "Soft-Boiled"
      ],
      "nature": "Bold",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 232,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFABLE:0",
      "originalSpeciesKey": "CLEFABLE:0",
      "trainerId": "POKEMANIAC:Boone:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer F Lumina [Slot 1]": {
      "level": 67,
      "ability": "Magic Guard",
      "moves": [
        "Stealth Rock",
        "Blizzard",
        "Fire Blast",
        "Psychic"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 259,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFABLE:0",
      "originalSpeciesKey": "CLEFABLE:0",
      "trainerId": "COOLTRAINER_F:Lumina:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer M Hawk [Slot 2]": {
      "level": 95,
      "ability": "Magic Guard",
      "moves": [
        "Moonblast",
        "Stored Power",
        "Cosmic Power",
        "Soft-Boiled"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 303,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFABLE:0",
      "originalSpeciesKey": "CLEFABLE:0",
      "trainerId": "COOLTRAINER_M:Hawk:0",
      "slot": 2,
      "doubles": false
    },
    "Ace Trainer Tibor (DOUBLES) [Slot 1]": {
      "level": 79,
      "ability": "Friend Guard",
      "moves": [
        "Moonblast",
        "Fire Blast",
        "Follow Me"
      ],
      "nature": "Relaxed",
      "item": "Iapapa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 290,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLEFABLE:0",
      "originalSpeciesKey": "CLEFABLE:0",
      "trainerId": "COOLTRAINER_M:Tibor:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Slowbro [Galarian]": {
    "Dawn Dawn #1 [Slot 4]": {
      "level": 33,
      "ability": "Quick Draw",
      "moves": [
        "Poison Jab",
        "Zen Headbutt",
        "Whirlpool",
        "Slack Off"
      ],
      "nature": "Relaxed",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 105,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SLOWBRO:1",
      "originalSpeciesKey": "SLOWBRO:1",
      "trainerId": "DAWN:Dawn:0",
      "slot": 4,
      "doubles": false
    },
    "Dawn Dawn #2 [Slot 4]": {
      "level": 69,
      "ability": "Quick Draw",
      "moves": [
        "Shell Side Arm",
        "Zen Headbutt",
        "Muddy Water",
        "Slack Off"
      ],
      "nature": "Relaxed",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 106,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SLOWBRO:1",
      "originalSpeciesKey": "SLOWBRO:1",
      "trainerId": "DAWN:Dawn:1",
      "slot": 4,
      "doubles": false
    }
  },
  "Torterra": {
    "Dawn Dawn #1 [Slot 5]": {
      "level": 34,
      "ability": "Overgrow",
      "moves": [
        "Seed Bomb",
        "Stomping Tantrum",
        "Stone Edge",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Yache Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 105,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TORTERRA:0",
      "originalSpeciesKey": "TORTERRA:0",
      "trainerId": "DAWN:Dawn:0",
      "slot": 5,
      "doubles": false
    },
    "Pokemonranger M Derek [Slot 3]": {
      "level": 59,
      "ability": "Perseverance",
      "moves": [
        "Wood Hammer",
        "Earthquake",
        "Leech Seed",
        "Protect"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 223,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TORTERRA:0",
      "originalSpeciesKey": "TORTERRA:0",
      "trainerId": "POKEMONRANGER_M:Derek:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Corviknight": {
    "Dawn Dawn #2 [Slot 2]": {
      "level": 69,
      "ability": "Unnerve",
      "moves": [
        "Pluck",
        "Body Press",
        "Bulk Up",
        "Roost"
      ],
      "nature": "Careful",
      "item": "Weakness Policy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 106,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CORVIKNIGHT:0",
      "originalSpeciesKey": "CORVIKNIGHT:0",
      "trainerId": "DAWN:Dawn:1",
      "slot": 2,
      "doubles": false
    },
    "Biker Sal [Slot 2]": {
      "level": 48,
      "ability": "Unnerve",
      "moves": [
        "Revenge",
        "Defog",
        "Iron Head",
        "Brave Bird"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 187,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CORVIKNIGHT:0",
      "originalSpeciesKey": "CORVIKNIGHT:0",
      "trainerId": "BIKER:Sal:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Darmanitan": {
    "Dawn Dawn #2 [Slot 5]": {
      "level": 69,
      "ability": "Sheer Force",
      "moves": [
        "Flare Blitz",
        "Zen Headbutt",
        "Rock Slide"
      ],
      "nature": "Jolly",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 106,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DARMANITAN:0",
      "originalSpeciesKey": "DARMANITAN:0",
      "trainerId": "DAWN:Dawn:1",
      "slot": 5,
      "doubles": false
    },
    "Burglar Drago [Slot 3]": {
      "level": 70,
      "ability": "Sheer Force",
      "moves": [
        "Flare Blitz",
        "Rock Slide",
        "Earthquake",
        "Reversal"
      ],
      "nature": "Jolly",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 268,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DARMANITAN:0",
      "originalSpeciesKey": "DARMANITAN:0",
      "trainerId": "BURGLAR:Drago:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Altaria [Mega Altaria]": {
    "Dawn Dawn #2 [Slot 6]": {
      "level": 70,
      "ability": "Pixilate",
      "moves": [
        "Hyper Voice",
        "Flamethrower",
        "Earthquake",
        "Roost"
      ],
      "nature": "Naive",
      "item": "Altarianite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 106,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ALTARIA:1",
      "originalSpeciesKey": "ALTARIA:0",
      "trainerId": "DAWN:Dawn:1",
      "slot": 6,
      "doubles": false
    }
  },
  "Dusclops": {
    "Cooltrainer M Chad [Slot 1]": {
      "level": 35,
      "ability": "Pressure",
      "moves": [
        "Night Shade",
        "Dark Pulse",
        "Pain Split",
        "Will-O-Wisp"
      ],
      "nature": "Relaxed",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 107,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DUSCLOPS:0",
      "originalSpeciesKey": "DUSCLOPS:0",
      "trainerId": "COOLTRAINER_M:Chad:0",
      "slot": 1,
      "doubles": false
    },
    "Channeler Paula [Slot 2]": {
      "level": 40,
      "ability": "Pressure",
      "moves": [
        "Night Shade",
        "Dark Pulse",
        "Pain Split",
        "Skill Swap"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 148,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DUSCLOPS:0",
      "originalSpeciesKey": "DUSCLOPS:0",
      "trainerId": "CHANNELER:Paula:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Rapidash": {
    "Cooltrainer M Chad [Slot 3]": {
      "level": 35,
      "ability": "Flame Body",
      "moves": [
        "Blaze Kick",
        "Play Rough",
        "Double-Edge"
      ],
      "nature": "Hasty",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 107,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RAPIDASH:0",
      "originalSpeciesKey": "RAPIDASH:0",
      "trainerId": "COOLTRAINER_M:Chad:0",
      "slot": 3,
      "doubles": false
    },
    "Gambler Reggie [Slot 1]": {
      "level": 46,
      "ability": "Reckless",
      "moves": [
        "Flare Blitz",
        "Double-Edge",
        "Wild Charge",
        "Jump Kick"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 181,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RAPIDASH:0",
      "originalSpeciesKey": "RAPIDASH:0",
      "trainerId": "GAMBLER:Reggie:0",
      "slot": 1,
      "doubles": false
    },
    "Burglar Addison [Slot 1]": {
      "level": 66,
      "ability": "Reckless",
      "moves": [
        "Flare Blitz",
        "Play Rough",
        "Double-Edge",
        "Jump Kick"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 247,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RAPIDASH:0",
      "originalSpeciesKey": "RAPIDASH:0",
      "trainerId": "BURGLAR:Addison:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Gyarados": {
    "Cooltrainer M Chad [Slot 4]": {
      "level": 36,
      "ability": "Intimidate",
      "moves": [
        "Waterfall",
        "Bounce",
        "Power Whip",
        "Dragon Dance"
      ],
      "nature": "Adamant",
      "item": "Wacan Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 107,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GYARADOS:0",
      "originalSpeciesKey": "GYARADOS:0",
      "trainerId": "COOLTRAINER_M:Chad:0",
      "slot": 4,
      "doubles": false
    },
    "Swimmer2 F Tara [Slot 3]": {
      "level": 46,
      "ability": "Intimidate",
      "moves": [
        "Take Down",
        "Ice Beam",
        "Hydro Pump",
        "Waterfall"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 160,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GYARADOS:0",
      "originalSpeciesKey": "GYARADOS:0",
      "trainerId": "SWIMMER2_F:Tara:0",
      "slot": 3,
      "doubles": false
    },
    "Galacticboss Cyrus #1 [Slot 3]": {
      "level": 61,
      "ability": "Intimidate",
      "moves": [
        "Waterfall",
        "Earthquake",
        "Stone Edge",
        "Power Whip"
      ],
      "nature": "Jolly",
      "item": "Wacan Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 229,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GYARADOS:0",
      "originalSpeciesKey": "GYARADOS:0",
      "trainerId": "GALACTICBOSS:Cyrus:0",
      "slot": 3,
      "doubles": false
    },
    "Galacticboss Cyrus #2 [Slot 3]": {
      "level": 76,
      "ability": "Intimidate",
      "moves": [
        "Waterfall",
        "Earthquake",
        "Stone Edge",
        "Power Whip"
      ],
      "nature": "Jolly",
      "item": "Wacan Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 230,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GYARADOS:0",
      "originalSpeciesKey": "GYARADOS:0",
      "trainerId": "GALACTICBOSS:Cyrus:1",
      "slot": 3,
      "doubles": false
    },
    "Lady Rosie [Slot 3]": {
      "level": 69,
      "ability": "Moxie",
      "moves": [
        "Waterfall",
        "Power Whip",
        "Earthquake",
        "Dragon Dance"
      ],
      "nature": "Jolly",
      "item": "Wacan Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 260,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GYARADOS:0",
      "originalSpeciesKey": "GYARADOS:0",
      "trainerId": "LADY:Rosie:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer M Matt [Slot 2]": {
      "level": 95,
      "ability": "Intimidate",
      "moves": [
        "Waterfall",
        "Power Whip",
        "Earthquake",
        "Scale Shot"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 296,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GYARADOS:0",
      "originalSpeciesKey": "GYARADOS:0",
      "trainerId": "COOLTRAINER_M:Matt:0",
      "slot": 2,
      "doubles": false
    },
    "Burglar Max & Greed [Slot 4]": {
      "level": 50,
      "ability": "Intimidate",
      "moves": [
        "Waterfall",
        "Power Whip",
        "Ice Fang",
        "Dragon Dance"
      ],
      "nature": "Jolly",
      "item": "Wacan Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 195,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GYARADOS:0",
      "originalSpeciesKey": "GYARADOS:0",
      "trainerId": "UTOPIA_DUO:3:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Luxray": {
    "Biker Duke [Slot 1]": {
      "level": 33,
      "ability": "Guts",
      "moves": [
        "Double Kick",
        "Covet",
        "Charm",
        "Wild Charge"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 109,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LUXRAY:0",
      "originalSpeciesKey": "LUXRAY:0",
      "trainerId": "BIKER:Duke:0",
      "slot": 1,
      "doubles": false
    },
    "Biker Rob [Slot 2]": {
      "level": 48,
      "ability": "Intimidate",
      "moves": [
        "Crunch",
        "Thunderbolt",
        "Play Rough",
        "Zing Zap"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 186,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LUXRAY:0",
      "originalSpeciesKey": "LUXRAY:0",
      "trainerId": "BIKER:Rob:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer F Lynette [Slot 2]": {
      "level": 94,
      "ability": "Guts",
      "moves": [
        "Quick Attack",
        "Zing Zap",
        "Facade",
        "Ice Fang"
      ],
      "nature": "Jolly",
      "item": "Flame Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 293,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LUXRAY:0",
      "originalSpeciesKey": "LUXRAY:0",
      "trainerId": "COOLTRAINER_F:Lynette:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Torracat": {
    "Biker Duke [Slot 2]": {
      "level": 34,
      "ability": "Blaze",
      "moves": [
        "Double Kick",
        "Bite",
        "Scary Face",
        "Blaze Kick"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 109,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TORRACAT:0",
      "originalSpeciesKey": "TORRACAT:0",
      "trainerId": "BIKER:Duke:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Swalot": {
    "Biker Spike [Slot 1]": {
      "level": 32,
      "ability": "Liquid Ooze",
      "moves": [
        "Water Pulse",
        "Venoshock",
        "Body Slam",
        "Toxic"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 110,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SWALOT:0",
      "originalSpeciesKey": "SWALOT:0",
      "trainerId": "BIKER:Spike:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Skorupi": {
    "Biker Spike [Slot 3]": {
      "level": 34,
      "ability": "Battle Armor",
      "moves": [
        "Venoshock",
        "Knock Off",
        "Night Slash",
        "X-Scissor"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 110,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SKORUPI:0",
      "originalSpeciesKey": "SKORUPI:0",
      "trainerId": "BIKER:Spike:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Greavard": {
    "Biker Rex [Slot 1]": {
      "level": 32,
      "ability": "Fluffy",
      "moves": [
        "Crunch",
        "Thunder Fang",
        "Fire Fang",
        "Ice Fang"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 111,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GREAVARD:0",
      "originalSpeciesKey": "GREAVARD:0",
      "trainerId": "BIKER:Rex:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Dreepy": {
    "Biker Rex [Slot 3]": {
      "level": 34,
      "ability": "Clear Body",
      "moves": [
        "Astonish",
        "Bite",
        "Infestation",
        "Dragon Tail"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 111,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DREEPY:0",
      "originalSpeciesKey": "DREEPY:0",
      "trainerId": "BIKER:Rex:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Furret": {
    "Biker Jax [Slot 1]": {
      "level": 33,
      "ability": "Adaptability",
      "moves": [
        "Covet",
        "Reversal",
        "Hyper Fang",
        "Tail Slap"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 112,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FURRET:0",
      "originalSpeciesKey": "FURRET:0",
      "trainerId": "BIKER:Jax:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Marshtomp": {
    "Biker Jax [Slot 2]": {
      "level": 34,
      "ability": "Torrent",
      "moves": [
        "Rock Slide",
        "Muddy Water",
        "Body Slam",
        "Low Kick"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 112,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MARSHTOMP:0",
      "originalSpeciesKey": "MARSHTOMP:0",
      "trainerId": "BIKER:Jax:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Electrode": {
    "Biker Zane [Slot 1]": {
      "level": 33,
      "ability": "Aftermath",
      "moves": [
        "Swift",
        "Signal Beam",
        "Electro Ball",
        "Reflect"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 113,
      "gender": "",
      "shiny": false,
      "speciesKey": "ELECTRODE:0",
      "originalSpeciesKey": "ELECTRODE:0",
      "trainerId": "BIKER:Zane:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Golem [Alolan]": {
    "Biker Zane [Slot 2]": {
      "level": 34,
      "ability": "Magnet Pull",
      "moves": [
        "Thunder Punch",
        "Rock Blast",
        "Self-Destruct",
        "Magnet Rise"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 113,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GOLEM:1",
      "originalSpeciesKey": "GOLEM:1",
      "trainerId": "BIKER:Zane:0",
      "slot": 2,
      "doubles": false
    },
    "Hiker Jerome [Slot 1]": {
      "level": 48,
      "ability": "Rock Head",
      "moves": [
        "Head Smash",
        "Wild Charge",
        "Earthquake",
        "Explosion"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 197,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GOLEM:1",
      "originalSpeciesKey": "GOLEM:1",
      "trainerId": "HIKER:Jerome:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Tim [Slot 2]": {
      "level": 64,
      "ability": "Rock Head",
      "moves": [
        "Head Smash",
        "Wild Charge",
        "Earthquake",
        "Explosion"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 236,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GOLEM:1",
      "originalSpeciesKey": "GOLEM:1",
      "trainerId": "HIKER:Tim:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Primeape": {
    "Blackbelt Kenn [Slot 1]": {
      "level": 33,
      "ability": "Defiant",
      "moves": [
        "Drain Punch",
        "Throat Chop",
        "Ice Punch",
        "Focus Energy"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 114,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PRIMEAPE:0",
      "originalSpeciesKey": "PRIMEAPE:0",
      "trainerId": "BLACKBELT:Kenn:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Bewear": {
    "Blackbelt Kenn [Slot 3]": {
      "level": 35,
      "ability": "Fluffy",
      "moves": [
        "Stomp",
        "Submission",
        "Darkest Lariat",
        "Bulk Up"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 114,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BEWEAR:0",
      "originalSpeciesKey": "BEWEAR:0",
      "trainerId": "BLACKBELT:Kenn:0",
      "slot": 3,
      "doubles": false
    },
    "Picnicker Julia [Slot 3]": {
      "level": 47,
      "ability": "Fluffy",
      "moves": [
        "Strength",
        "Drain Punch",
        "Zen Headbutt",
        "Stomping Tantrum"
      ],
      "nature": "Adamant",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 166,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BEWEAR:0",
      "originalSpeciesKey": "BEWEAR:0",
      "trainerId": "PICNICKER:Julia:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic D Grunt & Grunt (DOUBLES) [Slot 3]": {
      "level": 50,
      "ability": "Fluffy",
      "moves": [
        "Double-Edge",
        "Drain Punch",
        "Play Rough",
        "Rock Slide"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 204,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BEWEAR:0",
      "originalSpeciesKey": "BEWEAR:0",
      "trainerId": "GALACTIC_D:Grunt & Grunt:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Lilligant [Hisuian]": {
    "Blackbelt Ryuu [Slot 3]": {
      "level": 35,
      "ability": "Chlorophyll",
      "moves": [
        "Seed Bomb",
        "Brick Break",
        "Poison Jab",
        "Sleep Powder"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 115,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LILLIGANT:1",
      "originalSpeciesKey": "LILLIGANT:1",
      "trainerId": "BLACKBELT:Ryuu:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Hitmontop": {
    "Blackbelt Hiro [Slot 1]": {
      "level": 33,
      "ability": "Intimidate",
      "moves": [
        "Mach Punch",
        "Triple Kick",
        "Triple Axel",
        "Focus Energy"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 116,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HITMONTOP:0",
      "originalSpeciesKey": "HITMONTOP:0",
      "trainerId": "BLACKBELT:Hiro:0",
      "slot": 1,
      "doubles": false
    },
    "Blackbelt Damon [Slot 2]": {
      "level": 95,
      "ability": "Technician",
      "moves": [
        "Mach Punch",
        "Bullet Punch",
        "Triple Axel",
        "Pursuit"
      ],
      "nature": "Adamant",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 302,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HITMONTOP:0",
      "originalSpeciesKey": "HITMONTOP:0",
      "trainerId": "BLACKBELT:Damon:0",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Bruno #1 [Slot 1]": {
      "level": 99,
      "ability": "Intimidate",
      "moves": [
        "Mach Punch",
        "Bullet Punch",
        "Triple Axel"
      ],
      "nature": "Adamant",
      "item": "Punching Glove",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 312,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HITMONTOP:0",
      "originalSpeciesKey": "HITMONTOP:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:0",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Bruno #2 (DOUBLES) [Slot 2]": {
      "level": 99,
      "ability": "Intimidate",
      "moves": [
        "Mach Punch",
        "Bullet Punch",
        "Fake Out",
        "Triple Axel"
      ],
      "nature": "Adamant",
      "item": "Clear Amulet",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 313,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HITMONTOP:0",
      "originalSpeciesKey": "HITMONTOP:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:1",
      "slot": 2,
      "doubles": true
    }
  },
  "Hariyama": {
    "Blackbelt Hiro [Slot 2]": {
      "level": 34,
      "ability": "Guts",
      "moves": [
        "Fake Out",
        "Cross Chop",
        "Rock Slide",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 116,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HARIYAMA:0",
      "originalSpeciesKey": "HARIYAMA:0",
      "trainerId": "BLACKBELT:Hiro:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #19 (DOUBLES) [Slot 4]": {
      "level": 73,
      "ability": "Thick Fat",
      "moves": [
        "Fake Out",
        "Wake-Up Slap",
        "Rock Slide",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 280,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HARIYAMA:0",
      "originalSpeciesKey": "HARIYAMA:0",
      "trainerId": "GALACTIC_M:Grunt:19",
      "slot": 4,
      "doubles": true
    }
  },
  "Pawmot": {
    "Blackbelt Hiro [Slot 3]": {
      "level": 35,
      "ability": "Natural Cure",
      "moves": [
        "Wild Charge",
        "Arm Thrust",
        "Thief",
        "Revival Blessing"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 116,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PAWMOT:0",
      "originalSpeciesKey": "PAWMOT:0",
      "trainerId": "BLACKBELT:Hiro:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Toxicroak": {
    "Blackbelt Kojiro [Slot 2]": {
      "level": 35,
      "ability": "Poison Touch",
      "moves": [
        "Vacuum Wave",
        "Venoshock",
        "Aura Sphere",
        "Toxic"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 118,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOXICROAK:0",
      "originalSpeciesKey": "TOXICROAK:0",
      "trainerId": "BLACKBELT:Kojiro:0",
      "slot": 2,
      "doubles": false
    },
    "Juggler Dalton [Slot 2]": {
      "level": 36,
      "ability": "Poison Touch",
      "moves": [
        "Sucker Punch",
        "Brick Break",
        "Cross Chop",
        "Bulk Up"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 133,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TOXICROAK:0",
      "originalSpeciesKey": "TOXICROAK:0",
      "trainerId": "JUGGLER:Dalton:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #10 [Slot 2]": {
      "level": 49,
      "ability": "Poison Touch",
      "moves": [
        "Poison Jab",
        "Drain Punch",
        "Ice Punch"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 207,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOXICROAK:0",
      "originalSpeciesKey": "TOXICROAK:0",
      "trainerId": "GALACTIC_M:Grunt:9",
      "slot": 2,
      "doubles": false
    },
    "Galactic Commander Saturn #1 (DOUBLES) [Slot 1]": {
      "level": 51,
      "ability": "Poison Touch",
      "moves": [
        "Vacuum Wave",
        "Sludge Bomb",
        "Aura Sphere"
      ],
      "nature": "Modest",
      "item": "Payapa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 209,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOXICROAK:0",
      "originalSpeciesKey": "TOXICROAK:0",
      "trainerId": "SATURN:Saturn:0",
      "slot": 1,
      "doubles": true
    },
    "Galactic M Grunt #19 (DOUBLES) [Slot 1]": {
      "level": 72,
      "ability": "Poison Touch",
      "moves": [
        "Fake Out",
        "Poison Jab",
        "Wake-Up Slap",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Payapa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 280,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TOXICROAK:0",
      "originalSpeciesKey": "TOXICROAK:0",
      "trainerId": "GALACTIC_M:Grunt:19",
      "slot": 1,
      "doubles": true
    },
    "Ace Trainer Chalina (DOUBLES) [Slot 4]": {
      "level": 96,
      "ability": "Dry Skin",
      "moves": [
        "Fake Out",
        "Gunk Shot",
        "Cross Chop",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 307,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOXICROAK:0",
      "originalSpeciesKey": "TOXICROAK:0",
      "trainerId": "COOLTRAINER_F:Chalina:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Throh": {
    "Blackbelt Kojiro [Slot 3]": {
      "level": 36,
      "ability": "Guts",
      "moves": [
        "Storm Throw",
        "Body Slam",
        "Payback",
        "Recover"
      ],
      "nature": "Adamant",
      "item": "Flame Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 118,
      "gender": "M",
      "shiny": false,
      "speciesKey": "THROH:0",
      "originalSpeciesKey": "THROH:0",
      "trainerId": "BLACKBELT:Kojiro:0",
      "slot": 3,
      "doubles": false
    },
    "Blackbelt Corey [Slot 2]": {
      "level": 58,
      "ability": "Guts",
      "moves": [
        "Circle Throw",
        "Facade",
        "Bulk Up",
        "Recover"
      ],
      "nature": "Careful",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 225,
      "gender": "M",
      "shiny": false,
      "speciesKey": "THROH:0",
      "originalSpeciesKey": "THROH:0",
      "trainerId": "BLACKBELT:Corey:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Sawk": {
    "Blackbelt Kojiro [Slot 4]": {
      "level": 36,
      "ability": "Sturdy",
      "moves": [
        "Brick Break",
        "Throat Chop",
        "Thunder Punch",
        "Counter"
      ],
      "nature": "Adamant",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 118,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SAWK:0",
      "originalSpeciesKey": "SAWK:0",
      "trainerId": "BLACKBELT:Kojiro:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Aromatisse": {
    "Lass Amy [Slot 1]": {
      "level": 33,
      "ability": "Healer",
      "moves": [
        "Dazzling Gleam",
        "Drain Punch",
        "Sweet Kiss",
        "Attract"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 119,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AROMATISSE:0",
      "originalSpeciesKey": "AROMATISSE:0",
      "trainerId": "LASS:Amy:0",
      "slot": 1,
      "doubles": false
    },
    "Pokemonbreeder Mariah [Slot 1]": {
      "level": 48,
      "ability": "Aroma Veil",
      "moves": [
        "Encore",
        "Hyper Voice",
        "Dazzling Gleam",
        "Skill Swap"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 189,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AROMATISSE:0",
      "originalSpeciesKey": "AROMATISSE:0",
      "trainerId": "POKEMONBREEDER:Mariah:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Sandshrew [Alolan]": {
    "Lass Amy [Slot 2]": {
      "level": 34,
      "ability": "Slush Rush",
      "moves": [
        "Triple Axel",
        "Iron Head",
        "Stomping Tantrum",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 119,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SANDSHREW:1",
      "originalSpeciesKey": "SANDSHREW:1",
      "trainerId": "LASS:Amy:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Dachsbun": {
    "Lass Tina [Slot 2]": {
      "level": 34,
      "ability": "Well-Baked Body",
      "moves": [
        "Play Rough",
        "Psychic Fangs",
        "Crunch",
        "Take Down"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 120,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DACHSBUN:0",
      "originalSpeciesKey": "DACHSBUN:0",
      "trainerId": "LASS:Tina:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Zorua": {
    "Lass Tina [Slot 3]": {
      "level": 35,
      "ability": "Illusion",
      "moves": [
        "Foul Play",
        "Skitter Smack",
        "Dig",
        "Torment"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 120,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ZORUA:0",
      "originalSpeciesKey": "ZORUA:0",
      "trainerId": "LASS:Tina:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Lickitung": {
    "Gentleman Arthur [Slot 1]": {
      "level": 33,
      "ability": "Oblivious",
      "moves": [
        "Body Slam",
        "Muddy Water",
        "Shadow Ball",
        "Work Up"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 121,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LICKITUNG:0",
      "originalSpeciesKey": "LICKITUNG:0",
      "trainerId": "GENTLEMAN:Arthur:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Roselia": {
    "Gentleman Arthur [Slot 2]": {
      "level": 34,
      "ability": "Poison Point",
      "moves": [
        "Mega Drain",
        "Sludge",
        "Dazzling Gleam",
        "Grass Whistle"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 121,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ROSELIA:0",
      "originalSpeciesKey": "ROSELIA:0",
      "trainerId": "GENTLEMAN:Arthur:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Starmie": {
    "Gentleman Arthur [Slot 3]": {
      "level": 34,
      "ability": "Analytic",
      "moves": [
        "Brine",
        "Psybeam",
        "Aurora Beam",
        "Rapid Spin"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 121,
      "gender": "",
      "shiny": false,
      "speciesKey": "STARMIE:0",
      "originalSpeciesKey": "STARMIE:0",
      "trainerId": "GENTLEMAN:Arthur:0",
      "slot": 3,
      "doubles": false
    },
    "Swimmer2 F Tara [Slot 2]": {
      "level": 45,
      "ability": "Natural Cure",
      "moves": [
        "Whirlpool",
        "Spotlight",
        "Power Gem",
        "Surf"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 160,
      "gender": "",
      "shiny": false,
      "speciesKey": "STARMIE:0",
      "originalSpeciesKey": "STARMIE:0",
      "trainerId": "SWIMMER2_F:Tara:0",
      "slot": 2,
      "doubles": false
    },
    "Beauty Alina [Slot 2]": {
      "level": 48,
      "ability": "Analytic",
      "moves": [
        "Surf",
        "Psychic",
        "Dazzling Gleam",
        "Flip Turn"
      ],
      "nature": "Quiet",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 183,
      "gender": "",
      "shiny": false,
      "speciesKey": "STARMIE:0",
      "originalSpeciesKey": "STARMIE:0",
      "trainerId": "BEAUTY:Alina:0",
      "slot": 2,
      "doubles": false
    },
    "Psychic M Sheldon [Slot 4]": {
      "level": 66,
      "ability": "Analytic",
      "moves": [
        "Hydro Pump",
        "Psychic",
        "Grass Knot"
      ],
      "nature": "Timid",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 237,
      "gender": "",
      "shiny": false,
      "speciesKey": "STARMIE:0",
      "originalSpeciesKey": "STARMIE:0",
      "trainerId": "PSYCHIC_M:Sheldon:0",
      "slot": 4,
      "doubles": false
    },
    "Psychic M Juan [Slot 3]": {
      "level": 96,
      "ability": "Analytic",
      "moves": [
        "Scald",
        "Psychic",
        "Meteor Beam",
        "Ice Beam"
      ],
      "nature": "Timid",
      "item": "Power Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 306,
      "gender": "",
      "shiny": false,
      "speciesKey": "STARMIE:0",
      "originalSpeciesKey": "STARMIE:0",
      "trainerId": "PSYCHIC_M:Juan:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Eelektrik": {
    "Gentleman Arthur [Slot 4]": {
      "level": 35,
      "ability": "Levitate",
      "moves": [
        "Discharge",
        "Giga Drain",
        "Gastro Acid",
        "Knock Off"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 121,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EELEKTRIK:0",
      "originalSpeciesKey": "EELEKTRIK:0",
      "trainerId": "GENTLEMAN:Arthur:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Qwilfish [Hisuian]": {
    "Pokemonranger F Kara [Slot 1]": {
      "level": 34,
      "ability": "Intimidate",
      "moves": [
        "Toxic Spikes",
        "Throat Chop",
        "Liquidation",
        "Thunder Wave"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 122,
      "gender": "M",
      "shiny": false,
      "speciesKey": "QWILFISH:1",
      "originalSpeciesKey": "QWILFISH:1",
      "trainerId": "POKEMONRANGER_F:Kara:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Octillery": {
    "Pokemonranger F Kara [Slot 3]": {
      "level": 36,
      "ability": "Sniper",
      "moves": [
        "Water Pulse",
        "Bullet Seed",
        "Rock Blast",
        "Icy Wind"
      ],
      "nature": "Rash",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 122,
      "gender": "F",
      "shiny": false,
      "speciesKey": "OCTILLERY:0",
      "originalSpeciesKey": "OCTILLERY:0",
      "trainerId": "POKEMONRANGER_F:Kara:0",
      "slot": 3,
      "doubles": false
    },
    "Picnicker Julia [Slot 1]": {
      "level": 46,
      "ability": "Moody",
      "moves": [
        "Octazooka",
        "Bullet Seed",
        "Rock Blast",
        "Focus Energy"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 166,
      "gender": "F",
      "shiny": false,
      "speciesKey": "OCTILLERY:0",
      "originalSpeciesKey": "OCTILLERY:0",
      "trainerId": "PICNICKER:Julia:0",
      "slot": 1,
      "doubles": false
    },
    "Pokemonranger M Enzio [Slot 3]": {
      "level": 68,
      "ability": "Sniper",
      "moves": [
        "Fire Blast",
        "Gunk Shot",
        "Psychic",
        "Thunder Wave"
      ],
      "nature": "Quiet",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 251,
      "gender": "M",
      "shiny": false,
      "speciesKey": "OCTILLERY:0",
      "originalSpeciesKey": "OCTILLERY:0",
      "trainerId": "POKEMONRANGER_M:Enzio:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Mudbray": {
    "Hiker Lucas [Slot 1]": {
      "level": 34,
      "ability": "Tangling Hair",
      "moves": [
        "Stomping Tantrum",
        "Rock Tomb",
        "Low Sweep",
        "Counter"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 123,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MUDBRAY:0",
      "originalSpeciesKey": "MUDBRAY:0",
      "trainerId": "HIKER:Lucas:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Pupitar": {
    "Hiker Lucas [Slot 2]": {
      "level": 35,
      "ability": "Shed Skin",
      "moves": [
        "Rock Slide",
        "Stomping Tantrum",
        "Assurance",
        "Screech"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 123,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PUPITAR:0",
      "originalSpeciesKey": "PUPITAR:0",
      "trainerId": "HIKER:Lucas:0",
      "slot": 2,
      "doubles": false
    },
    "Pokemaniac Triton [Slot 1]": {
      "level": 46,
      "ability": "Shed Skin",
      "moves": [
        "Rock Tomb",
        "Bulldoze",
        "Crunch",
        "Screech"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 169,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PUPITAR:0",
      "originalSpeciesKey": "PUPITAR:0",
      "trainerId": "POKEMANIAC:Triton:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Tyrunt": {
    "Hiker Lucas [Slot 3]": {
      "level": 36,
      "ability": "Strong Jaw",
      "moves": [
        "Psychic Fangs",
        "Thunder Fang",
        "Fire Fang",
        "Ice Fang"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 123,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TYRUNT:0",
      "originalSpeciesKey": "TYRUNT:0",
      "trainerId": "HIKER:Lucas:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Gumshoos": {
    "Scientist Reed [Slot 1]": {
      "level": 33,
      "ability": "Stakeout",
      "moves": [
        "Take Down",
        "Crunch",
        "Super Fang",
        "Yawn"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 124,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GUMSHOOS:0",
      "originalSpeciesKey": "GUMSHOOS:0",
      "trainerId": "SCIENTIST:Reed:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Rabsca": {
    "Scientist Reed [Slot 3]": {
      "level": 35,
      "ability": "Synchronize",
      "moves": [
        "Struggle Bug",
        "Extrasensory",
        "Mud-Slap",
        "Speed Swap"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 124,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RABSCA:0",
      "originalSpeciesKey": "RABSCA:0",
      "trainerId": "SCIENTIST:Reed:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Magneton": {
    "Scientist Reed [Slot 4]": {
      "level": 36,
      "ability": "Magnet Pull",
      "moves": [
        "Discharge",
        "Mirror Shot",
        "Metal Sound"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 124,
      "gender": "",
      "shiny": false,
      "speciesKey": "MAGNETON:0",
      "originalSpeciesKey": "MAGNETON:0",
      "trainerId": "SCIENTIST:Reed:0",
      "slot": 4,
      "doubles": false
    },
    "Engineer Andrew [Slot 3]": {
      "level": 53,
      "ability": "Magnet Pull",
      "moves": [
        "Discharge",
        "Flash Cannon",
        "Signal Beam",
        "Magnet Rise"
      ],
      "nature": "Timid",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 216,
      "gender": "",
      "shiny": false,
      "speciesKey": "MAGNETON:0",
      "originalSpeciesKey": "MAGNETON:0",
      "trainerId": "ENGINEER:Andrew:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Galvantula": {
    "Pokemonranger M Brandon [Slot 1]": {
      "level": 34,
      "ability": "Unnerve",
      "moves": [
        "Signal Beam",
        "Thunderbolt",
        "Energy Ball",
        "Sticky Web"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 125,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GALVANTULA:0",
      "originalSpeciesKey": "GALVANTULA:0",
      "trainerId": "POKEMONRANGER_M:Brandon:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic F Grunt #5 [Slot 2]": {
      "level": 72,
      "ability": "Unnerve",
      "moves": [
        "Sucker Punch",
        "Bug Buzz",
        "Discharge",
        "Giga Drain"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 281,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GALVANTULA:0",
      "originalSpeciesKey": "GALVANTULA:0",
      "trainerId": "GALACTIC_F:Grunt:20",
      "slot": 2,
      "doubles": false
    }
  },
  "Tauros [Paldean (Aqua Breed)]": {
    "Pokemonranger M Brandon [Slot 2]": {
      "level": 34,
      "ability": "Intimidate",
      "moves": [
        "Aqua Jet",
        "Reversal",
        "Raging Bull",
        "Zen Headbutt"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 125,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TAUROS:3",
      "originalSpeciesKey": "TAUROS:3",
      "trainerId": "POKEMONRANGER_M:Brandon:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Dewott": {
    "Pokemonranger M Brandon [Slot 3]": {
      "level": 35,
      "ability": "Defiant",
      "moves": [
        "Aqua Jet",
        "Liquidation",
        "Retaliate",
        "Knock Off"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 125,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DEWOTT:0",
      "originalSpeciesKey": "DEWOTT:0",
      "trainerId": "POKEMONRANGER_M:Brandon:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Clodsire": {
    "Pokemonranger M Brandon [Slot 4]": {
      "level": 36,
      "ability": "Poison Point",
      "moves": [
        "Poison Jab",
        "Stomping Tantrum",
        "Chilling Water",
        "Recover"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 125,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CLODSIRE:0",
      "originalSpeciesKey": "CLODSIRE:1",
      "trainerId": "POKEMONRANGER_M:Brandon:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Bronzong": {
    "Tamer Vincent [Slot 1]": {
      "level": 34,
      "ability": "Levitate",
      "moves": [
        "Iron Head",
        "Extrasensory",
        "Future Sight",
        "Earthquake"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 126,
      "gender": "",
      "shiny": false,
      "speciesKey": "BRONZONG:0",
      "originalSpeciesKey": "BRONZONG:0",
      "trainerId": "TAMER:Vincent:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic Commander Mars [Slot 3]": {
      "level": 37,
      "ability": "Heatproof",
      "moves": [
        "Psychic",
        "Gyro Ball",
        "Shadow Ball",
        "Grass Knot"
      ],
      "nature": "Modest",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 132,
      "gender": "",
      "shiny": false,
      "speciesKey": "BRONZONG:0",
      "originalSpeciesKey": "BRONZONG:0",
      "trainerId": "MARS:Mars:0",
      "slot": 3,
      "doubles": false
    },
    "Ruinmaniac Warren [Slot 2]": {
      "level": 47,
      "ability": "Heavy Metal",
      "moves": [
        "Heavy Slam",
        "Future Sight",
        "Weather Ball",
        "Rain Dance"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 172,
      "gender": "",
      "shiny": false,
      "speciesKey": "BRONZONG:0",
      "originalSpeciesKey": "BRONZONG:0",
      "trainerId": "RUINMANIAC:Warren:0",
      "slot": 2,
      "doubles": false
    },
    "Engineer Braven [Slot 1]": {
      "level": 53,
      "ability": "Levitate",
      "moves": [
        "Gyro Ball",
        "Future Sight",
        "Explosion",
        "Trick Room"
      ],
      "nature": "Brave",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 215,
      "gender": "",
      "shiny": false,
      "speciesKey": "BRONZONG:0",
      "originalSpeciesKey": "BRONZONG:0",
      "trainerId": "ENGINEER:Braven:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Forrest (DOUBLES) [Slot 5]": {
      "level": 69,
      "ability": "Levitate",
      "moves": [
        "Heavy Slam",
        "Body Press",
        "Metal Sound",
        "Trick Room"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 263,
      "gender": "",
      "shiny": false,
      "speciesKey": "BRONZONG:0",
      "originalSpeciesKey": "BRONZONG:0",
      "trainerId": "COOLTRAINER_M:Forrest:0",
      "slot": 5,
      "doubles": true
    }
  },
  "Cacturne": {
    "Tamer Vincent [Slot 3]": {
      "level": 36,
      "ability": "Water Absorb",
      "moves": [
        "Sucker Punch",
        "Mega Drain",
        "Earth Power",
        "Dark Pulse"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 126,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CACTURNE:0",
      "originalSpeciesKey": "CACTURNE:0",
      "trainerId": "TAMER:Vincent:0",
      "slot": 3,
      "doubles": false
    },
    "Hiker Hubert [Slot 2]": {
      "level": 53,
      "ability": "Sand Force",
      "moves": [
        "Sucker Punch",
        "Giga Drain",
        "Earth Power",
        "Dark Pulse"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 217,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CACTURNE:0",
      "originalSpeciesKey": "CACTURNE:0",
      "trainerId": "HIKER:Hubert:0",
      "slot": 2,
      "doubles": false
    },
    "Hiker Ray [Slot 3]": {
      "level": 64,
      "ability": "Sand Force",
      "moves": [
        "Giga Drain",
        "Throat Chop",
        "Dark Pulse",
        "Earth Power"
      ],
      "nature": "Serious",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 233,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CACTURNE:0",
      "originalSpeciesKey": "CACTURNE:0",
      "trainerId": "HIKER:Ray:0",
      "slot": 3,
      "doubles": false
    },
    "Hiker Kipp [Slot 2]": {
      "level": 66,
      "ability": "Sand Veil",
      "moves": [
        "Seed Bomb",
        "Payback",
        "Earth Power",
        "Substitute"
      ],
      "nature": "Adamant",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 238,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CACTURNE:0",
      "originalSpeciesKey": "CACTURNE:0",
      "trainerId": "HIKER:Kipp:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Drednaw": {
    "Galactic M Grunt #4 [Slot 1]": {
      "level": 34,
      "ability": "Shell Armor",
      "moves": [
        "Stealth Rock",
        "Liquidation",
        "Rock Tomb",
        "Ice Fang"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 128,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DREDNAW:0",
      "originalSpeciesKey": "DREDNAW:0",
      "trainerId": "GALACTIC_M:Grunt:3",
      "slot": 1,
      "doubles": false
    }
  },
  "Morgrem": {
    "Galactic M Grunt #4 [Slot 2]": {
      "level": 35,
      "ability": "Prankster",
      "moves": [
        "Assurance",
        "Play Rough",
        "Thunder Wave",
        "Parting Shot"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 128,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MORGREM:0",
      "originalSpeciesKey": "MORGREM:0",
      "trainerId": "GALACTIC_M:Grunt:3",
      "slot": 2,
      "doubles": false
    }
  },
  "Toxtricity": {
    "Galactic M Grunt #4 [Slot 3]": {
      "level": 36,
      "ability": "Punk Rock",
      "moves": [
        "Discharge",
        "Sludge Bomb",
        "Hex",
        "Tearful Look"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 128,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOXTRICITY:0",
      "originalSpeciesKey": "TOXTRICITY:0",
      "trainerId": "GALACTIC_M:Grunt:3",
      "slot": 3,
      "doubles": false
    },
    "Galactic M Grunt #16 [Slot 2]": {
      "level": 72,
      "ability": "Punk Rock",
      "moves": [
        "Overdrive",
        "Sludge Bomb",
        "Boomburst",
        "Noble Roar"
      ],
      "nature": "Timid",
      "item": "Poison Barb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 277,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOXTRICITY:0",
      "originalSpeciesKey": "TOXTRICITY:0",
      "trainerId": "GALACTIC_M:Grunt:16",
      "slot": 2,
      "doubles": false
    }
  },
  "Magmar": {
    "Galactic M Grunt #5 [Slot 1]": {
      "level": 35,
      "ability": "Flame Body",
      "moves": [
        "Lava Plume",
        "Psychic",
        "Scorching Sands",
        "Confuse Ray"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 129,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAGMAR:0",
      "originalSpeciesKey": "MAGMAR:0",
      "trainerId": "GALACTIC_M:Grunt:4",
      "slot": 1,
      "doubles": false
    }
  },
  "Electabuzz": {
    "Galactic M Grunt #5 [Slot 2]": {
      "level": 36,
      "ability": "Static",
      "moves": [
        "Quick Attack",
        "Thunder Punch",
        "Ice Punch",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 129,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ELECTABUZZ:0",
      "originalSpeciesKey": "ELECTABUZZ:0",
      "trainerId": "GALACTIC_M:Grunt:4",
      "slot": 2,
      "doubles": false
    }
  },
  "Lokix": {
    "Galactic M Grunt #6 [Slot 1]": {
      "level": 35,
      "ability": "Swarm",
      "moves": [
        "Lunge",
        "Throat Chop",
        "Bounce",
        "Screech"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 130,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LOKIX:0",
      "originalSpeciesKey": "LOKIX:0",
      "trainerId": "GALACTIC_M:Grunt:5",
      "slot": 1,
      "doubles": false
    }
  },
  "Krokorok": {
    "Galactic M Grunt #6 [Slot 2]": {
      "level": 36,
      "ability": "Intimidate",
      "moves": [
        "Lash Out",
        "Stomping Tantrum",
        "Rock Slide",
        "Swagger [SWAGGER]"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 130,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KROKOROK:0",
      "originalSpeciesKey": "KROKOROK:0",
      "trainerId": "GALACTIC_M:Grunt:5",
      "slot": 2,
      "doubles": false
    },
    "Tamer Felix [Slot 2]": {
      "level": 37,
      "ability": "Intimidate",
      "moves": [
        "High Horsepower",
        "Crunch",
        "Stone Edge",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 136,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KROKOROK:0",
      "originalSpeciesKey": "KROKOROK:0",
      "trainerId": "TAMER:Felix:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Tentacruel": {
    "Galactic M Grunt #7 [Slot 1]": {
      "level": 35,
      "ability": "Liquid Ooze",
      "moves": [
        "Toxic Spikes",
        "Brine",
        "Sludge Bomb",
        "Acid Armor"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 131,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TENTACRUEL:0",
      "originalSpeciesKey": "TENTACRUEL:0",
      "trainerId": "GALACTIC_M:Grunt:6",
      "slot": 1,
      "doubles": false
    },
    "Juggler Mason [Slot 1]": {
      "level": 36,
      "ability": "Clear Body",
      "moves": [
        "Surf",
        "Venoshock",
        "Hex",
        "Toxic"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 137,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TENTACRUEL:0",
      "originalSpeciesKey": "TENTACRUEL:0",
      "trainerId": "JUGGLER:Mason:0",
      "slot": 1,
      "doubles": false
    },
    "Beauty Alina [Slot 1]": {
      "level": 47,
      "ability": "Liquid Ooze",
      "moves": [
        "Toxic Spikes",
        "Scald",
        "Sludge Bomb",
        "Giga Drain"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 183,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TENTACRUEL:0",
      "originalSpeciesKey": "TENTACRUEL:0",
      "trainerId": "BEAUTY:Alina:0",
      "slot": 1,
      "doubles": false
    },
    "Lady Anja [Slot 2]": {
      "level": 67,
      "ability": "Clear Body",
      "moves": [
        "Toxic Spikes",
        "Surf",
        "Poison Jab",
        "Blizzard"
      ],
      "nature": "Sassy",
      "item": "Safety Goggles",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 255,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TENTACRUEL:0",
      "originalSpeciesKey": "TENTACRUEL:0",
      "trainerId": "LADY:Anja:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer M Hawk [Slot 1]": {
      "level": 95,
      "ability": "Liquid Ooze",
      "moves": [
        "Toxic Spikes",
        "Scald",
        "Sludge Bomb",
        "Giga Drain"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 303,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TENTACRUEL:0",
      "originalSpeciesKey": "TENTACRUEL:0",
      "trainerId": "COOLTRAINER_M:Hawk:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Oinkologne [Female]": {
    "Galactic M Grunt #7 [Slot 2]": {
      "level": 36,
      "ability": "Thick Fat",
      "moves": [
        "Headbutt",
        "Play Rough",
        "High Horsepower",
        "Curse"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 131,
      "gender": "F",
      "shiny": false,
      "speciesKey": "OINKOLOGNE:1",
      "originalSpeciesKey": "OINKOLOGNE:1",
      "trainerId": "GALACTIC_M:Grunt:6",
      "slot": 2,
      "doubles": false
    }
  },
  "Venomoth": {
    "Galactic M Grunt #7 [Slot 3]": {
      "level": 36,
      "ability": "Compound Eyes",
      "moves": [
        "Signal Beam",
        "Venoshock",
        "Psychic Noise",
        "Poison Powder"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 131,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VENOMOTH:0",
      "originalSpeciesKey": "VENOMOTH:0",
      "trainerId": "GALACTIC_M:Grunt:6",
      "slot": 3,
      "doubles": false
    },
    "Picnicker Brooke [Slot 3]": {
      "level": 47,
      "ability": "Tinted Lens",
      "moves": [
        "Bug Buzz",
        "Psychic",
        "Sludge Bomb",
        "Sleep Powder"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 173,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VENOMOTH:0",
      "originalSpeciesKey": "VENOMOTH:0",
      "trainerId": "PICNICKER:Brooke:0",
      "slot": 3,
      "doubles": false
    },
    "Aromalady Adelaide [Slot 1]": {
      "level": 56,
      "ability": "Tinted Lens",
      "moves": [
        "Bug Buzz",
        "Psychic",
        "Sludge Bomb",
        "Energy Ball"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 220,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENOMOTH:0",
      "originalSpeciesKey": "VENOMOTH:0",
      "trainerId": "AROMALADY:Adelaide:0",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Aaron #1 [Slot 2]": {
      "level": 99,
      "ability": "Compound Eyes",
      "moves": [
        "Bug Buzz",
        "Psychic",
        "Sleep Powder"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 314,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENOMOTH:0",
      "originalSpeciesKey": "VENOMOTH:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:0",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Aaron #2 (DOUBLES) [Slot 1]": {
      "level": 99,
      "ability": "Compound Eyes",
      "moves": [
        "Bug Buzz",
        "Psychic",
        "Sleep Powder"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 315,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENOMOTH:0",
      "originalSpeciesKey": "VENOMOTH:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:1",
      "slot": 1,
      "doubles": true
    }
  },
  "Arcanine": {
    "Galactic M Grunt #7 [Slot 4]": {
      "level": 37,
      "ability": "Intimidate",
      "moves": [
        "Flamethrower",
        "Wild Charge",
        "Scorching Sands",
        "Roar"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 131,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ARCANINE:0",
      "originalSpeciesKey": "ARCANINE:0",
      "trainerId": "GALACTIC_M:Grunt:6",
      "slot": 4,
      "doubles": false
    },
    "Hiker Doyle [Slot 2]": {
      "level": 68,
      "ability": "Intimidate",
      "moves": [
        "Flare Blitz",
        "Wild Charge",
        "Close Combat",
        "Howl"
      ],
      "nature": "Jolly",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 248,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARCANINE:0",
      "originalSpeciesKey": "ARCANINE:0",
      "trainerId": "HIKER:Doyle:0",
      "slot": 2,
      "doubles": false
    },
    "Burglar Rocko [Slot 3]": {
      "level": 70,
      "ability": "Intimidate",
      "moves": [
        "Extreme Speed",
        "Burn Up",
        "Flare Blitz",
        "Close Combat"
      ],
      "nature": "Hasty",
      "item": "Fire Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 265,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARCANINE:0",
      "originalSpeciesKey": "ARCANINE:0",
      "trainerId": "BURGLAR:Rocko:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic D Grunt & Grunt (DOUBLES) [Slot 2]": {
      "level": 49,
      "ability": "Intimidate",
      "moves": [
        "Extreme Speed",
        "Heat Wave",
        "Wild Charge",
        "Close Combat"
      ],
      "nature": "Hasty",
      "item": "Covert Cloak",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 204,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARCANINE:0",
      "originalSpeciesKey": "ARCANINE:0",
      "trainerId": "GALACTIC_D:Grunt & Grunt:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Vikavolt": {
    "Galactic Commander Mars [Slot 1]": {
      "level": 37,
      "ability": "Levitate",
      "moves": [
        "Bug Buzz",
        "Discharge",
        "Energy Ball",
        "Sticky Web"
      ],
      "nature": "Sassy",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 132,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VIKAVOLT:0",
      "originalSpeciesKey": "VIKAVOLT:0",
      "trainerId": "MARS:Mars:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic M Grunt #9 [Slot 3]": {
      "level": 50,
      "ability": "Levitate",
      "moves": [
        "Bug Buzz",
        "Discharge",
        "Energy Ball",
        "Volt Switch"
      ],
      "nature": "Modest",
      "item": "Magnet",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 206,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VIKAVOLT:0",
      "originalSpeciesKey": "VIKAVOLT:0",
      "trainerId": "GALACTIC_M:Grunt:8",
      "slot": 3,
      "doubles": false
    }
  },
  "Crobat": {
    "Galactic Commander Mars [Slot 2]": {
      "level": 37,
      "ability": "Inner Focus",
      "moves": [
        "Sludge Bomb",
        "Air Slash",
        "Leech Life"
      ],
      "nature": "Naive",
      "item": "Poison Barb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 132,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CROBAT:0",
      "originalSpeciesKey": "CROBAT:0",
      "trainerId": "MARS:Mars:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Koga #1 [Slot 1]": {
      "level": 39,
      "ability": "Sniper",
      "moves": [
        "Sludge Bomb",
        "Giga Drain",
        "Nasty Plot",
        "Hypnosis"
      ],
      "nature": "Timid",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 139,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CROBAT:0",
      "originalSpeciesKey": "CROBAT:0",
      "trainerId": "LEADER_Koga:Koga:0",
      "slot": 1,
      "doubles": false
    },
    "Gym Leader Koga #2 (DOUBLES) [Slot 1]": {
      "level": 39,
      "ability": "Sniper",
      "moves": [
        "Sludge Bomb",
        "Giga Drain",
        "Nasty Plot",
        "Hypnosis"
      ],
      "nature": "Timid",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 140,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CROBAT:0",
      "originalSpeciesKey": "CROBAT:0",
      "trainerId": "LEADER_Koga:Koga:1",
      "slot": 1,
      "doubles": true
    },
    "Juggler Santino [Slot 2]": {
      "level": 66,
      "ability": "Shadow Tag",
      "moves": [
        "Cross Poison",
        "Leech Life",
        "Sludge Bomb",
        "Brave Bird"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 249,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CROBAT:0",
      "originalSpeciesKey": "CROBAT:0",
      "trainerId": "JUGGLER:Santino:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #13 [Slot 2]": {
      "level": 72,
      "ability": "Inner Focus",
      "moves": [
        "Cross Poison",
        "Brave Bird",
        "Heat Wave",
        "Giga Drain"
      ],
      "nature": "Naive",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 273,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CROBAT:0",
      "originalSpeciesKey": "CROBAT:0",
      "trainerId": "GALACTIC_M:Grunt:12",
      "slot": 2,
      "doubles": false
    }
  },
  "Orthworm": {
    "Galactic Commander Mars [Slot 5]": {
      "level": 37,
      "ability": "Earth Eater",
      "moves": [
        "Iron Head",
        "Body Press",
        "Shed Tail"
      ],
      "nature": "Impish",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 132,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORTHWORM:0",
      "originalSpeciesKey": "ORTHWORM:0",
      "trainerId": "MARS:Mars:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Purugly": {
    "Galactic Commander Mars [Slot 6]": {
      "level": 38,
      "ability": "Defiant",
      "moves": [
        "Body Slam",
        "Play Rough",
        "Shadow Claw",
        "(No Move)"
      ],
      "nature": "Adamant",
      "item": "Silk Scarf",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 132,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PURUGLY:0",
      "originalSpeciesKey": "PURUGLY:0",
      "trainerId": "MARS:Mars:0",
      "slot": 6,
      "doubles": false
    },
    "Beauty Alina [Slot 3]": {
      "level": 49,
      "ability": "Thick Fat",
      "moves": [
        "Fake Out",
        "Body Slam",
        "Play Rough",
        "Shadow Claw"
      ],
      "nature": "Adamant",
      "item": "Silk Scarf",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 183,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PURUGLY:0",
      "originalSpeciesKey": "PURUGLY:0",
      "trainerId": "BEAUTY:Alina:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Nidorino": {
    "Juggler Dalton [Slot 1]": {
      "level": 36,
      "ability": "Poison Point",
      "moves": [
        "Sludge Bomb",
        "Earth Power",
        "Ice Beam",
        "Venom Drench"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 133,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NIDORINO:0",
      "originalSpeciesKey": "NIDORINO:0",
      "trainerId": "JUGGLER:Dalton:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Revavroom": {
    "Juggler Dalton [Slot 3]": {
      "level": 37,
      "ability": "Filter",
      "moves": [
        "Iron Head",
        "Poison Jab",
        "High Horsepower",
        "Magnet Rise"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 133,
      "gender": "M",
      "shiny": false,
      "speciesKey": "REVAVROOM:0",
      "originalSpeciesKey": "REVAVROOM:0",
      "trainerId": "JUGGLER:Dalton:0",
      "slot": 3,
      "doubles": false
    },
    "Engineer Braven [Slot 2]": {
      "level": 53,
      "ability": "Filter",
      "moves": [
        "Hard Press",
        "Poison Jab",
        "Lash Out",
        "Overheat"
      ],
      "nature": "Brave",
      "item": "Air Balloon",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 0
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 215,
      "gender": "F",
      "shiny": false,
      "speciesKey": "REVAVROOM:0",
      "originalSpeciesKey": "REVAVROOM:0",
      "trainerId": "ENGINEER:Braven:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Nidorina": {
    "Juggler Kirk [Slot 1]": {
      "level": 36,
      "ability": "Poison Point",
      "moves": [
        "Toxic Spikes",
        "Poison Jab",
        "Stomping Tantrum",
        "Crunch"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 134,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NIDORINA:0",
      "originalSpeciesKey": "NIDORINA:0",
      "trainerId": "JUGGLER:Kirk:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Weezing": {
    "Juggler Kirk [Slot 2]": {
      "level": 36,
      "ability": "Levitate",
      "moves": [
        "Venoshock",
        "Sludge Bomb",
        "Flamethrower",
        "Explosion"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 134,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WEEZING:0",
      "originalSpeciesKey": "WEEZING:0",
      "trainerId": "JUGGLER:Kirk:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Toxapex": {
    "Juggler Kirk [Slot 3]": {
      "level": 37,
      "ability": "Merciless",
      "moves": [
        "Venoshock",
        "Muddy Water",
        "Infestation",
        "Baneful Bunker"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 134,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TOXAPEX:0",
      "originalSpeciesKey": "TOXAPEX:0",
      "trainerId": "JUGGLER:Kirk:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Shiftry": {
    "Tamer Edgar [Slot 1]": {
      "level": 36,
      "ability": "Early Bird",
      "moves": [
        "Extrasensory",
        "Energy Ball",
        "Foul Play",
        "Swagger [SWAGGER]"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 135,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SHIFTRY:0",
      "originalSpeciesKey": "SHIFTRY:0",
      "trainerId": "TAMER:Edgar:0",
      "slot": 1,
      "doubles": false
    },
    "Juggler Neil [Slot 1]": {
      "level": 38,
      "ability": "Pickpocket",
      "moves": [
        "Leaf Blade",
        "Knock Off",
        "Low Kick",
        "Tailwind"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 145,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SHIFTRY:0",
      "originalSpeciesKey": "SHIFTRY:0",
      "trainerId": "JUGGLER:Neil:0",
      "slot": 1,
      "doubles": false
    },
    "Juggler Santino [Slot 4]": {
      "level": 68,
      "ability": "Chlorophyll",
      "moves": [
        "Energy Ball",
        "Sucker Punch",
        "Night Slash",
        "Solar Blade"
      ],
      "nature": "Serious",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 249,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SHIFTRY:0",
      "originalSpeciesKey": "SHIFTRY:0",
      "trainerId": "JUGGLER:Santino:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Linoone [Galarian]": {
    "Tamer Edgar [Slot 3]": {
      "level": 37,
      "ability": "Gluttony",
      "moves": [
        "Snarl",
        "Hyper Voice",
        "Thunder Wave",
        "Trick"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 135,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LINOONE:1",
      "originalSpeciesKey": "LINOONE:1",
      "trainerId": "TAMER:Edgar:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Liepard": {
    "Tamer Felix [Slot 1]": {
      "level": 36,
      "ability": "Prankster",
      "moves": [
        "Fake Out",
        "Assist"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 136,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LIEPARD:0",
      "originalSpeciesKey": "LIEPARD:0",
      "trainerId": "TAMER:Felix:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Stanley (DOUBLES) [Slot 3]": {
      "level": 68,
      "ability": "Prankster",
      "moves": [
        "Fake Out",
        "Assurance",
        "Psycho Cut",
        "Fake Tears"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 262,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LIEPARD:0",
      "originalSpeciesKey": "LIEPARD:0",
      "trainerId": "COOLTRAINER_M:Stanley:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Persian [Alolan]": {
    "Tamer Felix [Slot 3]": {
      "level": 37,
      "ability": "Fur Coat",
      "moves": [
        "Dark Pulse",
        "Power Gem",
        "Burning Jealousy",
        "Nasty Plot"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 136,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PERSIAN:1",
      "originalSpeciesKey": "PERSIAN:1",
      "trainerId": "TAMER:Felix:0",
      "slot": 3,
      "doubles": false
    },
    "Channeler Agatha (DOUBLES) [Slot 2]": {
      "level": 40,
      "ability": "Technician",
      "moves": [
        "Snarl",
        "Shock Wave",
        "Icy Wind",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 151,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PERSIAN:1",
      "originalSpeciesKey": "PERSIAN:1",
      "trainerId": "CHANNELER:Agatha:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Sharpedo": {
    "Tamer Felix [Slot 4]": {
      "level": 38,
      "ability": "Speed Boost",
      "moves": [
        "Aqua Jet",
        "Waterfall",
        "Crunch",
        "Poison Fang"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 136,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SHARPEDO:0",
      "originalSpeciesKey": "SHARPEDO:0",
      "trainerId": "TAMER:Felix:0",
      "slot": 4,
      "doubles": false
    },
    "Swimmer2 M Dean [Slot 2]": {
      "level": 45,
      "ability": "Rough Skin",
      "moves": [
        "Surf",
        "Crunch",
        "Dark Pulse",
        "Psychic Fangs"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 162,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SHARPEDO:0",
      "originalSpeciesKey": "SHARPEDO:0",
      "trainerId": "SWIMMER2_M:Dean:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Seviper": {
    "Juggler Mason [Slot 2]": {
      "level": 37,
      "ability": "Shed Skin",
      "moves": [
        "Poison Tail",
        "Power Whip",
        "Reversal",
        "Rest"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 137,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SEVIPER:0",
      "originalSpeciesKey": "SEVIPER:0",
      "trainerId": "JUGGLER:Mason:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Venusaur": {
    "Juggler Mason [Slot 3]": {
      "level": 38,
      "ability": "Thick Fat",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Leech Seed",
        "Protect"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 137,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENUSAUR:0",
      "originalSpeciesKey": "VENUSAUR:0",
      "trainerId": "JUGGLER:Mason:0",
      "slot": 3,
      "doubles": false
    },
    "Picnicker Mia [Slot 2]": {
      "level": 46,
      "ability": "Chlorophyll",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Leech Seed",
        "Protect"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 163,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENUSAUR:0",
      "originalSpeciesKey": "VENUSAUR:0",
      "trainerId": "PICNICKER:Mia:0",
      "slot": 2,
      "doubles": false
    },
    "Pokemonranger M Enzio [Slot 1]": {
      "level": 68,
      "ability": "Chlorophyll",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Earthquake",
        "Weather Ball"
      ],
      "nature": "Naughty",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 251,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENUSAUR:0",
      "originalSpeciesKey": "VENUSAUR:0",
      "trainerId": "POKEMONRANGER_M:Enzio:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Chalina (DOUBLES) [Slot 3]": {
      "level": 96,
      "ability": "Chlorophyll",
      "moves": [
        "Solar Beam",
        "Earth Power",
        "Weather Ball",
        "Growth"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 307,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VENUSAUR:0",
      "originalSpeciesKey": "VENUSAUR:0",
      "trainerId": "COOLTRAINER_F:Chalina:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Ariados": {
    "Juggler Shawn [Slot 1]": {
      "level": 36,
      "ability": "Swarm",
      "moves": [
        "Shadow Sneak",
        "Bug Bite",
        "Infestation",
        "Toxic"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 138,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ARIADOS:0",
      "originalSpeciesKey": "ARIADOS:0",
      "trainerId": "JUGGLER:Shawn:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Amoonguss": {
    "Juggler Shawn [Slot 3]": {
      "level": 37,
      "ability": "Effect Spore",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Hex",
        "Spore"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 138,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AMOONGUSS:0",
      "originalSpeciesKey": "AMOONGUSS:0",
      "trainerId": "JUGGLER:Shawn:0",
      "slot": 3,
      "doubles": false
    },
    "Rocker Joey [Slot 3]": {
      "level": 48,
      "ability": "Effect Spore",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Growth",
        "Spore"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 188,
      "gender": "F",
      "shiny": false,
      "speciesKey": "AMOONGUSS:0",
      "originalSpeciesKey": "AMOONGUSS:0",
      "trainerId": "ROCKER:Joey:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Salazzle": {
    "Juggler Shawn [Slot 4]": {
      "level": 38,
      "ability": "Corrosion",
      "moves": [
        "Venoshock",
        "Incinerate",
        "Dragon Pulse",
        "Nasty Plot"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 138,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SALAZZLE:0",
      "originalSpeciesKey": "SALAZZLE:0",
      "trainerId": "JUGGLER:Shawn:0",
      "slot": 4,
      "doubles": false
    },
    "Burglar Gilligan [Slot 3]": {
      "level": 70,
      "ability": "Corrosion",
      "moves": [
        "Sludge Bomb",
        "Fire Blast",
        "Dragon Pulse"
      ],
      "nature": "Modest",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 269,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SALAZZLE:0",
      "originalSpeciesKey": "SALAZZLE:0",
      "trainerId": "BURGLAR:Gilligan:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Krookodile": {
    "Gym Leader Koga #1 [Slot 3]": {
      "level": 39,
      "ability": "Intimidate",
      "moves": [
        "Earthquake",
        "Knock Off",
        "Close Combat"
      ],
      "nature": "Adamant",
      "item": "Salac Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 139,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KROOKODILE:0",
      "originalSpeciesKey": "KROOKODILE:0",
      "trainerId": "LEADER_Koga:Koga:0",
      "slot": 3,
      "doubles": false
    },
    "Gym Leader Koga #2 (DOUBLES) [Slot 3]": {
      "level": 39,
      "ability": "Intimidate",
      "moves": [
        "High Horsepower",
        "Crunch",
        "Close Combat"
      ],
      "nature": "Adamant",
      "item": "Salac Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 140,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KROOKODILE:0",
      "originalSpeciesKey": "KROOKODILE:0",
      "trainerId": "LEADER_Koga:Koga:1",
      "slot": 3,
      "doubles": true
    },
    "Hiker Hubert [Slot 4]": {
      "level": 54,
      "ability": "Intimidate",
      "moves": [
        "Earthquake",
        "Power Trip",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "Weakness Policy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 217,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KROOKODILE:0",
      "originalSpeciesKey": "KROOKODILE:0",
      "trainerId": "HIKER:Hubert:0",
      "slot": 4,
      "doubles": false
    },
    "Ruinmaniac Roonie [Slot 4]": {
      "level": 67,
      "ability": "Moxie",
      "moves": [
        "Earthquake",
        "Knock Off",
        "Scale Shot",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 244,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KROOKODILE:0",
      "originalSpeciesKey": "KROOKODILE:0",
      "trainerId": "RUINMANIAC:Roonie:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Sneasler": {
    "Gym Leader Koga #1 [Slot 4]": {
      "level": 39,
      "ability": "Inner Focus",
      "moves": [
        "Brick Break",
        "Poison Jab",
        "Throat Chop"
      ],
      "nature": "Jolly",
      "item": "Chesto Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 139,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SNEASLER:0",
      "originalSpeciesKey": "SNEASLER:1",
      "trainerId": "LEADER_Koga:Koga:0",
      "slot": 4,
      "doubles": false
    },
    "Gym Leader Koga #2 (DOUBLES) [Slot 4]": {
      "level": 39,
      "ability": "Inner Focus",
      "moves": [
        "Brick Break",
        "Poison Jab",
        "Throat Chop"
      ],
      "nature": "Jolly",
      "item": "Chesto Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 140,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SNEASLER:0",
      "originalSpeciesKey": "SNEASLER:1",
      "trainerId": "LEADER_Koga:Koga:1",
      "slot": 4,
      "doubles": true
    },
    "Ace Trainer Wesley (DOUBLES) [Slot 3]": {
      "level": 68,
      "ability": "Inner Focus",
      "moves": [
        "Close Combat",
        "Gunk Shot",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 239,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SNEASLER:0",
      "originalSpeciesKey": "SNEASLER:1",
      "trainerId": "COOLTRAINER_M:Wesley:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Greninja": {
    "Gym Leader Koga #1 [Slot 5]": {
      "level": 39,
      "ability": "Protean",
      "moves": [
        "Water Shuriken",
        "Ice Beam",
        "Dark Pulse",
        "Extrasensory"
      ],
      "nature": "Timid",
      "item": "Mystic Water",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 139,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRENINJA:0",
      "originalSpeciesKey": "GRENINJA:0",
      "trainerId": "LEADER_Koga:Koga:0",
      "slot": 5,
      "doubles": false
    },
    "Gym Leader Koga #2 (DOUBLES) [Slot 5]": {
      "level": 39,
      "ability": "Protean",
      "moves": [
        "Water Shuriken",
        "Ice Beam",
        "Dark Pulse",
        "Extrasensory"
      ],
      "nature": "Timid",
      "item": "Mystic Water",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 140,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRENINJA:0",
      "originalSpeciesKey": "GRENINJA:0",
      "trainerId": "LEADER_Koga:Koga:1",
      "slot": 5,
      "doubles": true
    },
    "Beauty Jenn [Slot 1]": {
      "level": 68,
      "ability": "Protean",
      "moves": [
        "Water Shuriken",
        "Hydro Pump",
        "Blizzard",
        "Low Kick"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 258,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRENINJA:0",
      "originalSpeciesKey": "GRENINJA:0",
      "trainerId": "BEAUTY:Jenn:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Beedrill [Mega Beedrill]": {
    "Gym Leader Koga #1 [Slot 6]": {
      "level": 40,
      "ability": "Adaptability",
      "moves": [
        "U-turn",
        "Poison Jab",
        "Pursuit"
      ],
      "nature": "Adamant",
      "item": "Beedrillite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 139,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BEEDRILL:1",
      "originalSpeciesKey": "BEEDRILL:0",
      "trainerId": "LEADER_Koga:Koga:0",
      "slot": 6,
      "doubles": false
    },
    "Gym Leader Koga #2 (DOUBLES) [Slot 6]": {
      "level": 40,
      "ability": "Adaptability",
      "moves": [
        "X-Scissor",
        "Poison Jab",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "Beedrillite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 140,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BEEDRILL:1",
      "originalSpeciesKey": "BEEDRILL:0",
      "trainerId": "LEADER_Koga:Koga:1",
      "slot": 6,
      "doubles": true
    },
    "Cooltrainer M Julian [Slot 5]": {
      "level": 49,
      "ability": "Adaptability",
      "moves": [
        "Bug Bite",
        "Cross Poison",
        "Drill Peck",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Beedrillite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 182,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BEEDRILL:1",
      "originalSpeciesKey": "BEEDRILL:0",
      "trainerId": "COOLTRAINER_M:Julian:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Chansey": {
    "Picnicker Sophie [Slot 2]": {
      "level": 40,
      "ability": "Natural Cure",
      "moves": [
        "Seismic Toss",
        "Toxic",
        "Soft-Boiled",
        "Protect"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 141,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CHANSEY:0",
      "originalSpeciesKey": "CHANSEY:0",
      "trainerId": "PICNICKER:Sophie:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Wigglytuff": {
    "Picnicker Lily [Slot 1]": {
      "level": 39,
      "ability": "Competitive",
      "moves": [
        "Hyper Voice",
        "Moonblast",
        "Flamethrower",
        "Thunderbolt"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 142,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WIGGLYTUFF:0",
      "originalSpeciesKey": "WIGGLYTUFF:0",
      "trainerId": "PICNICKER:Lily:0",
      "slot": 1,
      "doubles": false
    },
    "Picnicker Hailey [Slot 3]": {
      "level": 47,
      "ability": "Competitive",
      "moves": [
        "Hyper Voice",
        "Moonblast",
        "Focus Blast",
        "Calm Mind"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 168,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WIGGLYTUFF:0",
      "originalSpeciesKey": "WIGGLYTUFF:0",
      "trainerId": "PICNICKER:Hailey:0",
      "slot": 3,
      "doubles": false
    },
    "Ace Trainer Niel (DOUBLES) [Slot 2]": {
      "level": 79,
      "ability": "Sheer Force",
      "moves": [
        "Moonblast",
        "Flamethrower",
        "Dark Pulse",
        "Thunder"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 289,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WIGGLYTUFF:0",
      "originalSpeciesKey": "WIGGLYTUFF:0",
      "trainerId": "COOLTRAINER_M:Niel:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Parasect": {
    "Picnicker Lily [Slot 2]": {
      "level": 40,
      "ability": "Effect Spore",
      "moves": [
        "Leech Life",
        "Leaf Blade",
        "Cross Poison",
        "Spore"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 142,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PARASECT:0",
      "originalSpeciesKey": "PARASECT:0",
      "trainerId": "PICNICKER:Lily:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #20 [Slot 2]": {
      "level": 74,
      "ability": "Dry Skin",
      "moves": [
        "Leech Life",
        "Knock Off",
        "Double Team"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 284,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PARASECT:0",
      "originalSpeciesKey": "PARASECT:0",
      "trainerId": "GALACTIC_M:Grunt:23",
      "slot": 2,
      "doubles": false
    }
  },
  "Raichu": {
    "Rocker Axel [Slot 1]": {
      "level": 38,
      "ability": "Static",
      "moves": [
        "Extreme Speed",
        "Discharge",
        "Surf",
        "Nasty Plot"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 143,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RAICHU:0",
      "originalSpeciesKey": "RAICHU:0",
      "trainerId": "ROCKER:Axel:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic Commander Saturn #1 (DOUBLES) [Slot 2]": {
      "level": 51,
      "ability": "Lightning Rod",
      "moves": [
        "Fake Out",
        "Thunderbolt",
        "Grass Knot",
        "Helping Hand"
      ],
      "nature": "Modest",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 209,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RAICHU:0",
      "originalSpeciesKey": "RAICHU:0",
      "trainerId": "SATURN:Saturn:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Cinccino": {
    "Rocker Axel [Slot 3]": {
      "level": 40,
      "ability": "Skill Link",
      "moves": [
        "Tail Slap",
        "Bullet Seed",
        "Rock Blast",
        "Triple Axel"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 143,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CINCCINO:0",
      "originalSpeciesKey": "CINCCINO:0",
      "trainerId": "ROCKER:Axel:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic M Grunt #9 [Slot 2]": {
      "level": 49,
      "ability": "Skill Link",
      "moves": [
        "Tail Slap",
        "Triple Axel",
        "Rock Blast",
        "Bullet Seed"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 206,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CINCCINO:0",
      "originalSpeciesKey": "CINCCINO:0",
      "trainerId": "GALACTIC_M:Grunt:8",
      "slot": 2,
      "doubles": false
    }
  },
  "Beartic": {
    "Blackbelt Thorsten [Slot 1]": {
      "level": 39,
      "ability": "Swift Swim",
      "moves": [
        "Aqua Jet",
        "Icicle Crash",
        "Close Combat",
        "Earthquake"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 144,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BEARTIC:0",
      "originalSpeciesKey": "BEARTIC:0",
      "trainerId": "BLACKBELT:Thorsten:0",
      "slot": 1,
      "doubles": false
    },
    "Lady Tami [Slot 3]": {
      "level": 68,
      "ability": "Slush Rush",
      "moves": [
        "Aqua Jet",
        "Icicle Spear",
        "Superpower",
        "Rock Slide"
      ],
      "nature": "Adamant",
      "item": "White Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 254,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BEARTIC:0",
      "originalSpeciesKey": "BEARTIC:0",
      "trainerId": "LADY:Tami:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Hawlucha": {
    "Blackbelt Thorsten [Slot 2]": {
      "level": 40,
      "ability": "Limber",
      "moves": [
        "Flying Press",
        "Dual Wingbeat",
        "Throat Chop",
        "Me First"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 144,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HAWLUCHA:0",
      "originalSpeciesKey": "HAWLUCHA:0",
      "trainerId": "BLACKBELT:Thorsten:0",
      "slot": 2,
      "doubles": false
    },
    "Cynthia Cynthia #1 [Slot 4]": {
      "level": 100,
      "ability": "Unburden",
      "moves": [
        "Close Combat",
        "Dual Wingbeat",
        "Swords Dance",
        "Stone Edge"
      ],
      "nature": "Adamant",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 318,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HAWLUCHA:0",
      "originalSpeciesKey": "HAWLUCHA:0",
      "trainerId": "CYNTHIA:Cynthia:0",
      "slot": 4,
      "doubles": false
    },
    "Cynthia Cynthia #2 (DOUBLES) [Slot 4]": {
      "level": 100,
      "ability": "Unburden",
      "moves": [
        "Close Combat",
        "Dual Wingbeat",
        "Swords Dance",
        "Stone Edge"
      ],
      "nature": "Adamant",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 319,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HAWLUCHA:0",
      "originalSpeciesKey": "HAWLUCHA:0",
      "trainerId": "CYNTHIA:Cynthia:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Swellow": {
    "Juggler Neil [Slot 2]": {
      "level": 39,
      "ability": "Guts",
      "moves": [
        "Double-Edge",
        "Air Slash",
        "Steel Wing",
        "Roost"
      ],
      "nature": "Rash",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 145,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SWELLOW:0",
      "originalSpeciesKey": "SWELLOW:0",
      "trainerId": "JUGGLER:Neil:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer M Miguel [Slot 1]": {
      "level": 94,
      "ability": "Scrappy",
      "moves": [
        "Boomburst",
        "Brave Bird",
        "Heat Wave",
        "U-turn"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 300,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SWELLOW:0",
      "originalSpeciesKey": "SWELLOW:0",
      "trainerId": "COOLTRAINER_M:Miguel:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Persian": {
    "Juggler Neil [Slot 3]": {
      "level": 40,
      "ability": "Unnerve",
      "moves": [
        "Hyper Voice",
        "Shadow Ball",
        "Thunderbolt",
        "U-turn"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 145,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PERSIAN:0",
      "originalSpeciesKey": "PERSIAN:0",
      "trainerId": "JUGGLER:Neil:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Golurk": {
    "Channeler Ruth [Slot 2]": {
      "level": 40,
      "ability": "Iron Fist",
      "moves": [
        "Shadow Punch",
        "Mega Punch",
        "Thunder Punch",
        "Confuse Ray"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 146,
      "gender": "",
      "shiny": false,
      "speciesKey": "GOLURK:0",
      "originalSpeciesKey": "GOLURK:0",
      "trainerId": "CHANNELER:Ruth:0",
      "slot": 2,
      "doubles": false
    },
    "Hiker Jared [Slot 2]": {
      "level": 58,
      "ability": "No Guard",
      "moves": [
        "Earthquake",
        "Stone Edge",
        "Mega Kick",
        "Dynamic Punch"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 224,
      "gender": "",
      "shiny": false,
      "speciesKey": "GOLURK:0",
      "originalSpeciesKey": "GOLURK:0",
      "trainerId": "HIKER:Jared:0",
      "slot": 2,
      "doubles": false
    },
    "Psychic M Sheldon [Slot 1]": {
      "level": 64,
      "ability": "Iron Fist",
      "moves": [
        "Stealth Rock",
        "Earthquake",
        "Shadow Punch",
        "Drain Punch"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 237,
      "gender": "",
      "shiny": false,
      "speciesKey": "GOLURK:0",
      "originalSpeciesKey": "GOLURK:0",
      "trainerId": "PSYCHIC_M:Sheldon:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Slowbro": {
    "Channeler Ruth [Slot 3]": {
      "level": 41,
      "ability": "Own Tempo",
      "moves": [
        "Scald",
        "Psychic",
        "Flamethrower",
        "Slack Off"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 146,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLOWBRO:0",
      "originalSpeciesKey": "SLOWBRO:0",
      "trainerId": "CHANNELER:Ruth:0",
      "slot": 3,
      "doubles": false
    },
    "Swimmer2 M Dean [Slot 3]": {
      "level": 46,
      "ability": "Oblivious",
      "moves": [
        "Block",
        "Safeguard",
        "Aqua Tail",
        "Surf"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 162,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SLOWBRO:0",
      "originalSpeciesKey": "SLOWBRO:0",
      "trainerId": "SWIMMER2_M:Dean:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Gothitelle": {
    "Channeler Naomi [Slot 2]": {
      "level": 40,
      "ability": "Shadow Tag",
      "moves": [
        "Psyshock",
        "Shadow Ball",
        "Dark Pulse",
        "Calm Mind"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 147,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GOTHITELLE:0",
      "originalSpeciesKey": "GOTHITELLE:0",
      "trainerId": "CHANNELER:Naomi:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Drifblim": {
    "Channeler Naomi [Slot 3]": {
      "level": 41,
      "ability": "Aftermath",
      "moves": [
        "Shadow Ball",
        "Acrobatics",
        "Strength Sap",
        "Disable"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 147,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRIFBLIM:0",
      "originalSpeciesKey": "DRIFBLIM:0",
      "trainerId": "CHANNELER:Naomi:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Houndstone": {
    "Channeler Paula [Slot 3]": {
      "level": 41,
      "ability": "Fluffy",
      "moves": [
        "Last Respects",
        "Play Rough",
        "Crunch",
        "Stomping Tantrum"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 148,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HOUNDSTONE:0",
      "originalSpeciesKey": "HOUNDSTONE:0",
      "trainerId": "CHANNELER:Paula:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Skeledirge": {
    "Channeler Martha (DOUBLES) [Slot 1]": {
      "level": 40,
      "ability": "Unaware",
      "moves": [
        "Torch Song",
        "Hex",
        "Will-O-Wisp",
        "Slack Off"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 149,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SKELEDIRGE:0",
      "originalSpeciesKey": "SKELEDIRGE:0",
      "trainerId": "CHANNELER:Martha:0",
      "slot": 1,
      "doubles": true
    },
    "Ruinmaniac Roonie [Slot 1]": {
      "level": 65,
      "ability": "Unaware",
      "moves": [
        "Flamethrower",
        "Hex",
        "Yawn",
        "Slack Off"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 244,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SKELEDIRGE:0",
      "originalSpeciesKey": "SKELEDIRGE:0",
      "trainerId": "RUINMANIAC:Roonie:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Dusknoir": {
    "Channeler Martha (DOUBLES) [Slot 2]": {
      "level": 40,
      "ability": "Pressure",
      "moves": [
        "Shadow Sneak",
        "Shadow Punch",
        "Dynamic Punch",
        "Will-O-Wisp"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 149,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DUSKNOIR:0",
      "originalSpeciesKey": "DUSKNOIR:0",
      "trainerId": "CHANNELER:Martha:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Umbreon": {
    "Channeler Martha (DOUBLES) [Slot 3]": {
      "level": 41,
      "ability": "Synchronize",
      "moves": [
        "Snarl",
        "Alluring Voice",
        "Toxic",
        "Moonlight"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 149,
      "gender": "M",
      "shiny": false,
      "speciesKey": "UMBREON:0",
      "originalSpeciesKey": "UMBREON:0",
      "trainerId": "CHANNELER:Martha:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Trevenant": {
    "Channeler Martha (DOUBLES) [Slot 4]": {
      "level": 41,
      "ability": "Natural Cure",
      "moves": [
        "Sucker Punch",
        "Shadow Claw",
        "Horn Leech",
        "Will-O-Wisp"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 149,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TREVENANT:0",
      "originalSpeciesKey": "TREVENANT:0",
      "trainerId": "CHANNELER:Martha:0",
      "slot": 4,
      "doubles": true
    },
    "Cooltrainer F Kumiko [Slot 3]": {
      "level": 94,
      "ability": "Harvest",
      "moves": [
        "Poltergeist",
        "Horn Leech",
        "Leech Seed",
        "Substitute"
      ],
      "nature": "Adamant",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 294,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TREVENANT:0",
      "originalSpeciesKey": "TREVENANT:0",
      "trainerId": "COOLTRAINER_F:Kumiko:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Gengar": {
    "Cooltrainer M Travis [Slot 1]": {
      "level": 40,
      "ability": "Levitate",
      "moves": [
        "Toxic Spikes",
        "Shadow Ball",
        "Dazzling Gleam",
        "Confuse Ray"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 156,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GENGAR:0",
      "originalSpeciesKey": "GENGAR:0",
      "trainerId": "COOLTRAINER_M:Travis:0",
      "slot": 1,
      "doubles": false
    },
    "Channeler Evelyn (DOUBLES) [Slot 1]": {
      "level": 40,
      "ability": "Levitate",
      "moves": [
        "Hex",
        "Dream Eater",
        "Substitute",
        "Hypnosis"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 150,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GENGAR:0",
      "originalSpeciesKey": "GENGAR:0",
      "trainerId": "CHANNELER:Evelyn:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Spiritomb": {
    "Channeler Evelyn (DOUBLES) [Slot 3]": {
      "level": 41,
      "ability": "Pressure",
      "moves": [
        "Shadow Ball",
        "Dark Pulse",
        "Hypnosis",
        "Dream Eater"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 150,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SPIRITOMB:0",
      "originalSpeciesKey": "SPIRITOMB:0",
      "trainerId": "CHANNELER:Evelyn:0",
      "slot": 3,
      "doubles": true
    },
    "Ace Trainer Wesley (DOUBLES) [Slot 4]": {
      "level": 67,
      "ability": "Pressure",
      "moves": [
        "Hex",
        "Foul Play",
        "Psychic",
        "Hypnosis"
      ],
      "nature": "Bold",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 239,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SPIRITOMB:0",
      "originalSpeciesKey": "SPIRITOMB:0",
      "trainerId": "COOLTRAINER_M:Wesley:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Palossand": {
    "Haramsu Haramsu [Slot 5]": {
      "level": 42,
      "ability": "Water Compaction",
      "moves": [
        "Shadow Ball",
        "Earth Power",
        "Terrain Pulse"
      ],
      "nature": "Sassy",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 152,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PALOSSAND:0",
      "originalSpeciesKey": "PALOSSAND:0",
      "trainerId": "HARAMSU:Haramsu:0",
      "slot": 5,
      "doubles": false
    },
    "Psychic F Summer [Slot 3]": {
      "level": 64,
      "ability": "Sand Veil",
      "moves": [
        "Hex",
        "Scorching Sands",
        "Ancient Power",
        "Shore Up"
      ],
      "nature": "Modest",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 234,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PALOSSAND:0",
      "originalSpeciesKey": "PALOSSAND:0",
      "trainerId": "PSYCHIC_F:Summer:0",
      "slot": 3,
      "doubles": false
    },
    "Channeler Evelyn (DOUBLES) [Slot 4]": {
      "level": 41,
      "ability": "Water Compaction",
      "moves": [
        "Hex",
        "Earth Power",
        "Giga Drain",
        "Hypnosis"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 150,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PALOSSAND:0",
      "originalSpeciesKey": "PALOSSAND:0",
      "trainerId": "CHANNELER:Evelyn:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Mimikyu": {
    "Youngster Adam [Slot 3]": {
      "level": 49,
      "ability": "Disguise",
      "moves": [
        "Shadow Sneak",
        "Play Rough",
        "Drain Punch",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 198,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MIMIKYU:0",
      "originalSpeciesKey": "MIMIKYU:0",
      "trainerId": "YOUNGSTER:Adam:0",
      "slot": 3,
      "doubles": false
    },
    "Psychic M Sheldon [Slot 2]": {
      "level": 65,
      "ability": "Disguise",
      "moves": [
        "Shadow Sneak",
        "Shadow Claw",
        "Play Rough",
        "Will-O-Wisp"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 237,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MIMIKYU:0",
      "originalSpeciesKey": "MIMIKYU:0",
      "trainerId": "PSYCHIC_M:Sheldon:0",
      "slot": 2,
      "doubles": false
    },
    "Channeler Agatha (DOUBLES) [Slot 1]": {
      "level": 40,
      "ability": "Disguise",
      "moves": [
        "Shadow Sneak",
        "Play Rough",
        "Drain Punch",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 151,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MIMIKYU:0",
      "originalSpeciesKey": "MIMIKYU:0",
      "trainerId": "CHANNELER:Agatha:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Meowstic [Female]": {
    "Galactic F Grunt #5 [Slot 4]": {
      "level": 73,
      "ability": "Competitive",
      "moves": [
        "Psychic",
        "Thunderbolt",
        "Shadow Ball",
        "Signal Beam"
      ],
      "nature": "Timid",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 281,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MEOWSTIC:1",
      "originalSpeciesKey": "MEOWSTIC:1",
      "trainerId": "GALACTIC_F:Grunt:20",
      "slot": 4,
      "doubles": false
    },
    "Channeler Agatha (DOUBLES) [Slot 3]": {
      "level": 41,
      "ability": "Keen Eye",
      "moves": [
        "Psyshock",
        "Thunderbolt",
        "Helping Hand",
        "Reflect"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 151,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MEOWSTIC:1",
      "originalSpeciesKey": "MEOWSTIC:1",
      "trainerId": "CHANNELER:Agatha:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Chandelure": {
    "Cooltrainer F Serena [Slot 1]": {
      "level": 40,
      "ability": "Infiltrator",
      "moves": [
        "Shadow Ball",
        "Mystical Fire",
        "Energy Ball",
        "Substitute"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 157,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CHANDELURE:0",
      "originalSpeciesKey": "CHANDELURE:0",
      "trainerId": "COOLTRAINER_F:Serena:0",
      "slot": 1,
      "doubles": false
    },
    "Lass Jeanne [Slot 4]": {
      "level": 68,
      "ability": "Shadow Tag",
      "moves": [
        "Shadow Ball",
        "Fire Blast",
        "Energy Ball"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 250,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CHANDELURE:0",
      "originalSpeciesKey": "CHANDELURE:0",
      "trainerId": "LASS:Jeanne:0",
      "slot": 4,
      "doubles": false
    },
    "Supernerd Friedrich [Slot 2]": {
      "level": 70,
      "ability": "Flame Body",
      "moves": [
        "Hex",
        "Flamethrower",
        "Will-O-Wisp",
        "Substitute"
      ],
      "nature": "Timid",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 267,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CHANDELURE:0",
      "originalSpeciesKey": "CHANDELURE:0",
      "trainerId": "SUPERNERD:Friedrich:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer M Miguel [Slot 2]": {
      "level": 95,
      "ability": "Shadow Tag",
      "moves": [
        "Shadow Ball",
        "Fire Blast",
        "Energy Ball",
        "Minimize"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 300,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CHANDELURE:0",
      "originalSpeciesKey": "CHANDELURE:0",
      "trainerId": "COOLTRAINER_M:Miguel:0",
      "slot": 2,
      "doubles": false
    },
    "Channeler Agatha (DOUBLES) [Slot 4]": {
      "level": 41,
      "ability": "Flame Body",
      "moves": [
        "Shadow Ball",
        "Heat Wave",
        "Energy Ball",
        "Acid Armor"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 151,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CHANDELURE:0",
      "originalSpeciesKey": "CHANDELURE:0",
      "trainerId": "CHANNELER:Agatha:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Incineroar": {
    "Haramsu Haramsu [Slot 3]": {
      "level": 42,
      "ability": "Intimidate",
      "moves": [
        "Fake Out",
        "Flare Blitz",
        "Darkest Lariat",
        "Parting Shot"
      ],
      "nature": "Adamant",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 152,
      "gender": "M",
      "shiny": false,
      "speciesKey": "INCINEROAR:0",
      "originalSpeciesKey": "INCINEROAR:0",
      "trainerId": "HARAMSU:Haramsu:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Raichu [Alolan]": {
    "Haramsu Haramsu [Slot 4]": {
      "level": 42,
      "ability": "Surge Surfer",
      "moves": [
        "Rising Voltage",
        "Psychic",
        "Grass Knot"
      ],
      "nature": "Modest",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 152,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RAICHU:1",
      "originalSpeciesKey": "RAICHU:1",
      "trainerId": "HARAMSU:Haramsu:0",
      "slot": 4,
      "doubles": false
    },
    "Biker Sal [Slot 1]": {
      "level": 47,
      "ability": "Surge Surfer",
      "moves": [
        "Nuzzle",
        "Wild Charge",
        "Psychic",
        "Thunderbolt"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 187,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RAICHU:1",
      "originalSpeciesKey": "RAICHU:1",
      "trainerId": "BIKER:Sal:0",
      "slot": 1,
      "doubles": false
    },
    "Pokemonranger M Auron [Slot 2]": {
      "level": 95,
      "ability": "Surge Surfer",
      "moves": [
        "Extreme Speed",
        "Thunderbolt",
        "Psychic",
        "Surf"
      ],
      "nature": "Mild",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 308,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RAICHU:1",
      "originalSpeciesKey": "RAICHU:1",
      "trainerId": "POKEMONRANGER_M:Auron:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Chesnaught [Mega Chesnaught]": {
    "Haramsu Haramsu [Slot 6]": {
      "level": 43,
      "ability": "Bulletproof",
      "moves": [
        "Seed Bomb",
        "Body Press",
        "Knock Off",
        "Bulk Up"
      ],
      "nature": "Careful",
      "item": "Chesnaughtite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 152,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CHESNAUGHT:1",
      "originalSpeciesKey": "CHESNAUGHT:0",
      "trainerId": "HARAMSU:Haramsu:0",
      "slot": 6,
      "doubles": false
    }
  },
  "Reuniclus": {
    "Cooltrainer M David [Slot 1]": {
      "level": 40,
      "ability": "Magic Guard",
      "moves": [
        "Extrasensory",
        "Shadow Ball",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 153,
      "gender": "M",
      "shiny": false,
      "speciesKey": "REUNICLUS:0",
      "originalSpeciesKey": "REUNICLUS:0",
      "trainerId": "COOLTRAINER_M:David:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Banette": {
    "Cooltrainer M David [Slot 2]": {
      "level": 41,
      "ability": "Cursed Body",
      "moves": [
        "Night Shade",
        "Gunk Shot",
        "Torment",
        "Confuse Ray"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 153,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BANETTE:0",
      "originalSpeciesKey": "BANETTE:0",
      "trainerId": "COOLTRAINER_M:David:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Beheeyem": {
    "Cooltrainer M David [Slot 3]": {
      "level": 41,
      "ability": "Analytic",
      "moves": [
        "Psychic",
        "Shadow Ball",
        "Signal Beam",
        "Disable"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 153,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BEHEEYEM:0",
      "originalSpeciesKey": "BEHEEYEM:0",
      "trainerId": "COOLTRAINER_M:David:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Gourgeist [Super Size]": {
    "Cooltrainer M David [Slot 4]": {
      "level": 42,
      "ability": "Insomnia",
      "moves": [
        "Poltergeist",
        "Seed Bomb",
        "Leech Seed",
        "Protect"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 153,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GOURGEIST:3",
      "originalSpeciesKey": "GOURGEIST:3",
      "trainerId": "COOLTRAINER_M:David:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Polteageist": {
    "Channeler Mayumi [Slot 1]": {
      "level": 41,
      "ability": "Cursed Body",
      "moves": [
        "Shadow Ball",
        "Giga Drain",
        "Strength Sap",
        "Protect"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 154,
      "gender": "",
      "shiny": false,
      "speciesKey": "POLTEAGEIST:0",
      "originalSpeciesKey": "POLTEAGEIST:0",
      "trainerId": "CHANNELER:Mayumi:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Brambleghast": {
    "Channeler Mayumi [Slot 2]": {
      "level": 41,
      "ability": "Infiltrator",
      "moves": [
        "Phantom Force",
        "Skitter Smack",
        "Confuse Ray",
        "Leech Seed"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 154,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRAMBLEGHAST:0",
      "originalSpeciesKey": "BRAMBLEGHAST:0",
      "trainerId": "CHANNELER:Mayumi:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic Commander Saturn #2 (DOUBLES) [Slot 1]": {
      "level": 74,
      "ability": "Wind Rider",
      "moves": [
        "Shadow Sneak",
        "Power Whip",
        "Poltergeist"
      ],
      "nature": "Jolly",
      "item": "Yache Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 210,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRAMBLEGHAST:0",
      "originalSpeciesKey": "BRAMBLEGHAST:0",
      "trainerId": "SATURN:Saturn:1",
      "slot": 1,
      "doubles": true
    }
  },
  "Doublade": {
    "Channeler Mayumi [Slot 3]": {
      "level": 42,
      "ability": "No Guard",
      "moves": [
        "Shadow Sneak",
        "Iron Head",
        "Sacred Sword",
        "Destiny Bond"
      ],
      "nature": "Adamant",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 154,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DOUBLADE:0",
      "originalSpeciesKey": "DOUBLADE:0",
      "trainerId": "CHANNELER:Mayumi:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Jellicent": {
    "Channeler Keiko [Slot 1]": {
      "level": 41,
      "ability": "Cursed Body",
      "moves": [
        "Muddy Water",
        "Shadow Ball",
        "Ice Beam",
        "Wring Out"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 155,
      "gender": "M",
      "shiny": false,
      "speciesKey": "JELLICENT:0",
      "originalSpeciesKey": "JELLICENT:0",
      "trainerId": "CHANNELER:Keiko:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic M Grunt #20 [Slot 4]": {
      "level": 75,
      "ability": "Water Absorb",
      "moves": [
        "Water Spout",
        "Scald",
        "Shadow Ball",
        "Strength Sap"
      ],
      "nature": "Timid",
      "item": "Mystic Water",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 284,
      "gender": "F",
      "shiny": false,
      "speciesKey": "JELLICENT:0",
      "originalSpeciesKey": "JELLICENT:0",
      "trainerId": "GALACTIC_M:Grunt:23",
      "slot": 4,
      "doubles": false
    },
    "Ace Trainer Forrest (DOUBLES) [Slot 1]": {
      "level": 68,
      "ability": "Water Absorb",
      "moves": [
        "Hydro Pump",
        "Shadow Ball",
        "Strength Sap",
        "Trick Room"
      ],
      "nature": "Quiet",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 263,
      "gender": "M",
      "shiny": false,
      "speciesKey": "JELLICENT:0",
      "originalSpeciesKey": "JELLICENT:0",
      "trainerId": "COOLTRAINER_M:Forrest:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Marowak [Alolan]": {
    "Channeler Keiko [Slot 2]": {
      "level": 41,
      "ability": "Rock Head",
      "moves": [
        "Flare Blitz",
        "Shadow Bone",
        "Bonemerang",
        "Focus Energy"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 155,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAROWAK:1",
      "originalSpeciesKey": "MAROWAK:1",
      "trainerId": "CHANNELER:Keiko:0",
      "slot": 2,
      "doubles": false
    },
    "Juggler Seymour [Slot 4]": {
      "level": 68,
      "ability": "Rock Head",
      "moves": [
        "Flare Blitz",
        "Shadow Bone",
        "Earthquake"
      ],
      "nature": "Adamant",
      "item": "Thick Club",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 253,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MAROWAK:1",
      "originalSpeciesKey": "MAROWAK:1",
      "trainerId": "JUGGLER:Seymour:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Rotom": {
    "Channeler Keiko [Slot 3]": {
      "level": 42,
      "ability": "Levitate",
      "moves": [
        "Discharge",
        "Shadow Ball",
        "Dark Pulse",
        "Nasty Plot"
      ],
      "nature": "Quiet",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 155,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROTOM:0",
      "originalSpeciesKey": "ROTOM:0",
      "trainerId": "CHANNELER:Keiko:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Runerigus": {
    "Cooltrainer M Travis [Slot 2]": {
      "level": 41,
      "ability": "Wandering Spirit",
      "moves": [
        "Earth Power",
        "Shadow Ball",
        "Energy Ball",
        "Power Split"
      ],
      "nature": "Modest",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 156,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RUNERIGUS:0",
      "originalSpeciesKey": "RUNERIGUS:1",
      "trainerId": "COOLTRAINER_M:Travis:0",
      "slot": 2,
      "doubles": false
    },
    "Ruinmaniac Harold [Slot 1]": {
      "level": 65,
      "ability": "Wandering Spirit",
      "moves": [
        "Stealth Rock",
        "Sand Tomb",
        "Will-O-Wisp",
        "Destiny Bond"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 242,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RUNERIGUS:0",
      "originalSpeciesKey": "RUNERIGUS:1",
      "trainerId": "RUINMANIAC:Harold:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Drakloak": {
    "Cooltrainer M Travis [Slot 3]": {
      "level": 41,
      "ability": "Clear Body",
      "moves": [
        "Sucker Punch",
        "Breaking Swipe",
        "Phantom Force",
        "U-turn"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 156,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAKLOAK:0",
      "originalSpeciesKey": "DRAKLOAK:0",
      "trainerId": "COOLTRAINER_M:Travis:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Malamar": {
    "Cooltrainer M Travis [Slot 4]": {
      "level": 42,
      "ability": "Infiltrator",
      "moves": [
        "Psycho Cut",
        "Night Slash",
        "Superpower",
        "Protect"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 156,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MALAMAR:0",
      "originalSpeciesKey": "MALAMAR:0",
      "trainerId": "COOLTRAINER_M:Travis:0",
      "slot": 4,
      "doubles": false
    },
    "Galactic M Grunt #12 [Slot 2]": {
      "level": 72,
      "ability": "Contrary",
      "moves": [
        "Night Slash",
        "Psycho Cut",
        "Superpower",
        "Rock Slide"
      ],
      "nature": "Adamant",
      "item": "Quick Claw",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 272,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MALAMAR:0",
      "originalSpeciesKey": "MALAMAR:0",
      "trainerId": "GALACTIC_M:Grunt:11",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Lucian #1 [Slot 5]": {
      "level": 99,
      "ability": "Contrary",
      "moves": [
        "Knock Off",
        "Psycho Cut",
        "Superpower"
      ],
      "nature": "Adamant",
      "item": "Quick Claw",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 316,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MALAMAR:0",
      "originalSpeciesKey": "MALAMAR:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:0",
      "slot": 5,
      "doubles": false
    },
    "Elite Four Lucian #2 (DOUBLES) [Slot 6]": {
      "level": 99,
      "ability": "Contrary",
      "moves": [
        "Night Slash",
        "Psycho Cut",
        "Superpower"
      ],
      "nature": "Adamant",
      "item": "Quick Claw",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 317,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MALAMAR:0",
      "originalSpeciesKey": "MALAMAR:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Cursola": {
    "Cooltrainer F Serena [Slot 3]": {
      "level": 41,
      "ability": "Weak Armor",
      "moves": [
        "Shadow Ball",
        "Scald",
        "Icy Wind",
        "Strength Sap"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 157,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CURSOLA:0",
      "originalSpeciesKey": "CURSOLA:1",
      "trainerId": "COOLTRAINER_F:Serena:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Ceruledge": {
    "Gym Leader Fantina #1 [Slot 1]": {
      "level": 43,
      "ability": "Weak Armor",
      "moves": [
        "Shadow Claw",
        "Bitter Blade",
        "Close Combat",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "Colbur Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 158,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CERULEDGE:0",
      "originalSpeciesKey": "CERULEDGE:0",
      "trainerId": "LEADER_Fantina:Fantina:0",
      "slot": 1,
      "doubles": false
    },
    "Gym Leader Fantina #2 (DOUBLES) [Slot 1]": {
      "level": 43,
      "ability": "Flame Body",
      "moves": [
        "Shadow Claw",
        "Bitter Blade",
        "Close Combat",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "Colbur Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 159,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CERULEDGE:0",
      "originalSpeciesKey": "CERULEDGE:0",
      "trainerId": "LEADER_Fantina:Fantina:1",
      "slot": 1,
      "doubles": true
    },
    "Toni Toni [Slot 2]": {
      "level": 68,
      "ability": "Flame Body",
      "moves": [
        "Flare Blitz",
        "Shadow Claw",
        "X-Scissor",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 245,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CERULEDGE:0",
      "originalSpeciesKey": "CERULEDGE:0",
      "trainerId": "TONI:Toni:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Bruxish": {
    "Gym Leader Fantina #1 [Slot 2]": {
      "level": 43,
      "ability": "Wonder Skin",
      "moves": [
        "Waterfall",
        "Psychic Fangs",
        "Ice Fang"
      ],
      "nature": "Careful",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 158,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BRUXISH:0",
      "originalSpeciesKey": "BRUXISH:0",
      "trainerId": "LEADER_Fantina:Fantina:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Fantina #2 (DOUBLES) [Slot 2]": {
      "level": 43,
      "ability": "Wonder Skin",
      "moves": [
        "Waterfall",
        "Psychic Fangs",
        "Ice Fang"
      ],
      "nature": "Careful",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 159,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BRUXISH:0",
      "originalSpeciesKey": "BRUXISH:0",
      "trainerId": "LEADER_Fantina:Fantina:1",
      "slot": 2,
      "doubles": true
    },
    "Ace Trainer Wesley (DOUBLES) [Slot 1]": {
      "level": 68,
      "ability": "Dazzling",
      "moves": [
        "Liquidation",
        "Psychic Fangs",
        "Icy Wind",
        "Super Fang"
      ],
      "nature": "Jolly",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 239,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRUXISH:0",
      "originalSpeciesKey": "BRUXISH:0",
      "trainerId": "COOLTRAINER_M:Wesley:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Froslass": {
    "Gym Leader Fantina #1 [Slot 3]": {
      "level": 43,
      "ability": "Cursed Body",
      "moves": [
        "Ice Beam",
        "Shadow Ball",
        "Will-O-Wisp",
        "Destiny Bond"
      ],
      "nature": "Hasty",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 158,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FROSLASS:0",
      "originalSpeciesKey": "FROSLASS:0",
      "trainerId": "LEADER_Fantina:Fantina:0",
      "slot": 3,
      "doubles": false
    },
    "Gym Leader Fantina #2 (DOUBLES) [Slot 3]": {
      "level": 43,
      "ability": "Cursed Body",
      "moves": [
        "Ice Beam",
        "Shadow Ball",
        "Will-O-Wisp",
        "Destiny Bond"
      ],
      "nature": "Hasty",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 159,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FROSLASS:0",
      "originalSpeciesKey": "FROSLASS:0",
      "trainerId": "LEADER_Fantina:Fantina:1",
      "slot": 3,
      "doubles": true
    },
    "Galactic M Grunt #11 [Slot 3]": {
      "level": 49,
      "ability": "Cursed Body",
      "moves": [
        "Ice Beam",
        "Hex",
        "Thunder Wave",
        "Will-O-Wisp"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 208,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FROSLASS:0",
      "originalSpeciesKey": "FROSLASS:0",
      "trainerId": "GALACTIC_M:Grunt:10",
      "slot": 3,
      "doubles": false
    }
  },
  "Espeon": {
    "Gym Leader Fantina #1 [Slot 4]": {
      "level": 43,
      "ability": "Synchronize",
      "moves": [
        "Psychic",
        "Dazzling Gleam",
        "Calm Mind"
      ],
      "nature": "Mild",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 158,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ESPEON:0",
      "originalSpeciesKey": "ESPEON:0",
      "trainerId": "LEADER_Fantina:Fantina:0",
      "slot": 4,
      "doubles": false
    },
    "Gym Leader Fantina #2 (DOUBLES) [Slot 4]": {
      "level": 43,
      "ability": "Synchronize",
      "moves": [
        "Psychic",
        "Dazzling Gleam",
        "Calm Mind"
      ],
      "nature": "Mild",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 159,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ESPEON:0",
      "originalSpeciesKey": "ESPEON:0",
      "trainerId": "LEADER_Fantina:Fantina:1",
      "slot": 4,
      "doubles": true
    },
    "Lass Sable [Slot 2]": {
      "level": 67,
      "ability": "Synchronize",
      "moves": [
        "Psychic",
        "Weather Ball",
        "Morning Sun"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 252,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ESPEON:0",
      "originalSpeciesKey": "ESPEON:0",
      "trainerId": "LASS:Sable:0",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Lucian #1 [Slot 4]": {
      "level": 99,
      "ability": "Magic Bounce",
      "moves": [
        "Psychic",
        "Dazzling Gleam"
      ],
      "nature": "Timid",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 316,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ESPEON:0",
      "originalSpeciesKey": "ESPEON:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:0",
      "slot": 4,
      "doubles": false
    },
    "Elite Four Lucian #2 (DOUBLES) [Slot 5]": {
      "level": 99,
      "ability": "Magic Bounce",
      "moves": [
        "Psychic",
        "Dazzling Gleam"
      ],
      "nature": "Timid",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 317,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ESPEON:0",
      "originalSpeciesKey": "ESPEON:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Mismagius": {
    "Gym Leader Fantina #1 [Slot 5]": {
      "level": 43,
      "ability": "Levitate",
      "moves": [
        "Shadow Ball",
        "Dazzling Gleam",
        "Mystical Fire"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 158,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MISMAGIUS:0",
      "originalSpeciesKey": "MISMAGIUS:0",
      "trainerId": "LEADER_Fantina:Fantina:0",
      "slot": 5,
      "doubles": false
    },
    "Gym Leader Fantina #2 (DOUBLES) [Slot 5]": {
      "level": 43,
      "ability": "Levitate",
      "moves": [
        "Shadow Ball",
        "Dazzling Gleam",
        "Mystical Fire"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 159,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MISMAGIUS:0",
      "originalSpeciesKey": "MISMAGIUS:0",
      "trainerId": "LEADER_Fantina:Fantina:1",
      "slot": 5,
      "doubles": true
    },
    "Cooltrainer F Mag [Slot 2]": {
      "level": 95,
      "ability": "Levitate",
      "moves": [
        "Shadow Ball",
        "Moonblast",
        "Mystical Fire",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 304,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MISMAGIUS:0",
      "originalSpeciesKey": "MISMAGIUS:0",
      "trainerId": "COOLTRAINER_F:Mag:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Gengar [Mega Gengar]": {
    "Gym Leader Fantina #1 [Slot 6]": {
      "level": 44,
      "ability": "Shadow Tag",
      "moves": [
        "Shadow Ball",
        "Sludge Bomb",
        "Will-O-Wisp"
      ],
      "nature": "Timid",
      "item": "Gengarite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 158,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GENGAR:1",
      "originalSpeciesKey": "GENGAR:0",
      "trainerId": "LEADER_Fantina:Fantina:0",
      "slot": 6,
      "doubles": false
    },
    "Gym Leader Fantina #2 (DOUBLES) [Slot 6]": {
      "level": 44,
      "ability": "Shadow Tag",
      "moves": [
        "Shadow Ball",
        "Sludge Bomb",
        "Will-O-Wisp"
      ],
      "nature": "Timid",
      "item": "Gengarite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 159,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GENGAR:1",
      "originalSpeciesKey": "GENGAR:0",
      "trainerId": "LEADER_Fantina:Fantina:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Clawitzer": {
    "Swimmer2 F Tara [Slot 1]": {
      "level": 45,
      "ability": "Mega Launcher",
      "moves": [
        "Terrain Pulse",
        "Dragon Pulse",
        "Aura Sphere",
        "Dark Pulse"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 160,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLAWITZER:0",
      "originalSpeciesKey": "CLAWITZER:0",
      "trainerId": "SWIMMER2_F:Tara:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic F Grunt #6 [Slot 1]": {
      "level": 74,
      "ability": "Mega Launcher",
      "moves": [
        "Aqua Jet",
        "Water Pulse",
        "Dragon Pulse",
        "Aura Sphere"
      ],
      "nature": "Quiet",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 282,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CLAWITZER:0",
      "originalSpeciesKey": "CLAWITZER:0",
      "trainerId": "GALACTIC_F:Grunt:21",
      "slot": 1,
      "doubles": false
    }
  },
  "Inteleon": {
    "Swimmer2 F Tara [Slot 4]": {
      "level": 46,
      "ability": "Sniper",
      "moves": [
        "Liquidation",
        "Snipe Shot",
        "Scald",
        "U-turn"
      ],
      "nature": "Modest",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 160,
      "gender": "M",
      "shiny": false,
      "speciesKey": "INTELEON:0",
      "originalSpeciesKey": "INTELEON:0",
      "trainerId": "SWIMMER2_F:Tara:0",
      "slot": 4,
      "doubles": false
    },
    "Burglar Max & Greed [Slot 1]": {
      "level": 49,
      "ability": "Torrent",
      "moves": [
        "Muddy Water",
        "Icy Wind",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 195,
      "gender": "M",
      "shiny": false,
      "speciesKey": "INTELEON:0",
      "originalSpeciesKey": "INTELEON:0",
      "trainerId": "UTOPIA_DUO:3:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Mantine": {
    "Swimmer2 F Nicole [Slot 1]": {
      "level": 45,
      "ability": "Water Absorb",
      "moves": [
        "Aqua Ring",
        "Mirror Coat",
        "Air Slash",
        "Tailwind"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 161,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MANTINE:0",
      "originalSpeciesKey": "MANTINE:0",
      "trainerId": "SWIMMER2_F:Nicole:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Relicanth": {
    "Swimmer2 F Nicole [Slot 2]": {
      "level": 45,
      "ability": "Sturdy",
      "moves": [
        "Aqua Tail",
        "Rest",
        "Flail",
        "Hydro Pump"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 161,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RELICANTH:0",
      "originalSpeciesKey": "RELICANTH:0",
      "trainerId": "SWIMMER2_F:Nicole:0",
      "slot": 2,
      "doubles": false
    },
    "Hiker Ray [Slot 4]": {
      "level": 64,
      "ability": "Sturdy",
      "moves": [
        "Flail",
        "Hydro Pump",
        "Double-Edge",
        "Head Smash"
      ],
      "nature": "Serious",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 233,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RELICANTH:0",
      "originalSpeciesKey": "RELICANTH:0",
      "trainerId": "HIKER:Ray:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Gastrodon": {
    "Swimmer2 F Nicole [Slot 3]": {
      "level": 46,
      "ability": "Storm Drain",
      "moves": [
        "Ancient Power",
        "Earth Power",
        "Muddy Water",
        "Sludge Bomb"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 161,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GASTRODON:0",
      "originalSpeciesKey": "GASTRODON:0",
      "trainerId": "SWIMMER2_F:Nicole:0",
      "slot": 3,
      "doubles": false
    },
    "Gym Leader Byron #1 [Slot 4]": {
      "level": 55,
      "ability": "Storm Drain",
      "moves": [
        "Scald",
        "Earth Power",
        "Ice Beam",
        "Recover"
      ],
      "nature": "Bold",
      "item": "Rindo Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 218,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GASTRODON:0",
      "originalSpeciesKey": "GASTRODON:0",
      "trainerId": "LEADER_Byron:Byron:0",
      "slot": 4,
      "doubles": false
    },
    "Gym Leader Byron #2 (DOUBLES) [Slot 4]": {
      "level": 55,
      "ability": "Storm Drain",
      "moves": [
        "Muddy Water",
        "Earth Power",
        "Icy Wind",
        "Recover"
      ],
      "nature": "Bold",
      "item": "Rindo Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 219,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GASTRODON:0",
      "originalSpeciesKey": "GASTRODON:0",
      "trainerId": "LEADER_Byron:Byron:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Walrein": {
    "Swimmer2 F Nicole [Slot 4]": {
      "level": 46,
      "ability": "Thick Fat",
      "moves": [
        "Body Slam",
        "Icy Wind",
        "Super Fang",
        "Frost Breath"
      ],
      "nature": "Calm",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 161,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WALREIN:0",
      "originalSpeciesKey": "WALREIN:0",
      "trainerId": "SWIMMER2_F:Nicole:0",
      "slot": 4,
      "doubles": false
    },
    "Gentleman Heath [Slot 3]": {
      "level": 67,
      "ability": "Ice Body",
      "moves": [
        "Blizzard",
        "Scald",
        "Toxic",
        "Substitute"
      ],
      "nature": "Modest",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 257,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WALREIN:0",
      "originalSpeciesKey": "WALREIN:0",
      "trainerId": "GENTLEMAN:Heath:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Quaquaval": {
    "Swimmer2 M Dean [Slot 4]": {
      "level": 46,
      "ability": "Torrent",
      "moves": [
        "Double Hit",
        "Fling",
        "Aqua Cutter",
        "Acrobatics"
      ],
      "nature": "Jolly",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 162,
      "gender": "M",
      "shiny": false,
      "speciesKey": "QUAQUAVAL:0",
      "originalSpeciesKey": "QUAQUAVAL:0",
      "trainerId": "SWIMMER2_M:Dean:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Torkoal": {
    "Picnicker Mia [Slot 1]": {
      "level": 45,
      "ability": "Drought",
      "moves": [
        "Flamethrower",
        "Fire Spin",
        "Earth Power",
        "Yawn"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 163,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TORKOAL:0",
      "originalSpeciesKey": "TORKOAL:0",
      "trainerId": "PICNICKER:Mia:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Doyle [Slot 1]": {
      "level": 67,
      "ability": "White Smoke",
      "moves": [
        "Fire Blast",
        "Earth Power",
        "Body Press"
      ],
      "nature": "Relaxed",
      "item": "Custap Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 248,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TORKOAL:0",
      "originalSpeciesKey": "TORKOAL:0",
      "trainerId": "HIKER:Doyle:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Talonflame": {
    "Picnicker Mia [Slot 3]": {
      "level": 47,
      "ability": "Gale Wings",
      "moves": [
        "Flare Blitz",
        "Dual Wingbeat",
        "Steel Wing",
        "Roost"
      ],
      "nature": "Jolly",
      "item": "Charcoal",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 163,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TALONFLAME:0",
      "originalSpeciesKey": "TALONFLAME:0",
      "trainerId": "PICNICKER:Mia:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer M Julian [Slot 2]": {
      "level": 48,
      "ability": "Flame Body",
      "moves": [
        "Flare Blitz",
        "Acrobatics",
        "Swords Dance",
        "Will-O-Wisp"
      ],
      "nature": "Jolly",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 182,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TALONFLAME:0",
      "originalSpeciesKey": "TALONFLAME:0",
      "trainerId": "COOLTRAINER_M:Julian:0",
      "slot": 2,
      "doubles": false
    },
    "Lass Jeanne [Slot 2]": {
      "level": 67,
      "ability": "Flame Body",
      "moves": [
        "Flare Blitz",
        "Acrobatics",
        "Will-O-Wisp",
        "Roost"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 250,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TALONFLAME:0",
      "originalSpeciesKey": "TALONFLAME:0",
      "trainerId": "LASS:Jeanne:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Roserade": {
    "Picnicker Candice [Slot 1]": {
      "level": 46,
      "ability": "Poison Point",
      "moves": [
        "Energy Ball",
        "Sludge Bomb",
        "Sleep Powder",
        "Synthesis"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 164,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ROSERADE:0",
      "originalSpeciesKey": "ROSERADE:0",
      "trainerId": "PICNICKER:Candice:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer F Lumina [Slot 5]": {
      "level": 69,
      "ability": "Technician",
      "moves": [
        "Grass Knot",
        "Sludge Bomb",
        "Extrasensory",
        "Sleep Powder"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 259,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ROSERADE:0",
      "originalSpeciesKey": "ROSERADE:0",
      "trainerId": "COOLTRAINER_F:Lumina:0",
      "slot": 5,
      "doubles": false
    },
    "Cynthia Cynthia #1 [Slot 5]": {
      "level": 100,
      "ability": "Technician",
      "moves": [
        "Grass Knot",
        "Sludge Bomb",
        "Extrasensory",
        "Sleep Powder"
      ],
      "nature": "Timid",
      "item": "Black Sludge",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 318,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ROSERADE:0",
      "originalSpeciesKey": "ROSERADE:0",
      "trainerId": "CYNTHIA:Cynthia:0",
      "slot": 5,
      "doubles": false
    },
    "Cynthia Cynthia #2 (DOUBLES) [Slot 5]": {
      "level": 100,
      "ability": "Technician",
      "moves": [
        "Grass Knot",
        "Sludge Bomb",
        "Extrasensory",
        "Sleep Powder"
      ],
      "nature": "Timid",
      "item": "Black Sludge",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 319,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ROSERADE:0",
      "originalSpeciesKey": "ROSERADE:0",
      "trainerId": "CYNTHIA:Cynthia:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Ursaring": {
    "Picnicker Candice [Slot 2]": {
      "level": 46,
      "ability": "Guts",
      "moves": [
        "Strength",
        "Close Combat",
        "Crunch",
        "High Horsepower"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 164,
      "gender": "M",
      "shiny": false,
      "speciesKey": "URSARING:0",
      "originalSpeciesKey": "URSARING:0",
      "trainerId": "PICNICKER:Candice:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Ribombee": {
    "Picnicker Candice [Slot 3]": {
      "level": 47,
      "ability": "Triage",
      "moves": [
        "Draining Kiss",
        "Giga Drain",
        "Fake Tears",
        "Quiver Dance"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 164,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RIBOMBEE:0",
      "originalSpeciesKey": "RIBOMBEE:0",
      "trainerId": "PICNICKER:Candice:0",
      "slot": 3,
      "doubles": false
    },
    "Rocker Leroy [Slot 1]": {
      "level": 64,
      "ability": "Shield Dust",
      "moves": [
        "Bug Buzz",
        "Moonblast",
        "Energy Ball",
        "Stun Spore"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 240,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RIBOMBEE:0",
      "originalSpeciesKey": "RIBOMBEE:0",
      "trainerId": "ROCKER:Leroy:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Copperajah": {
    "Pokemaniac Curtis [Slot 1]": {
      "level": 46,
      "ability": "Sheer Force",
      "moves": [
        "Stealth Rock",
        "Iron Head",
        "Rock Slide",
        "Bulldoze"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 165,
      "gender": "M",
      "shiny": false,
      "speciesKey": "COPPERAJAH:0",
      "originalSpeciesKey": "COPPERAJAH:0",
      "trainerId": "POKEMANIAC:Curtis:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Charizard": {
    "Pokemaniac Curtis [Slot 2]": {
      "level": 47,
      "ability": "Blazing Fury",
      "moves": [
        "Flamethrower",
        "Dual Wingbeat",
        "Scale Shot",
        "Scorching Sands"
      ],
      "nature": "Hasty",
      "item": "Charti Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 165,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CHARIZARD:0",
      "originalSpeciesKey": "CHARIZARD:0",
      "trainerId": "POKEMANIAC:Curtis:0",
      "slot": 2,
      "doubles": false
    },
    "Hiker Kipp [Slot 1]": {
      "level": 65,
      "ability": "Blaze",
      "moves": [
        "Flamethrower",
        "Dual Wingbeat",
        "Dragon Claw",
        "Weather Ball"
      ],
      "nature": "Hasty",
      "item": "Rock Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 238,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CHARIZARD:0",
      "originalSpeciesKey": "CHARIZARD:0",
      "trainerId": "HIKER:Kipp:0",
      "slot": 1,
      "doubles": false
    },
    "Juggler Seymour [Slot 2]": {
      "level": 67,
      "ability": "Blaze",
      "moves": [
        "Flame Charge",
        "Dual Wingbeat",
        "Earthquake",
        "Rock Slide"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 253,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CHARIZARD:0",
      "originalSpeciesKey": "CHARIZARD:0",
      "trainerId": "JUGGLER:Seymour:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Blaine #1 [Slot 4]": {
      "level": 72,
      "ability": "Solar Power",
      "moves": [
        "Heat Wave",
        "Air Slash",
        "Dragon Pulse",
        "Scorching Sands"
      ],
      "nature": "Timid",
      "item": "Charcoal",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 270,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CHARIZARD:0",
      "originalSpeciesKey": "CHARIZARD:0",
      "trainerId": "LEADER_Blaine:Blaine:0",
      "slot": 4,
      "doubles": false
    },
    "Gym Leader Blaine #2 (DOUBLES) [Slot 4]": {
      "level": 72,
      "ability": "Solar Power",
      "moves": [
        "Heat Wave",
        "Air Slash",
        "Dragon Pulse",
        "Scorching Sands"
      ],
      "nature": "Timid",
      "item": "Charcoal",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 271,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CHARIZARD:0",
      "originalSpeciesKey": "CHARIZARD:0",
      "trainerId": "LEADER_Blaine:Blaine:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Frosmoth": {
    "Picnicker Julia [Slot 2]": {
      "level": 47,
      "ability": "Shield Dust",
      "moves": [
        "Bug Bite",
        "Icy Wind",
        "Infestation",
        "Tailwind"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 166,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FROSMOTH:0",
      "originalSpeciesKey": "FROSMOTH:0",
      "trainerId": "PICNICKER:Julia:0",
      "slot": 2,
      "doubles": false
    },
    "Painter Clara [Slot 4]": {
      "level": 68,
      "ability": "Shield Dust",
      "moves": [
        "Feather Dance",
        "Tailwind",
        "Wide Guard",
        "Blizzard"
      ],
      "nature": "Serious",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 256,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FROSMOTH:0",
      "originalSpeciesKey": "FROSMOTH:0",
      "trainerId": "PAINTER:Clara:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Sandslash": {
    "Pokemaniac Lowell [Slot 1]": {
      "level": 46,
      "ability": "Sand Force",
      "moves": [
        "Earthquake",
        "Stone Edge",
        "Leech Life",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 167,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SANDSLASH:0",
      "originalSpeciesKey": "SANDSLASH:0",
      "trainerId": "POKEMANIAC:Lowell:0",
      "slot": 1,
      "doubles": false
    },
    "Biker Richie [Slot 2]": {
      "level": 48,
      "ability": "Sand Force",
      "moves": [
        "Dig",
        "Slash",
        "Drill Run",
        "Crush Claw"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 185,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SANDSLASH:0",
      "originalSpeciesKey": "SANDSLASH:0",
      "trainerId": "BIKER:Richie:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Meowscarada": {
    "Picnicker Hailey [Slot 2]": {
      "level": 46,
      "ability": "Overgrow",
      "moves": [
        "Sucker Punch",
        "Flower Trick",
        "Night Slash",
        "U-turn"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 168,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MEOWSCARADA:0",
      "originalSpeciesKey": "MEOWSCARADA:0",
      "trainerId": "PICNICKER:Hailey:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Altaria": {
    "Picnicker Hailey [Slot 4]": {
      "level": 47,
      "ability": "Natural Cure",
      "moves": [
        "Dragon Pulse",
        "Dual Wingbeat",
        "Moonblast"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 168,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ALTARIA:0",
      "originalSpeciesKey": "ALTARIA:0",
      "trainerId": "PICNICKER:Hailey:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Tauros [Paldean (Blaze Breed)]": {
    "Pokemaniac Triton [Slot 2]": {
      "level": 47,
      "ability": "Intimidate",
      "moves": [
        "Body Press",
        "Raging Bull",
        "Wild Charge",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 169,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TAUROS:2",
      "originalSpeciesKey": "TAUROS:2",
      "trainerId": "POKEMANIAC:Triton:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Metang": {
    "Pokemaniac Triton [Slot 3]": {
      "level": 47,
      "ability": "Iron Fist",
      "moves": [
        "Bullet Punch",
        "Meteor Mash",
        "Psycho Cut",
        "Ice Punch"
      ],
      "nature": "Adamant",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 169,
      "gender": "",
      "shiny": false,
      "speciesKey": "METANG:0",
      "originalSpeciesKey": "METANG:0",
      "trainerId": "POKEMANIAC:Triton:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Mudsdale": {
    "Hiker Frent [Slot 1]": {
      "level": 46,
      "ability": "Stamina",
      "moves": [
        "High Horsepower",
        "Rock Slide",
        "Heavy Slam",
        "Body Press"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 170,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MUDSDALE:0",
      "originalSpeciesKey": "MUDSDALE:0",
      "trainerId": "HIKER:Frent:0",
      "slot": 1,
      "doubles": false
    },
    "Engineer Orville [Slot 2]": {
      "level": 53,
      "ability": "Stamina",
      "moves": [
        "Earthquake",
        "Body Press",
        "Smack Down",
        "Substitute"
      ],
      "nature": "Careful",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 212,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MUDSDALE:0",
      "originalSpeciesKey": "MUDSDALE:0",
      "trainerId": "ENGINEER:Orville:0",
      "slot": 2,
      "doubles": false
    },
    "Ruinmaniac Harold [Slot 2]": {
      "level": 65,
      "ability": "Stamina",
      "moves": [
        "Heavy Slam",
        "Body Press",
        "Iron Defense",
        "Roar"
      ],
      "nature": "Adamant",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 242,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MUDSDALE:0",
      "originalSpeciesKey": "MUDSDALE:0",
      "trainerId": "RUINMANIAC:Harold:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer M Wes [Slot 2]": {
      "level": 95,
      "ability": "Stamina",
      "moves": [
        "Earthquake",
        "Heavy Slam",
        "Body Press",
        "Payback"
      ],
      "nature": "Adamant",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 298,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MUDSDALE:0",
      "originalSpeciesKey": "MUDSDALE:0",
      "trainerId": "COOLTRAINER_M:Wes:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer F Mag [Slot 3]": {
      "level": 96,
      "ability": "Stamina",
      "moves": [
        "Earthquake",
        "Heavy Slam",
        "Stone Edge",
        "Counter"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 304,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MUDSDALE:0",
      "originalSpeciesKey": "MUDSDALE:0",
      "trainerId": "COOLTRAINER_F:Mag:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Barbaracle": {
    "Hiker Frent [Slot 2]": {
      "level": 47,
      "ability": "Sniper",
      "moves": [
        "Stone Edge",
        "Razor Shell",
        "Cross Chop",
        "Shell Smash"
      ],
      "nature": "Jolly",
      "item": "White Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 170,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BARBARACLE:0",
      "originalSpeciesKey": "BARBARACLE:0",
      "trainerId": "HIKER:Frent:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Gliscor": {
    "Hiker Nolan [Slot 1]": {
      "level": 46,
      "ability": "Hyper Cutter",
      "moves": [
        "High Horsepower",
        "Dual Wingbeat",
        "Fire Fang",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 171,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GLISCOR:0",
      "originalSpeciesKey": "GLISCOR:0",
      "trainerId": "HIKER:Nolan:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Pedro [Slot 3]": {
      "level": 53,
      "ability": "Hyper Cutter",
      "moves": [
        "High Horsepower",
        "Acrobatics",
        "Knock Off",
        "Roost"
      ],
      "nature": "Jolly",
      "item": "Flying Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 214,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GLISCOR:0",
      "originalSpeciesKey": "GLISCOR:0",
      "trainerId": "HIKER:Pedro:0",
      "slot": 3,
      "doubles": false
    },
    "Toni Toni [Slot 5]": {
      "level": 68,
      "ability": "Poison Heal",
      "moves": [
        "Earthquake",
        "Dual Wingbeat",
        "Facade",
        "Roost"
      ],
      "nature": "Careful",
      "item": "Toxic Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 245,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GLISCOR:0",
      "originalSpeciesKey": "GLISCOR:0",
      "trainerId": "TONI:Toni:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Probopass": {
    "Hiker Nolan [Slot 2]": {
      "level": 47,
      "ability": "Sturdy",
      "moves": [
        "Power Gem",
        "Discharge",
        "Earth Power",
        "Gravity"
      ],
      "nature": "Bold",
      "item": "Starf Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 171,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PROBOPASS:0",
      "originalSpeciesKey": "PROBOPASS:0",
      "trainerId": "HIKER:Nolan:0",
      "slot": 2,
      "doubles": false
    },
    "Engineer Terrell [Slot 4]": {
      "level": 54,
      "ability": "Sturdy",
      "moves": [
        "Power Gem",
        "Flash Cannon",
        "Thunderbolt",
        "Explosion"
      ],
      "nature": "Quiet",
      "item": "Custap Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 211,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PROBOPASS:0",
      "originalSpeciesKey": "PROBOPASS:0",
      "trainerId": "ENGINEER:Terrell:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Corsola": {
    "Ruinmaniac Warren [Slot 1]": {
      "level": 46,
      "ability": "Regenerator",
      "moves": [
        "Scald",
        "Earth Power",
        "Light Screen",
        "Rain Dance"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 172,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CORSOLA:0",
      "originalSpeciesKey": "CORSOLA:0",
      "trainerId": "RUINMANIAC:Warren:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Kabutops": {
    "Ruinmaniac Warren [Slot 3]": {
      "level": 47,
      "ability": "Swift Swim",
      "moves": [
        "Rock Slide",
        "Razor Shell",
        "Leech Life",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "Rindo Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 172,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KABUTOPS:0",
      "originalSpeciesKey": "KABUTOPS:0",
      "trainerId": "RUINMANIAC:Warren:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Sawsbuck [Summer Form]": {
    "Picnicker Brooke [Slot 2]": {
      "level": 46,
      "ability": "Sap Sipper",
      "moves": [
        "Double-Edge",
        "Horn Leech",
        "Jump Kick",
        "Stomping Tantrum"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 173,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SAWSBUCK:1",
      "originalSpeciesKey": "SAWSBUCK:1",
      "trainerId": "PICNICKER:Brooke:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Machamp": {
    "Picnicker Brooke [Slot 4]": {
      "level": 47,
      "ability": "Guts",
      "moves": [
        "Brick Break",
        "Poison Jab",
        "Stone Edge",
        "Protect"
      ],
      "nature": "Adamant",
      "item": "Flame Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 173,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MACHAMP:0",
      "originalSpeciesKey": "MACHAMP:0",
      "trainerId": "PICNICKER:Brooke:0",
      "slot": 4,
      "doubles": false
    },
    "Elite Four Bruno #1 [Slot 4]": {
      "level": 99,
      "ability": "Guts",
      "moves": [
        "Close Combat",
        "Poison Jab",
        "Stone Edge",
        "Protect"
      ],
      "nature": "Adamant",
      "item": "Flame Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 312,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MACHAMP:0",
      "originalSpeciesKey": "MACHAMP:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:0",
      "slot": 4,
      "doubles": false
    },
    "Elite Four Bruno #2 (DOUBLES) [Slot 4]": {
      "level": 99,
      "ability": "Guts",
      "moves": [
        "Close Combat",
        "Poison Jab",
        "Stone Edge",
        "Protect"
      ],
      "nature": "Jolly",
      "item": "Flame Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 313,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MACHAMP:0",
      "originalSpeciesKey": "MACHAMP:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Lycanroc": {
    "Hiker Clifford [Slot 1]": {
      "level": 46,
      "ability": "Sand Rush",
      "moves": [
        "Accelerock",
        "Rock Blast",
        "Thunder Fang",
        "Sandstorm"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 174,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LYCANROC:0",
      "originalSpeciesKey": "LYCANROC:0",
      "trainerId": "HIKER:Clifford:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Lycanroc [Dusk Form]": {
    "Hiker Clifford [Slot 2]": {
      "level": 47,
      "ability": "Tough Claws",
      "moves": [
        "Accelerock",
        "Crush Claw",
        "Psychic Fangs",
        "Crunch"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 174,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LYCANROC:2",
      "originalSpeciesKey": "LYCANROC:2",
      "trainerId": "HIKER:Clifford:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #18 [Slot 2]": {
      "level": 72,
      "ability": "Tough Claws",
      "moves": [
        "Accelerock",
        "Rock Slide",
        "Stomping Tantrum",
        "Howl"
      ],
      "nature": "Jolly",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 279,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LYCANROC:2",
      "originalSpeciesKey": "LYCANROC:2",
      "trainerId": "GALACTIC_M:Grunt:18",
      "slot": 2,
      "doubles": false
    }
  },
  "Lycanroc [Midnight Form]": {
    "Hiker Clifford [Slot 3]": {
      "level": 47,
      "ability": "Keen Eye",
      "moves": [
        "Sucker Punch",
        "Rock Slide",
        "Iron Head",
        "Play Rough"
      ],
      "nature": "Adamant",
      "item": "Adrenaline Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 174,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LYCANROC:1",
      "originalSpeciesKey": "LYCANROC:1",
      "trainerId": "HIKER:Clifford:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Exeggutor [Alolan]": {
    "Ruinmaniac Clark [Slot 1]": {
      "level": 46,
      "ability": "Frisk",
      "moves": [
        "Energy Ball",
        "Dragon Pulse",
        "Low Kick",
        "Psyshock"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 175,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EXEGGUTOR:1",
      "originalSpeciesKey": "EXEGGUTOR:1",
      "trainerId": "RUINMANIAC:Clark:0",
      "slot": 1,
      "doubles": false
    },
    "Burglar Drago [Slot 2]": {
      "level": 70,
      "ability": "Harvest",
      "moves": [
        "Wood Hammer",
        "Low Kick",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "Quick Claw",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 268,
      "gender": "F",
      "shiny": false,
      "speciesKey": "EXEGGUTOR:1",
      "originalSpeciesKey": "EXEGGUTOR:1",
      "trainerId": "BURGLAR:Drago:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Aurorus": {
    "Ruinmaniac Clark [Slot 2]": {
      "level": 47,
      "ability": "Refrigerate",
      "moves": [
        "Power Gem",
        "Hyper Voice",
        "Freeze-Dry",
        "Mirror Coat"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 175,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AURORUS:0",
      "originalSpeciesKey": "AURORUS:0",
      "trainerId": "RUINMANIAC:Clark:0",
      "slot": 2,
      "doubles": false
    },
    "Ruinmaniac Vince [Slot 4]": {
      "level": 67,
      "ability": "Refrigerate",
      "moves": [
        "Hyper Voice",
        "Freeze-Dry",
        "Earth Power",
        "Substitute"
      ],
      "nature": "Timid",
      "item": "Ice Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 241,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AURORUS:0",
      "originalSpeciesKey": "AURORUS:0",
      "trainerId": "RUINMANIAC:Vince:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Tyrantrum": {
    "Ruinmaniac Clark [Slot 3]": {
      "level": 47,
      "ability": "Strong Jaw",
      "moves": [
        "Rock Slide",
        "Scale Shot",
        "Psychic Fangs",
        "Substitute"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 175,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TYRANTRUM:0",
      "originalSpeciesKey": "TYRANTRUM:0",
      "trainerId": "RUINMANIAC:Clark:0",
      "slot": 3,
      "doubles": false
    },
    "Supernerd Jebediah [Slot 2]": {
      "level": 48,
      "ability": "Rock Head",
      "moves": [
        "Rock Slide",
        "Dragon Claw",
        "Earthquake",
        "Dragon Dance"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 202,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TYRANTRUM:0",
      "originalSpeciesKey": "TYRANTRUM:0",
      "trainerId": "SUPERNERD:Jebediah:0",
      "slot": 2,
      "doubles": false
    },
    "Ruinmaniac Vince [Slot 3]": {
      "level": 66,
      "ability": "Rock Head",
      "moves": [
        "Head Smash",
        "Scale Shot",
        "Earthquake",
        "Substitute"
      ],
      "nature": "Jolly",
      "item": "Dragon Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 241,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TYRANTRUM:0",
      "originalSpeciesKey": "TYRANTRUM:0",
      "trainerId": "RUINMANIAC:Vince:0",
      "slot": 3,
      "doubles": false
    },
    "Gym Leader Blaine #1 [Slot 5]": {
      "level": 72,
      "ability": "Rock Head",
      "moves": [
        "Head Smash",
        "Scale Shot",
        "Close Combat"
      ],
      "nature": "Adamant",
      "item": "Air Balloon",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 270,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TYRANTRUM:0",
      "originalSpeciesKey": "TYRANTRUM:0",
      "trainerId": "LEADER_Blaine:Blaine:0",
      "slot": 5,
      "doubles": false
    },
    "Gym Leader Blaine #2 (DOUBLES) [Slot 5]": {
      "level": 72,
      "ability": "Rock Head",
      "moves": [
        "Head Smash",
        "Scale Shot",
        "Close Combat"
      ],
      "nature": "Adamant",
      "item": "Air Balloon",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 271,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TYRANTRUM:0",
      "originalSpeciesKey": "TYRANTRUM:0",
      "trainerId": "LEADER_Blaine:Blaine:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Gigalith": {
    "Ruinmaniac Clark [Slot 4]": {
      "level": 47,
      "ability": "Clear Body",
      "moves": [
        "Stone Edge",
        "Earthquake",
        "Body Press",
        "Sand Tomb"
      ],
      "nature": "Adamant",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 175,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GIGALITH:0",
      "originalSpeciesKey": "GIGALITH:0",
      "trainerId": "RUINMANIAC:Clark:0",
      "slot": 4,
      "doubles": false
    },
    "Hiker Bart [Slot 2]": {
      "level": 64,
      "ability": "Clear Body",
      "moves": [
        "Stone Edge",
        "Earthquake",
        "Body Press",
        "Sand Tomb"
      ],
      "nature": "Adamant",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 235,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GIGALITH:0",
      "originalSpeciesKey": "GIGALITH:0",
      "trainerId": "HIKER:Bart:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Eelektross": {
    "Hiker Michael [Slot 2]": {
      "level": 47,
      "ability": "Levitate",
      "moves": [
        "Thunderbolt",
        "Flamethrower",
        "Grass Knot",
        "Toxic"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 176,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EELEKTROSS:0",
      "originalSpeciesKey": "EELEKTROSS:0",
      "trainerId": "HIKER:Michael:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #20 [Slot 1]": {
      "level": 73,
      "ability": "Levitate",
      "moves": [
        "Thunder",
        "Aqua Tail",
        "Sludge Bomb"
      ],
      "nature": "Naive",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 284,
      "gender": "F",
      "shiny": false,
      "speciesKey": "EELEKTROSS:0",
      "originalSpeciesKey": "EELEKTROSS:0",
      "trainerId": "GALACTIC_M:Grunt:23",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer M Matt [Slot 4]": {
      "level": 95,
      "ability": "Levitate",
      "moves": [
        "Discharge",
        "Flamethrower",
        "Sludge Bomb",
        "Knock Off"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 296,
      "gender": "F",
      "shiny": false,
      "speciesKey": "EELEKTROSS:0",
      "originalSpeciesKey": "EELEKTROSS:0",
      "trainerId": "COOLTRAINER_M:Matt:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Camerupt": {
    "Hiker Michael [Slot 3]": {
      "level": 47,
      "ability": "Own Tempo",
      "moves": [
        "Eruption",
        "Earthquake",
        "Stone Edge",
        "Yawn"
      ],
      "nature": "Quiet",
      "item": "Quick Claw",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 176,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CAMERUPT:0",
      "originalSpeciesKey": "CAMERUPT:0",
      "trainerId": "HIKER:Michael:0",
      "slot": 3,
      "doubles": false
    },
    "Engineer Orville [Slot 3]": {
      "level": 54,
      "ability": "Solid Rock",
      "moves": [
        "Flamethrower",
        "Earth Power",
        "Steam Eruption",
        "Rock Slide"
      ],
      "nature": "Quiet",
      "item": "Quick Claw",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 212,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CAMERUPT:0",
      "originalSpeciesKey": "CAMERUPT:0",
      "trainerId": "ENGINEER:Orville:0",
      "slot": 3,
      "doubles": false
    },
    "Juggler Santino [Slot 3]": {
      "level": 67,
      "ability": "Magma Armor",
      "moves": [
        "Explosion",
        "Body Slam",
        "Double-Edge",
        "Eruption"
      ],
      "nature": "Serious",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 249,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CAMERUPT:0",
      "originalSpeciesKey": "CAMERUPT:0",
      "trainerId": "JUGGLER:Santino:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Seismitoad": {
    "Cooltrainer F Alize [Slot 2]": {
      "level": 95,
      "ability": "Swift Swim",
      "moves": [
        "Scald",
        "Earth Power",
        "Sludge Bomb",
        "Power Whip"
      ],
      "nature": "Rash",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 301,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SEISMITOAD:0",
      "originalSpeciesKey": "SEISMITOAD:0",
      "trainerId": "COOLTRAINER_F:Alize:0",
      "slot": 2,
      "doubles": false
    },
    "Pokémon Ranger Dylan (DOUBLES) [Slot 2]": {
      "level": 48,
      "ability": "Water Absorb",
      "moves": [
        "Muddy Water",
        "Earth Power",
        "Venoshock",
        "Toxic"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 177,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SEISMITOAD:0",
      "originalSpeciesKey": "SEISMITOAD:0",
      "trainerId": "POKEMONRANGER_M:Dylan:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Ferrothorn": {
    "Hiker Kenny [Slot 3]": {
      "level": 53,
      "ability": "Iron Barbs",
      "moves": [
        "Power Whip",
        "Gyro Ball",
        "Knock Off",
        "Thunder Wave"
      ],
      "nature": "Brave",
      "item": "Rocky Helmet",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 213,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FERROTHORN:0",
      "originalSpeciesKey": "FERROTHORN:0",
      "trainerId": "HIKER:Kenny:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer M Wes [Slot 1]": {
      "level": 94,
      "ability": "Iron Barbs",
      "moves": [
        "Stealth Rock",
        "Spikes",
        "Power Whip",
        "Gyro Ball"
      ],
      "nature": "Sassy",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 298,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FERROTHORN:0",
      "originalSpeciesKey": "FERROTHORN:0",
      "trainerId": "COOLTRAINER_M:Wes:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer M Nicolas [Slot 2]": {
      "level": 95,
      "ability": "Iron Barbs",
      "moves": [
        "Power Whip",
        "Body Press",
        "Knock Off",
        "Leech Seed"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 309,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FERROTHORN:0",
      "originalSpeciesKey": "FERROTHORN:0",
      "trainerId": "COOLTRAINER_M:Nicolas:0",
      "slot": 2,
      "doubles": false
    },
    "Pokémon Ranger Dylan (DOUBLES) [Slot 3]": {
      "level": 47,
      "ability": "Iron Barbs",
      "moves": [
        "Seed Bomb",
        "Body Press",
        "Iron Defense",
        "Leech Seed"
      ],
      "nature": "Sassy",
      "item": "Rocky Helmet",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 177,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FERROTHORN:0",
      "originalSpeciesKey": "FERROTHORN:0",
      "trainerId": "POKEMONRANGER_M:Dylan:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Sigilyph": {
    "Psychic F Summer [Slot 2]": {
      "level": 64,
      "ability": "Magic Guard",
      "moves": [
        "Psychic",
        "Air Slash",
        "Heat Wave",
        "Energy Ball"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 234,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SIGILYPH:0",
      "originalSpeciesKey": "SIGILYPH:0",
      "trainerId": "PSYCHIC_F:Summer:0",
      "slot": 2,
      "doubles": false
    },
    "Pokémon Ranger Dylan (DOUBLES) [Slot 4]": {
      "level": 48,
      "ability": "Magic Guard",
      "moves": [
        "Psychic",
        "Air Slash",
        "Heat Wave",
        "Energy Ball"
      ],
      "nature": "Modest",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 177,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SIGILYPH:0",
      "originalSpeciesKey": "SIGILYPH:0",
      "trainerId": "POKEMONRANGER_M:Dylan:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Lopunny [Mega Lopunny]": {
    "Pokémon Ranger Dylan (DOUBLES) [Slot 5]": {
      "level": 49,
      "ability": "Scrappy",
      "moves": [
        "Fake Out",
        "Facade",
        "Close Combat",
        "Triple Axel"
      ],
      "nature": "Adamant",
      "item": "Lopunnite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 177,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LOPUNNY:1",
      "originalSpeciesKey": "LOPUNNY:0",
      "trainerId": "POKEMONRANGER_M:Dylan:0",
      "slot": 5,
      "doubles": true
    }
  },
  "Crustle": {
    "Gentleman Bernarnd [Slot 1]": {
      "level": 46,
      "ability": "Weak Armor",
      "moves": [
        "X-Scissor",
        "Stone Edge",
        "Stomping Tantrum",
        "Knock Off"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 178,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CRUSTLE:0",
      "originalSpeciesKey": "CRUSTLE:0",
      "trainerId": "GENTLEMAN:Bernarnd:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Bart [Slot 1]": {
      "level": 63,
      "ability": "Weak Armor",
      "moves": [
        "X-Scissor",
        "Stone Edge",
        "Earthquake",
        "Shell Smash"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 235,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CRUSTLE:0",
      "originalSpeciesKey": "CRUSTLE:0",
      "trainerId": "HIKER:Bart:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Wesley (DOUBLES) [Slot 2]": {
      "level": 67,
      "ability": "Sturdy",
      "moves": [
        "Stealth Rock",
        "X-Scissor",
        "Rock Slide"
      ],
      "nature": "Jolly",
      "item": "Red Card",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 239,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CRUSTLE:0",
      "originalSpeciesKey": "CRUSTLE:0",
      "trainerId": "COOLTRAINER_M:Wesley:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Florges": {
    "Beauty Clarissa [Slot 1]": {
      "level": 46,
      "ability": "Flower Veil",
      "moves": [
        "Dazzling Gleam",
        "Giga Drain",
        "Pollen Puff",
        "Tearful Look"
      ],
      "nature": "Calm",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 179,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FLORGES:0",
      "originalSpeciesKey": "FLORGES:0",
      "trainerId": "BEAUTY:Clarissa:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Vanilluxe": {
    "Beauty Clarissa [Slot 2]": {
      "level": 47,
      "ability": "Filter",
      "moves": [
        "Ice Shard",
        "Frost Breath",
        "Extrasensory",
        "Explosion"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 179,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VANILLUXE:0",
      "originalSpeciesKey": "VANILLUXE:0",
      "trainerId": "BEAUTY:Clarissa:0",
      "slot": 2,
      "doubles": false
    },
    "Lady Tami [Slot 1]": {
      "level": 66,
      "ability": "Filter",
      "moves": [
        "Ice Shard",
        "Blizzard",
        "Freeze-Dry",
        "Explosion"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 254,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VANILLUXE:0",
      "originalSpeciesKey": "VANILLUXE:0",
      "trainerId": "LADY:Tami:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Electrode [Hisuian]": {
    "Beauty Clarissa [Slot 3]": {
      "level": 48,
      "ability": "Aftermath",
      "moves": [
        "Discharge",
        "Energy Ball",
        "Foul Play",
        "Leech Seed"
      ],
      "nature": "Modest",
      "item": "Big Root",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 179,
      "gender": "",
      "shiny": false,
      "speciesKey": "ELECTRODE:1",
      "originalSpeciesKey": "ELECTRODE:1",
      "trainerId": "BEAUTY:Clarissa:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer F Alize [Slot 3]": {
      "level": 95,
      "ability": "Static",
      "moves": [
        "Thunder",
        "Energy Ball",
        "Explosion",
        "Hidden Power"
      ],
      "nature": "Rash",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 30
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 301,
      "gender": "",
      "shiny": false,
      "speciesKey": "ELECTRODE:1",
      "originalSpeciesKey": "ELECTRODE:1",
      "trainerId": "COOLTRAINER_F:Alize:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Passimian": {
    "Gentleman Phillip [Slot 1]": {
      "level": 46,
      "ability": "Defiant",
      "moves": [
        "Close Combat",
        "Rock Slide",
        "Acrobatics",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 180,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PASSIMIAN:0",
      "originalSpeciesKey": "PASSIMIAN:0",
      "trainerId": "GENTLEMAN:Phillip:0",
      "slot": 1,
      "doubles": false
    },
    "Blackbelt Corey [Slot 1]": {
      "level": 57,
      "ability": "Defiant",
      "moves": [
        "Close Combat",
        "Rock Slide",
        "Knock Off",
        "Acrobatics"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 225,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PASSIMIAN:0",
      "originalSpeciesKey": "PASSIMIAN:0",
      "trainerId": "BLACKBELT:Corey:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Oinkologne": {
    "Gentleman Phillip [Slot 3]": {
      "level": 47,
      "ability": "Thick Fat",
      "moves": [
        "Headbutt",
        "Zen Headbutt",
        "High Horsepower",
        "Lash Out"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 180,
      "gender": "M",
      "shiny": false,
      "speciesKey": "OINKOLOGNE:0",
      "originalSpeciesKey": "OINKOLOGNE:0",
      "trainerId": "GENTLEMAN:Phillip:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Golisopod": {
    "Gentleman Phillip [Slot 4]": {
      "level": 48,
      "ability": "Emergency Exit",
      "moves": [
        "First Impression",
        "Leech Life",
        "Liquidation",
        "Rock Slide"
      ],
      "nature": "Careful",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 180,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GOLISOPOD:0",
      "originalSpeciesKey": "GOLISOPOD:0",
      "trainerId": "GENTLEMAN:Phillip:0",
      "slot": 4,
      "doubles": false
    },
    "Elite Four Aaron #1 [Slot 4]": {
      "level": 99,
      "ability": "Emergency Exit",
      "moves": [
        "First Impression",
        "X-Scissor",
        "Liquidation",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 314,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GOLISOPOD:0",
      "originalSpeciesKey": "GOLISOPOD:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:0",
      "slot": 4,
      "doubles": false
    },
    "Elite Four Aaron #2 (DOUBLES) [Slot 4]": {
      "level": 99,
      "ability": "Emergency Exit",
      "moves": [
        "First Impression",
        "X-Scissor",
        "Liquidation",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 315,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GOLISOPOD:0",
      "originalSpeciesKey": "GOLISOPOD:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Haxorus": {
    "Gambler Reggie [Slot 2]": {
      "level": 47,
      "ability": "Unnerve",
      "moves": [
        "Dragon Claw",
        "Aqua Tail",
        "Poison Jab",
        "Dragon Dance"
      ],
      "nature": "Impish",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 181,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HAXORUS:0",
      "originalSpeciesKey": "HAXORUS:0",
      "trainerId": "GAMBLER:Reggie:0",
      "slot": 2,
      "doubles": false
    },
    "Supernerd Nathan [Slot 2]": {
      "level": 70,
      "ability": "Unnerve",
      "moves": [
        "Dual Chop",
        "Iron Head",
        "Aqua Tail",
        "Dragon Dance"
      ],
      "nature": "Jolly",
      "item": "Water Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 266,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HAXORUS:0",
      "originalSpeciesKey": "HAXORUS:0",
      "trainerId": "SUPERNERD:Nathan:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Scyther": {
    "Cooltrainer M Julian [Slot 1]": {
      "level": 47,
      "ability": "Technician",
      "moves": [
        "U-turn",
        "Dual Wingbeat"
      ],
      "nature": "Jolly",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 182,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SCYTHER:0",
      "originalSpeciesKey": "SCYTHER:0",
      "trainerId": "COOLTRAINER_M:Julian:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Tauros": {
    "Cooltrainer M Julian [Slot 3]": {
      "level": 47,
      "ability": "Sheer Force",
      "moves": [
        "Body Slam",
        "Close Combat",
        "Zen Headbutt",
        "Throat Chop"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 182,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TAUROS:0",
      "originalSpeciesKey": "TAUROS:0",
      "trainerId": "COOLTRAINER_M:Julian:0",
      "slot": 3,
      "doubles": false
    },
    "Juggler Seymour [Slot 1]": {
      "level": 66,
      "ability": "Sheer Force",
      "moves": [
        "Body Slam",
        "Iron Tail",
        "Play Rough",
        "Fire Blast"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 253,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TAUROS:0",
      "originalSpeciesKey": "TAUROS:0",
      "trainerId": "JUGGLER:Seymour:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Nikola (DOUBLES) [Slot 4]": {
      "level": 80,
      "ability": "Sheer Force",
      "moves": [
        "Body Slam",
        "Close Combat",
        "Throat Chop"
      ],
      "nature": "Jolly",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 288,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TAUROS:0",
      "originalSpeciesKey": "TAUROS:0",
      "trainerId": "COOLTRAINER_F:Nikola:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Espathra": {
    "Cooltrainer M Julian [Slot 4]": {
      "level": 48,
      "ability": "Speed Boost",
      "moves": [
        "Psychic",
        "Shadow Ball",
        "Dazzling Gleam",
        "Confuse Ray"
      ],
      "nature": "Modest",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 182,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ESPATHRA:0",
      "originalSpeciesKey": "ESPATHRA:0",
      "trainerId": "COOLTRAINER_M:Julian:0",
      "slot": 4,
      "doubles": false
    },
    "Psychic M Juan [Slot 2]": {
      "level": 96,
      "ability": "Speed Boost",
      "moves": [
        "Lumina Crash",
        "Shadow Ball",
        "Dazzling Gleam",
        "Hypnosis"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 306,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ESPATHRA:0",
      "originalSpeciesKey": "ESPATHRA:0",
      "trainerId": "PSYCHIC_M:Juan:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic D Grunt & Grunt (DOUBLES) [Slot 1]": {
      "level": 49,
      "ability": "Speed Boost",
      "moves": [
        "Lumina Crash",
        "Shadow Ball",
        "Aura Sphere",
        "Hypnosis"
      ],
      "nature": "Timid",
      "item": "Weakness Policy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 204,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ESPATHRA:0",
      "originalSpeciesKey": "ESPATHRA:0",
      "trainerId": "GALACTIC_D:Grunt & Grunt:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Jolteon": {
    "Biker Richie [Slot 3]": {
      "level": 49,
      "ability": "Volt Absorb",
      "moves": [
        "Wild Charge",
        "Weather Ball",
        "Hyper Voice",
        "Double-Edge"
      ],
      "nature": "Modest",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 185,
      "gender": "M",
      "shiny": false,
      "speciesKey": "JOLTEON:0",
      "originalSpeciesKey": "JOLTEON:0",
      "trainerId": "BIKER:Richie:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Magnezone": {
    "Biker Rob [Slot 1]": {
      "level": 47,
      "ability": "Magnet Pull",
      "moves": [
        "Mirror Shot",
        "Electroweb",
        "Signal Beam",
        "Thunderbolt"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 186,
      "gender": "",
      "shiny": false,
      "speciesKey": "MAGNEZONE:0",
      "originalSpeciesKey": "MAGNEZONE:0",
      "trainerId": "BIKER:Rob:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Gabite": {
    "Biker Rob [Slot 4]": {
      "level": 49,
      "ability": "Rough Skin",
      "moves": [
        "Dig",
        "Dragon Claw",
        "Sand Tomb",
        "Iron Tail"
      ],
      "nature": "Jolly",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 186,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GABITE:0",
      "originalSpeciesKey": "GABITE:0",
      "trainerId": "BIKER:Rob:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Blastoise": {
    "Biker Sal [Slot 3]": {
      "level": 49,
      "ability": "Torrent",
      "moves": [
        "Razor Shell",
        "Skull Bash",
        "Muddy Water",
        "Ice Beam"
      ],
      "nature": "Naive",
      "item": "Mystic Water",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 187,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BLASTOISE:0",
      "originalSpeciesKey": "BLASTOISE:0",
      "trainerId": "BIKER:Sal:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer M Wes [Slot 3]": {
      "level": 95,
      "ability": "Torrent",
      "moves": [
        "Hydro Pump",
        "Flash Cannon",
        "Ice Beam",
        "Shell Smash"
      ],
      "nature": "Naive",
      "item": "White Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 298,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BLASTOISE:0",
      "originalSpeciesKey": "BLASTOISE:0",
      "trainerId": "COOLTRAINER_M:Wes:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic D Grunt & Grunt (DOUBLES) [Slot 4]": {
      "level": 50,
      "ability": "Torrent",
      "moves": [
        "Fake Out",
        "Muddy Water",
        "Blizzard",
        "Follow Me"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 204,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BLASTOISE:0",
      "originalSpeciesKey": "BLASTOISE:0",
      "trainerId": "GALACTIC_D:Grunt & Grunt:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Kilowattrel": {
    "Rocker Joey [Slot 1]": {
      "level": 47,
      "ability": "Competitive",
      "moves": [
        "Thunder",
        "Air Slash",
        "U-turn"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 188,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KILOWATTREL:0",
      "originalSpeciesKey": "KILOWATTREL:0",
      "trainerId": "ROCKER:Joey:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer M Hawk [Slot 3]": {
      "level": 96,
      "ability": "Wind Power",
      "moves": [
        "Thunderbolt",
        "Air Slash",
        "Tailwind",
        "Roost"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 303,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KILOWATTREL:0",
      "originalSpeciesKey": "KILOWATTREL:0",
      "trainerId": "COOLTRAINER_M:Hawk:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic Commander Saturn #2 (DOUBLES) [Slot 2]": {
      "level": 74,
      "ability": "Wind Power",
      "moves": [
        "Thunderbolt",
        "Air Slash",
        "Roost",
        "Tailwind"
      ],
      "nature": "Modest",
      "item": "Covert Cloak",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 210,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KILOWATTREL:0",
      "originalSpeciesKey": "KILOWATTREL:0",
      "trainerId": "SATURN:Saturn:1",
      "slot": 2,
      "doubles": true
    }
  },
  "Floatzel": {
    "Rocker Joey [Slot 2]": {
      "level": 48,
      "ability": "Swift Swim",
      "moves": [
        "Aqua Jet",
        "Hydro Pump",
        "Ice Beam",
        "Focus Blast"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 188,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FLOATZEL:0",
      "originalSpeciesKey": "FLOATZEL:0",
      "trainerId": "ROCKER:Joey:0",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer F Lumina [Slot 4]": {
      "level": 68,
      "ability": "Water Veil",
      "moves": [
        "Hydro Pump",
        "Blizzard",
        "Focus Blast",
        "Taunt"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 259,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FLOATZEL:0",
      "originalSpeciesKey": "FLOATZEL:0",
      "trainerId": "COOLTRAINER_F:Lumina:0",
      "slot": 4,
      "doubles": false
    },
    "Galactic M Grunt #17 [Slot 3]": {
      "level": 73,
      "ability": "Water Veil",
      "moves": [
        "Aqua Jet",
        "Hydro Pump",
        "Focus Blast",
        "Ice Beam"
      ],
      "nature": "Hasty",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 278,
      "gender": "F",
      "shiny": false,
      "speciesKey": "FLOATZEL:0",
      "originalSpeciesKey": "FLOATZEL:0",
      "trainerId": "GALACTIC_M:Grunt:17",
      "slot": 3,
      "doubles": false
    }
  },
  "Swampert": {
    "Rocker Joey [Slot 4]": {
      "level": 49,
      "ability": "Hydration",
      "moves": [
        "Waterfall",
        "Earthquake",
        "Ice Punch",
        "Substitute"
      ],
      "nature": "Jolly",
      "item": "Rindo Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 188,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SWAMPERT:0",
      "originalSpeciesKey": "SWAMPERT:0",
      "trainerId": "ROCKER:Joey:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Furfrou [Heart Trim]": {
    "Painter Sam [Slot 1]": {
      "level": 48,
      "ability": "Fur Coat",
      "moves": [
        "Crunch",
        "Swagger [SWAGGER]",
        "Sucker Punch",
        "Double-Edge"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 190,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FURFROU:1",
      "originalSpeciesKey": "FURFROU:1",
      "trainerId": "PAINTER:Sam:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Ditto": {
    "Painter Sam [Slot 2]": {
      "level": 49,
      "ability": "Imposter",
      "moves": [
        "Transform"
      ],
      "nature": "Serious",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 190,
      "gender": "",
      "shiny": false,
      "speciesKey": "DITTO:0",
      "originalSpeciesKey": "DITTO:0",
      "trainerId": "PAINTER:Sam:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Giovanni #1 [Slot 4]": {
      "level": 81,
      "ability": "Imposter",
      "moves": [
        "Transform"
      ],
      "nature": "Hasty",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 291,
      "gender": "",
      "shiny": false,
      "speciesKey": "DITTO:0",
      "originalSpeciesKey": "DITTO:0",
      "trainerId": "LEADER_Giovanni:Giovanni:0",
      "slot": 4,
      "doubles": false
    },
    "Gym Leader Giovanni #2 (DOUBLES) [Slot 4]": {
      "level": 81,
      "ability": "Imposter",
      "moves": [
        "Transform"
      ],
      "nature": "Hasty",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 292,
      "gender": "",
      "shiny": false,
      "speciesKey": "DITTO:0",
      "originalSpeciesKey": "DITTO:0",
      "trainerId": "LEADER_Giovanni:Giovanni:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Stantler": {
    "Psychic M Neagle [Slot 2]": {
      "level": 48,
      "ability": "Intimidate",
      "moves": [
        "Hyper Voice",
        "Psyshield Bash",
        "Energy Ball",
        "Me First"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 191,
      "gender": "M",
      "shiny": false,
      "speciesKey": "STANTLER:0",
      "originalSpeciesKey": "STANTLER:0",
      "trainerId": "PSYCHIC_M:Neagle:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Farigiraf": {
    "Psychic M Neagle [Slot 3]": {
      "level": 49,
      "ability": "Armor Tail",
      "moves": [
        "Boomburst",
        "Psyshield Bash",
        "Future Sight",
        "Calm Mind"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 191,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FARIGIRAF:0",
      "originalSpeciesKey": "FARIGIRAF:0",
      "trainerId": "PSYCHIC_M:Neagle:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Wyrdeer": {
    "Psychic M Neagle [Slot 4]": {
      "level": 49,
      "ability": "Sap Sipper",
      "moves": [
        "Double-Edge",
        "Psyshield Bash",
        "Earthquake",
        "Lunge"
      ],
      "nature": "Adamant",
      "item": "Expert Belt",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 191,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WYRDEER:0",
      "originalSpeciesKey": "WYRDEER:0",
      "trainerId": "PSYCHIC_M:Neagle:0",
      "slot": 4,
      "doubles": false
    },
    "Galactic M Grunt #16 [Slot 3]": {
      "level": 73,
      "ability": "Intimidate",
      "moves": [
        "Hyper Voice",
        "Psyshield Bash",
        "Throat Chop",
        "Earthquake"
      ],
      "nature": "Hasty",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 277,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WYRDEER:0",
      "originalSpeciesKey": "WYRDEER:0",
      "trainerId": "GALACTIC_M:Grunt:16",
      "slot": 3,
      "doubles": false
    },
    "Ace Trainer Niel (DOUBLES) [Slot 1]": {
      "level": 79,
      "ability": "Intimidate",
      "moves": [
        "Hyper Voice",
        "Psychic",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Timid",
      "item": "Light Clay",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 289,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WYRDEER:0",
      "originalSpeciesKey": "WYRDEER:0",
      "trainerId": "COOLTRAINER_M:Niel:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Feraligatr": {
    "Hiker Walts [Slot 1]": {
      "level": 47,
      "ability": "Sheer Force",
      "moves": [
        "Liquidation",
        "Crunch",
        "Scary Face",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 192,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FERALIGATR:0",
      "originalSpeciesKey": "FERALIGATR:0",
      "trainerId": "HIKER:Walts:0",
      "slot": 1,
      "doubles": false
    },
    "Ruinmaniac Roonie [Slot 3]": {
      "level": 66,
      "ability": "Torrent",
      "moves": [
        "Liquidation",
        "Scale Shot",
        "Ice Punch",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 244,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FERALIGATR:0",
      "originalSpeciesKey": "FERALIGATR:0",
      "trainerId": "RUINMANIAC:Roonie:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Heliolisk": {
    "Hiker Walts [Slot 2]": {
      "level": 48,
      "ability": "Dry Skin",
      "moves": [
        "Hyper Voice",
        "Thunderbolt",
        "Signal Beam",
        "Grass Knot"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 192,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HELIOLISK:0",
      "originalSpeciesKey": "HELIOLISK:0",
      "trainerId": "HIKER:Walts:0",
      "slot": 2,
      "doubles": false
    },
    "Hiker Tim [Slot 1]": {
      "level": 63,
      "ability": "Sand Veil",
      "moves": [
        "Parabolic Charge",
        "Hyper Voice",
        "Grass Knot",
        "Magnet Rise"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 236,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HELIOLISK:0",
      "originalSpeciesKey": "HELIOLISK:0",
      "trainerId": "HIKER:Tim:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Tavarius (DOUBLES) [Slot 1]": {
      "level": 79,
      "ability": "Dry Skin",
      "moves": [
        "Thunder",
        "Electroweb",
        "Hyper Voice",
        "Grass Knot"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 286,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HELIOLISK:0",
      "originalSpeciesKey": "HELIOLISK:0",
      "trainerId": "COOLTRAINER_M:Tavarius:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Claydol": {
    "Hiker Rocky [Slot 1]": {
      "level": 47,
      "ability": "Levitate",
      "moves": [
        "Drill Run",
        "Stored Power",
        "Body Press",
        "Cosmic Power"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 193,
      "gender": "",
      "shiny": false,
      "speciesKey": "CLAYDOL:0",
      "originalSpeciesKey": "CLAYDOL:0",
      "trainerId": "HIKER:Rocky:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Weavile": {
    "Hiker Rocky [Slot 2]": {
      "level": 48,
      "ability": "Technician",
      "moves": [
        "Fake Out",
        "Ice Shard",
        "Icicle Spear",
        "Aerial Ace"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 193,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WEAVILE:0",
      "originalSpeciesKey": "WEAVILE:0",
      "trainerId": "HIKER:Rocky:0",
      "slot": 2,
      "doubles": false
    },
    "Galacticboss Cyrus #1 [Slot 1]": {
      "level": 61,
      "ability": "Inner Focus",
      "moves": [
        "Ice Shard",
        "Knock Off",
        "Pursuit",
        "Triple Axel"
      ],
      "nature": "Adamant",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 229,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WEAVILE:0",
      "originalSpeciesKey": "WEAVILE:0",
      "trainerId": "GALACTICBOSS:Cyrus:0",
      "slot": 1,
      "doubles": false
    },
    "Galacticboss Cyrus #2 [Slot 1]": {
      "level": 76,
      "ability": "Inner Focus",
      "moves": [
        "Ice Shard",
        "Knock Off",
        "Pursuit",
        "Triple Axel"
      ],
      "nature": "Adamant",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 230,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WEAVILE:0",
      "originalSpeciesKey": "WEAVILE:0",
      "trainerId": "GALACTICBOSS:Cyrus:1",
      "slot": 1,
      "doubles": false
    },
    "Gentleman Kendall [Slot 2]": {
      "level": 68,
      "ability": "Inner Focus",
      "moves": [
        "Pursuit",
        "Triple Axel",
        "Psycho Cut",
        "Low Kick"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 261,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WEAVILE:0",
      "originalSpeciesKey": "WEAVILE:0",
      "trainerId": "GENTLEMAN:Kendall:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Lurantis": {
    "Hiker Rocky [Slot 3]": {
      "level": 49,
      "ability": "Contrary",
      "moves": [
        "Leaf Storm",
        "Leaf Blade",
        "Superpower",
        "Facade"
      ],
      "nature": "Relaxed",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 193,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LURANTIS:0",
      "originalSpeciesKey": "LURANTIS:0",
      "trainerId": "HIKER:Rocky:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Medicham": {
    "Blackbelt Brian [Slot 1]": {
      "level": 47,
      "ability": "Pure Power",
      "moves": [
        "High Jump Kick",
        "Zen Headbutt",
        "Reversal",
        "Counter"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 194,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MEDICHAM:0",
      "originalSpeciesKey": "MEDICHAM:0",
      "trainerId": "BLACKBELT:Brian:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Ray [Slot 2]": {
      "level": 63,
      "ability": "Pure Power",
      "moves": [
        "Drain Punch",
        "Psycho Cut",
        "Recover",
        "Close Combat"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 233,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MEDICHAM:0",
      "originalSpeciesKey": "MEDICHAM:0",
      "trainerId": "HIKER:Ray:0",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Lucian #1 [Slot 2]": {
      "level": 99,
      "ability": "Pure Power",
      "moves": [
        "Close Combat",
        "Zen Headbutt",
        "Blaze Kick"
      ],
      "nature": "Jolly",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 316,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MEDICHAM:0",
      "originalSpeciesKey": "MEDICHAM:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:0",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Lucian #2 (DOUBLES) [Slot 3]": {
      "level": 99,
      "ability": "Pure Power",
      "moves": [
        "Close Combat",
        "Zen Headbutt",
        "Blaze Kick"
      ],
      "nature": "Jolly",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 317,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MEDICHAM:0",
      "originalSpeciesKey": "MEDICHAM:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:1",
      "slot": 3,
      "doubles": true
    }
  },
  "Conkeldurr": {
    "Blackbelt Brian [Slot 2]": {
      "level": 48,
      "ability": "Iron Fist",
      "moves": [
        "Mach Punch",
        "Close Combat",
        "Thunder Punch",
        "Ice Punch"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 194,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CONKELDURR:0",
      "originalSpeciesKey": "CONKELDURR:0",
      "trainerId": "BLACKBELT:Brian:0",
      "slot": 2,
      "doubles": false
    },
    "Blackbelt Damon [Slot 3]": {
      "level": 95,
      "ability": "Iron Fist",
      "moves": [
        "Mach Punch",
        "Drain Punch",
        "Ice Punch",
        "Bulk Up"
      ],
      "nature": "Adamant",
      "item": "Big Root",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 302,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CONKELDURR:0",
      "originalSpeciesKey": "CONKELDURR:0",
      "trainerId": "BLACKBELT:Damon:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Lucario": {
    "Blackbelt Brian [Slot 3]": {
      "level": 49,
      "ability": "Inner Focus",
      "moves": [
        "Vacuum Wave",
        "Flash Cannon",
        "Aura Sphere",
        "Stone Edge"
      ],
      "nature": "Hasty",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 194,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LUCARIO:0",
      "originalSpeciesKey": "LUCARIO:0",
      "trainerId": "BLACKBELT:Brian:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Lapras": {
    "Burglar Max & Greed [Slot 2]": {
      "level": 50,
      "ability": "Shell Armor",
      "moves": [
        "Freeze-Dry",
        "Thunder",
        "Protect",
        "Roar"
      ],
      "nature": "Bold",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 195,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LAPRAS:0",
      "originalSpeciesKey": "LAPRAS:0",
      "trainerId": "UTOPIA_DUO:3:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Ludicolo": {
    "Cooltrainer F Lynette [Slot 3]": {
      "level": 94,
      "ability": "Own Tempo",
      "moves": [
        "Leaf Storm",
        "Scald",
        "Icy Wind",
        "Knock Off"
      ],
      "nature": "Timid",
      "item": "Eject Pack",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 293,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LUDICOLO:0",
      "originalSpeciesKey": "LUDICOLO:0",
      "trainerId": "COOLTRAINER_F:Lynette:0",
      "slot": 3,
      "doubles": false
    },
    "Burglar Max & Greed [Slot 3]": {
      "level": 49,
      "ability": "Swift Swim",
      "moves": [
        "Fake Out",
        "Waterfall",
        "Seed Bomb",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 195,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LUDICOLO:0",
      "originalSpeciesKey": "LUDICOLO:0",
      "trainerId": "UTOPIA_DUO:3:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Togedemaru": {
    "Youngster Adam [Slot 2]": {
      "level": 48,
      "ability": "Iron Barbs",
      "moves": [
        "Steel Roller",
        "Iron Head",
        "Zing Zap",
        "Magnet Rise"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 198,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TOGEDEMARU:0",
      "originalSpeciesKey": "TOGEDEMARU:0",
      "trainerId": "YOUNGSTER:Adam:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Dugtrio": {
    "Hiker Felix [Slot 1]": {
      "level": 47,
      "ability": "Arena Trap",
      "moves": [
        "Earthquake",
        "Night Slash",
        "Slash",
        "Double Team"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 199,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DUGTRIO:0",
      "originalSpeciesKey": "DUGTRIO:0",
      "trainerId": "HIKER:Felix:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Cradily": {
    "Hiker Felix [Slot 2]": {
      "level": 48,
      "ability": "Suction Cups",
      "moves": [
        "Ancient Power",
        "Giga Drain",
        "Earth Power",
        "Cosmic Power"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 199,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CRADILY:0",
      "originalSpeciesKey": "CRADILY:0",
      "trainerId": "HIKER:Felix:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Diggersby": {
    "Hiker Felix [Slot 3]": {
      "level": 49,
      "ability": "Huge Power",
      "moves": [
        "Quick Attack",
        "Body Slam",
        "High Horsepower",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Chople Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 199,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DIGGERSBY:0",
      "originalSpeciesKey": "DIGGERSBY:0",
      "trainerId": "HIKER:Felix:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Heatmor": {
    "Picnicker Lo [Slot 1]": {
      "level": 48,
      "ability": "White Smoke",
      "moves": [
        "Flare Blitz",
        "Focus Blast",
        "Thunder Punch",
        "Grass Knot"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 200,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HEATMOR:0",
      "originalSpeciesKey": "HEATMOR:0",
      "trainerId": "PICNICKER:Lo:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Durant": {
    "Picnicker Lo [Slot 2]": {
      "level": 49,
      "ability": "Hustle",
      "moves": [
        "Iron Head",
        "X-Scissor",
        "Rock Slide",
        "Hone Claws"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 200,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DURANT:0",
      "originalSpeciesKey": "DURANT:0",
      "trainerId": "PICNICKER:Lo:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Slowking": {
    "Picnicker Lo [Slot 3]": {
      "level": 49,
      "ability": "Regenerator",
      "moves": [
        "Psychic",
        "Surf",
        "Slack Off",
        "Toxic"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 200,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SLOWKING:0",
      "originalSpeciesKey": "SLOWKING:0",
      "trainerId": "PICNICKER:Lo:0",
      "slot": 3,
      "doubles": false
    },
    "Tamer Markus [Slot 1]": {
      "level": 56,
      "ability": "Oblivious",
      "moves": [
        "Safeguard",
        "Aqua Tail",
        "Surf",
        "Psychic"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 221,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLOWKING:0",
      "originalSpeciesKey": "SLOWKING:0",
      "trainerId": "TAMER:Markus:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer F Kumiko [Slot 2]": {
      "level": 94,
      "ability": "Regenerator",
      "moves": [
        "Scald",
        "Future Sight",
        "Flamethrower",
        "Dragon Tail"
      ],
      "nature": "Bold",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 294,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLOWKING:0",
      "originalSpeciesKey": "SLOWKING:0",
      "trainerId": "COOLTRAINER_F:Kumiko:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Togekiss": {
    "Picnicker Lo [Slot 4]": {
      "level": 50,
      "ability": "Super Luck",
      "moves": [
        "Air Cutter",
        "Dazzling Gleam",
        "Aura Sphere",
        "Roost"
      ],
      "nature": "Timid",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 200,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOGEKISS:0",
      "originalSpeciesKey": "TOGEKISS:0",
      "trainerId": "PICNICKER:Lo:0",
      "slot": 4,
      "doubles": false
    },
    "Galactic M Grunt #13 [Slot 3]": {
      "level": 72,
      "ability": "Serene Grace",
      "moves": [
        "Air Slash",
        "Flamethrower",
        "Aura Sphere",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 273,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TOGEKISS:0",
      "originalSpeciesKey": "TOGEKISS:0",
      "trainerId": "GALACTIC_M:Grunt:12",
      "slot": 3,
      "doubles": false
    },
    "Pokemonranger M Sid [Slot 1]": {
      "level": 94,
      "ability": "Super Luck",
      "moves": [
        "Extreme Speed",
        "Moonblast",
        "Air Slash",
        "Flamethrower"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 297,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TOGEKISS:0",
      "originalSpeciesKey": "TOGEKISS:0",
      "trainerId": "POKEMONRANGER_M:Sid:0",
      "slot": 1,
      "doubles": false
    },
    "Cynthia Cynthia #1 [Slot 1]": {
      "level": 100,
      "ability": "Super Luck",
      "moves": [
        "Dazzling Gleam",
        "Air Slash",
        "Flamethrower"
      ],
      "nature": "Modest",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 318,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TOGEKISS:0",
      "originalSpeciesKey": "TOGEKISS:0",
      "trainerId": "CYNTHIA:Cynthia:0",
      "slot": 1,
      "doubles": false
    },
    "Cynthia Cynthia #2 (DOUBLES) [Slot 1]": {
      "level": 100,
      "ability": "Super Luck",
      "moves": [
        "Dazzling Gleam",
        "Air Slash",
        "Flamethrower"
      ],
      "nature": "Modest",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 319,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TOGEKISS:0",
      "originalSpeciesKey": "TOGEKISS:0",
      "trainerId": "CYNTHIA:Cynthia:1",
      "slot": 1,
      "doubles": true
    }
  },
  "Vaporeon": {
    "Sailor Keith [Slot 1]": {
      "level": 48,
      "ability": "Hydration",
      "moves": [
        "Scald",
        "Alluring Voice",
        "Icy Wind",
        "Acid Armor"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 201,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VAPOREON:0",
      "originalSpeciesKey": "VAPOREON:0",
      "trainerId": "SAILOR:Keith:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Comfey": {
    "Sailor Keith [Slot 2]": {
      "level": 48,
      "ability": "Triage",
      "moves": [
        "Draining Kiss",
        "Giga Drain",
        "Calm Mind",
        "Leech Seed"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 201,
      "gender": "M",
      "shiny": false,
      "speciesKey": "COMFEY:0",
      "originalSpeciesKey": "COMFEY:0",
      "trainerId": "SAILOR:Keith:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Araquanid": {
    "Sailor Keith [Slot 3]": {
      "level": 49,
      "ability": "Water Bubble",
      "moves": [
        "Liquidation",
        "X-Scissor",
        "Poison Jab",
        "Protect"
      ],
      "nature": "Impish",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 201,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARAQUANID:0",
      "originalSpeciesKey": "ARAQUANID:0",
      "trainerId": "SAILOR:Keith:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Jynx": {
    "Supernerd Jebediah [Slot 1]": {
      "level": 48,
      "ability": "Dry Skin",
      "moves": [
        "Ice Beam",
        "Psychic",
        "Fake Tears",
        "Lovely Kiss"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 202,
      "gender": "F",
      "shiny": false,
      "speciesKey": "JYNX:0",
      "originalSpeciesKey": "JYNX:0",
      "trainerId": "SUPERNERD:Jebediah:0",
      "slot": 1,
      "doubles": false
    },
    "Pokemonranger F Mell [Slot 4]": {
      "level": 95,
      "ability": "Dry Skin",
      "moves": [
        "Ice Beam",
        "Psycho Boost",
        "Focus Blast",
        "Lovely Kiss"
      ],
      "nature": "Timid",
      "item": "White Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 299,
      "gender": "F",
      "shiny": false,
      "speciesKey": "JYNX:0",
      "originalSpeciesKey": "JYNX:0",
      "trainerId": "POKEMONRANGER_F:Mell:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Drampa": {
    "Supernerd Jebediah [Slot 3]": {
      "level": 49,
      "ability": "Berserk",
      "moves": [
        "Hyper Voice",
        "Dragon Breath",
        "Flamethrower",
        "Roost"
      ],
      "nature": "Modest",
      "item": "Normal Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 202,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAMPA:0",
      "originalSpeciesKey": "DRAMPA:0",
      "trainerId": "SUPERNERD:Jebediah:0",
      "slot": 3,
      "doubles": false
    },
    "Burglar Addison [Slot 2]": {
      "level": 67,
      "ability": "Berserk",
      "moves": [
        "Hyper Voice",
        "Dragon Pulse",
        "Roost"
      ],
      "nature": "Modest",
      "item": "Iapapa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 247,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAMPA:0",
      "originalSpeciesKey": "DRAMPA:0",
      "trainerId": "BURGLAR:Addison:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Appletun": {
    "Aromalady Eileen [Slot 2]": {
      "level": 48,
      "ability": "Thick Fat",
      "moves": [
        "Sucker Punch",
        "Apple Acid",
        "Dragon Pulse",
        "Recover"
      ],
      "nature": "Quiet",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 203,
      "gender": "M",
      "shiny": false,
      "speciesKey": "APPLETUN:0",
      "originalSpeciesKey": "APPLETUN:0",
      "trainerId": "AROMALADY:Eileen:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic M Grunt #15 [Slot 3]": {
      "level": 72,
      "ability": "Gluttony",
      "moves": [
        "Apple Acid",
        "Dragon Pulse",
        "Leech Seed",
        "Recover"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 275,
      "gender": "M",
      "shiny": false,
      "speciesKey": "APPLETUN:0",
      "originalSpeciesKey": "APPLETUN:0",
      "trainerId": "GALACTIC_M:Grunt:14",
      "slot": 3,
      "doubles": false
    }
  },
  "Sliggoo": {
    "Aromalady Eileen [Slot 3]": {
      "level": 49,
      "ability": "Gooey",
      "moves": [
        "Dragon Breath",
        "Muddy Water",
        "Infestation",
        "Protect"
      ],
      "nature": "Modest",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 203,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SLIGGOO:0",
      "originalSpeciesKey": "SLIGGOO:0",
      "trainerId": "AROMALADY:Eileen:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Centiskorch": {
    "Galactic M Grunt #8 [Slot 2]": {
      "level": 49,
      "ability": "Flame Body",
      "moves": [
        "Fire Lash",
        "Leech Life",
        "Knock Off",
        "Coil"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 205,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CENTISKORCH:0",
      "originalSpeciesKey": "CENTISKORCH:0",
      "trainerId": "GALACTIC_M:Grunt:7",
      "slot": 2,
      "doubles": false
    }
  },
  "Aerodactyl": {
    "Galactic M Grunt #10 [Slot 3]": {
      "level": 49,
      "ability": "Unnerve",
      "moves": [
        "Stone Edge",
        "Dual Wingbeat",
        "Thunder Fang",
        "Iron Head"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 207,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AERODACTYL:0",
      "originalSpeciesKey": "AERODACTYL:0",
      "trainerId": "GALACTIC_M:Grunt:9",
      "slot": 3,
      "doubles": false
    }
  },
  "Lunatone": {
    "Galactic M Grunt #10 [Slot 4]": {
      "level": 50,
      "ability": "Levitate",
      "moves": [
        "Power Gem",
        "Psychic",
        "Moonblast",
        "Calm Mind"
      ],
      "nature": "Modest",
      "item": "Colbur Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 207,
      "gender": "",
      "shiny": false,
      "speciesKey": "LUNATONE:0",
      "originalSpeciesKey": "LUNATONE:0",
      "trainerId": "GALACTIC_M:Grunt:9",
      "slot": 4,
      "doubles": false
    }
  },
  "Solrock": {
    "Galactic M Grunt #11 [Slot 4]": {
      "level": 50,
      "ability": "Levitate",
      "moves": [
        "Rock Slide",
        "Zen Headbutt",
        "Flare Blitz",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Passho Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 208,
      "gender": "",
      "shiny": false,
      "speciesKey": "SOLROCK:0",
      "originalSpeciesKey": "SOLROCK:0",
      "trainerId": "GALACTIC_M:Grunt:10",
      "slot": 4,
      "doubles": false
    }
  },
  "Nidoking": {
    "Pokemonranger M Auron [Slot 4]": {
      "level": 96,
      "ability": "Sheer Force",
      "moves": [
        "Sludge Wave",
        "Earth Power",
        "Ice Beam",
        "Counter"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 308,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NIDOKING:0",
      "originalSpeciesKey": "NIDOKING:0",
      "trainerId": "POKEMONRANGER_M:Auron:0",
      "slot": 4,
      "doubles": false
    },
    "Galactic Commander Saturn #1 (DOUBLES) [Slot 3]": {
      "level": 51,
      "ability": "Sheer Force",
      "moves": [
        "Poison Jab",
        "Drill Run",
        "Thunderbolt",
        "Flamethrower"
      ],
      "nature": "Hasty",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 209,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NIDOKING:0",
      "originalSpeciesKey": "NIDOKING:0",
      "trainerId": "SATURN:Saturn:0",
      "slot": 3,
      "doubles": true
    },
    "Galactic Commander Saturn #2 (DOUBLES) [Slot 3]": {
      "level": 74,
      "ability": "Sheer Force",
      "moves": [
        "Poison Jab",
        "Drill Run",
        "Thunderbolt",
        "Flamethrower"
      ],
      "nature": "Hasty",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 210,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NIDOKING:0",
      "originalSpeciesKey": "NIDOKING:0",
      "trainerId": "SATURN:Saturn:1",
      "slot": 3,
      "doubles": true
    }
  },
  "Overqwil": {
    "Cooltrainer F Alize [Slot 4]": {
      "level": 95,
      "ability": "Swift Swim",
      "moves": [
        "Throat Chop",
        "Gunk Shot",
        "Liquidation",
        "Destiny Bond"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 301,
      "gender": "F",
      "shiny": false,
      "speciesKey": "OVERQWIL:0",
      "originalSpeciesKey": "OVERQWIL:1",
      "trainerId": "COOLTRAINER_F:Alize:0",
      "slot": 4,
      "doubles": false
    },
    "Galactic Commander Saturn #1 (DOUBLES) [Slot 4]": {
      "level": 51,
      "ability": "Intimidate",
      "moves": [
        "Poison Jab",
        "Throat Chop",
        "Liquidation",
        "Icy Wind"
      ],
      "nature": "Jolly",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 209,
      "gender": "M",
      "shiny": false,
      "speciesKey": "OVERQWIL:0",
      "originalSpeciesKey": "OVERQWIL:1",
      "trainerId": "SATURN:Saturn:0",
      "slot": 4,
      "doubles": true
    },
    "Galactic Commander Saturn #2 (DOUBLES) [Slot 4]": {
      "level": 74,
      "ability": "Intimidate",
      "moves": [
        "Poison Jab",
        "Throat Chop",
        "Liquidation",
        "Icy Wind"
      ],
      "nature": "Jolly",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 210,
      "gender": "M",
      "shiny": false,
      "speciesKey": "OVERQWIL:0",
      "originalSpeciesKey": "OVERQWIL:1",
      "trainerId": "SATURN:Saturn:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Dewgong": {
    "Lady Tami [Slot 2]": {
      "level": 67,
      "ability": "Ice Body",
      "moves": [
        "Blizzard",
        "Drill Run",
        "Substitute",
        "Protect"
      ],
      "nature": "Sassy",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 254,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DEWGONG:0",
      "originalSpeciesKey": "DEWGONG:0",
      "trainerId": "LADY:Tami:0",
      "slot": 2,
      "doubles": false
    },
    "Galactic Commander Saturn #1 (DOUBLES) [Slot 5]": {
      "level": 51,
      "ability": "Thick Fat",
      "moves": [
        "Fake Out",
        "Hydro Pump",
        "Freeze-Dry"
      ],
      "nature": "Relaxed",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 209,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DEWGONG:0",
      "originalSpeciesKey": "DEWGONG:0",
      "trainerId": "SATURN:Saturn:0",
      "slot": 5,
      "doubles": true
    },
    "Galactic Commander Saturn #2 (DOUBLES) [Slot 5]": {
      "level": 74,
      "ability": "Thick Fat",
      "moves": [
        "Fake Out",
        "Muddy Water",
        "Freeze-Dry",
        "Drill Run"
      ],
      "nature": "Relaxed",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 210,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DEWGONG:0",
      "originalSpeciesKey": "DEWGONG:0",
      "trainerId": "SATURN:Saturn:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Absol [Mega Absol Z]": {
    "Galactic Commander Saturn #1 (DOUBLES) [Slot 6]": {
      "level": 52,
      "ability": "Sharpness",
      "moves": [
        "Shadow Claw",
        "Knock Off",
        "Play Rough"
      ],
      "nature": "Jolly",
      "item": "Absolite Z",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 209,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ABSOL:2",
      "originalSpeciesKey": "ABSOL:0",
      "trainerId": "SATURN:Saturn:0",
      "slot": 6,
      "doubles": true
    },
    "Galactic Commander Saturn #2 (DOUBLES) [Slot 6]": {
      "level": 75,
      "ability": "Sharpness",
      "moves": [
        "Poltergeist",
        "Knock Off",
        "Play Rough"
      ],
      "nature": "Jolly",
      "item": "Absolite Z",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 210,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ABSOL:2",
      "originalSpeciesKey": "ABSOL:0",
      "trainerId": "SATURN:Saturn:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Skarmory": {
    "Engineer Terrell [Slot 1]": {
      "level": 52,
      "ability": "Sturdy",
      "moves": [
        "Stealth Rock",
        "Spikes",
        "Dual Wingbeat",
        "Body Press"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 211,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SKARMORY:0",
      "originalSpeciesKey": "SKARMORY:0",
      "trainerId": "ENGINEER:Terrell:0",
      "slot": 1,
      "doubles": false
    },
    "Ruinmaniac Braid [Slot 1]": {
      "level": 65,
      "ability": "Sturdy",
      "moves": [
        "Stealth Rock",
        "Iron Head",
        "Body Press",
        "Whirlwind"
      ],
      "nature": "Naive",
      "item": "Red Card",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 243,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SKARMORY:0",
      "originalSpeciesKey": "SKARMORY:0",
      "trainerId": "RUINMANIAC:Braid:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Perrserker": {
    "Engineer Terrell [Slot 2]": {
      "level": 53,
      "ability": "Steely Spirit",
      "moves": [
        "Bullet Punch",
        "Iron Tail",
        "Close Combat",
        "Gunk Shot"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 211,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PERRSERKER:0",
      "originalSpeciesKey": "PERRSERKER:2",
      "trainerId": "ENGINEER:Terrell:0",
      "slot": 2,
      "doubles": false
    },
    "Ace Trainer Forrest (DOUBLES) [Slot 4]": {
      "level": 68,
      "ability": "Steely Spirit",
      "moves": [
        "Fake Out",
        "Iron Tail",
        "Close Combat",
        "Metal Sound"
      ],
      "nature": "Brave",
      "item": "Occa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 263,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PERRSERKER:0",
      "originalSpeciesKey": "PERRSERKER:2",
      "trainerId": "COOLTRAINER_M:Forrest:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Scizor": {
    "Engineer Terrell [Slot 3]": {
      "level": 53,
      "ability": "Technician",
      "moves": [
        "Bullet Punch",
        "Dual Wingbeat",
        "Knock Off",
        "U-turn"
      ],
      "nature": "Sassy",
      "item": "Occa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 211,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SCIZOR:0",
      "originalSpeciesKey": "SCIZOR:0",
      "trainerId": "ENGINEER:Terrell:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer M Lewis [Slot 3]": {
      "level": 94,
      "ability": "Technician",
      "moves": [
        "Bullet Punch",
        "Bug Bite",
        "Dual Wingbeat",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 295,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SCIZOR:0",
      "originalSpeciesKey": "SCIZOR:0",
      "trainerId": "COOLTRAINER_M:Lewis:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Hippowdon": {
    "Engineer Orville [Slot 1]": {
      "level": 52,
      "ability": "Sand Stream",
      "moves": [
        "Earthquake",
        "Ice Fang",
        "Crunch",
        "Slack Off"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 212,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HIPPOWDON:0",
      "originalSpeciesKey": "HIPPOWDON:0",
      "trainerId": "ENGINEER:Orville:0",
      "slot": 1,
      "doubles": false
    },
    "Hiker Hubert [Slot 1]": {
      "level": 53,
      "ability": "Sand Stream",
      "moves": [
        "Earthquake",
        "Rock Slide",
        "Slack Off",
        "Curse"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 217,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HIPPOWDON:0",
      "originalSpeciesKey": "HIPPOWDON:0",
      "trainerId": "HIKER:Hubert:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer M Nicolas [Slot 1]": {
      "level": 95,
      "ability": "Sand Stream",
      "moves": [
        "Stealth Rock",
        "Earthquake",
        "Ice Fang",
        "Crunch"
      ],
      "nature": "Careful",
      "item": "Smooth Rock",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 309,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HIPPOWDON:0",
      "originalSpeciesKey": "HIPPOWDON:0",
      "trainerId": "COOLTRAINER_M:Nicolas:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Sandaconda": {
    "Hiker Kenny [Slot 1]": {
      "level": 52,
      "ability": "Sand Spit",
      "moves": [
        "Earthquake",
        "Stone Edge",
        "Fire Fang",
        "Glare"
      ],
      "nature": "Careful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 213,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SANDACONDA:0",
      "originalSpeciesKey": "SANDACONDA:0",
      "trainerId": "HIKER:Kenny:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Whiscash": {
    "Hiker Kenny [Slot 2]": {
      "level": 53,
      "ability": "Sheer Force",
      "moves": [
        "Liquidation",
        "Earth Power",
        "Ice Beam",
        "Dragon Dance"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 213,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WHISCASH:0",
      "originalSpeciesKey": "WHISCASH:0",
      "trainerId": "HIKER:Kenny:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Dugtrio [Alolan]": {
    "Hiker Kenny [Slot 4]": {
      "level": 54,
      "ability": "Tangling Hair",
      "moves": [
        "Earthquake",
        "Iron Head",
        "Stone Edge",
        "Reversal"
      ],
      "nature": "Jolly",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 213,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DUGTRIO:1",
      "originalSpeciesKey": "DUGTRIO:1",
      "trainerId": "HIKER:Kenny:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Bastiodon": {
    "Hiker Pedro [Slot 1]": {
      "level": 52,
      "ability": "Sturdy",
      "moves": [
        "Stealth Rock",
        "Metal Burst",
        "Heavy Slam",
        "Roar"
      ],
      "nature": "Brave",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 214,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BASTIODON:0",
      "originalSpeciesKey": "BASTIODON:0",
      "trainerId": "HIKER:Pedro:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Duraludon": {
    "Hiker Pedro [Slot 2]": {
      "level": 53,
      "ability": "Heavy Metal",
      "moves": [
        "Heavy Slam",
        "Dragon Pulse",
        "Dragon Tail",
        "Thunderbolt"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 214,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DURALUDON:0",
      "originalSpeciesKey": "DURALUDON:0",
      "trainerId": "HIKER:Pedro:0",
      "slot": 2,
      "doubles": false
    },
    "Burglar Gilligan [Slot 1]": {
      "level": 69,
      "ability": "Heavy Metal",
      "moves": [
        "Stealth Rock",
        "Heavy Slam",
        "Draco Meteor",
        "Body Press"
      ],
      "nature": "Relaxed",
      "item": "Iapapa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 269,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DURALUDON:0",
      "originalSpeciesKey": "DURALUDON:0",
      "trainerId": "BURGLAR:Gilligan:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Klinklang": {
    "Hiker Pedro [Slot 4]": {
      "level": 54,
      "ability": "Clear Body",
      "moves": [
        "Gear Grind",
        "Wild Charge",
        "High Horsepower",
        "Shift Gear"
      ],
      "nature": "Adamant",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 214,
      "gender": "",
      "shiny": false,
      "speciesKey": "KLINKLANG:0",
      "originalSpeciesKey": "KLINKLANG:0",
      "trainerId": "HIKER:Pedro:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Gastrodon [East Sea]": {
    "Engineer Braven [Slot 3]": {
      "level": 54,
      "ability": "Sticky Hold",
      "moves": [
        "Muddy Water",
        "Earth Power",
        "Toxic",
        "Recover"
      ],
      "nature": "Bold",
      "item": "Rindo Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 215,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GASTRODON:1",
      "originalSpeciesKey": "GASTRODON:1",
      "trainerId": "ENGINEER:Braven:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Empoleon": {
    "Engineer Andrew [Slot 1]": {
      "level": 53,
      "ability": "Competitive",
      "moves": [
        "Aqua Jet",
        "Iron Head",
        "Drill Peck",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 216,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EMPOLEON:0",
      "originalSpeciesKey": "EMPOLEON:0",
      "trainerId": "ENGINEER:Andrew:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Mamoswine": {
    "Engineer Andrew [Slot 2]": {
      "level": 53,
      "ability": "Oblivious",
      "moves": [
        "Ice Shard",
        "Icicle Crash",
        "High Horsepower",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 216,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAMOSWINE:0",
      "originalSpeciesKey": "MAMOSWINE:0",
      "trainerId": "ENGINEER:Andrew:0",
      "slot": 2,
      "doubles": false
    },
    "Gentleman Heath [Slot 4]": {
      "level": 68,
      "ability": "Thick Fat",
      "moves": [
        "Icicle Crash",
        "Earthquake",
        "Stone Edge",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 257,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MAMOSWINE:0",
      "originalSpeciesKey": "MAMOSWINE:0",
      "trainerId": "GENTLEMAN:Heath:0",
      "slot": 4,
      "doubles": false
    },
    "Cooltrainer M Jazz [Slot 3]": {
      "level": 96,
      "ability": "Thick Fat",
      "moves": [
        "Ice Shard",
        "Icicle Crash",
        "Earthquake",
        "Superpower"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 305,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAMOSWINE:0",
      "originalSpeciesKey": "MAMOSWINE:0",
      "trainerId": "COOLTRAINER_M:Jazz:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Goodra [Hisuian]": {
    "Engineer Andrew [Slot 4]": {
      "level": 54,
      "ability": "Shell Armor",
      "moves": [
        "Heavy Slam",
        "Dragon Tail",
        "Earthquake",
        "Curse"
      ],
      "nature": "Impish",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 216,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GOODRA:1",
      "originalSpeciesKey": "GOODRA:1",
      "trainerId": "ENGINEER:Andrew:0",
      "slot": 4,
      "doubles": false
    },
    "Beauty Jenn [Slot 2]": {
      "level": 69,
      "ability": "Shell Armor",
      "moves": [
        "Heavy Slam",
        "Dragon Claw",
        "Earthquake",
        "Curse"
      ],
      "nature": "Impish",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 258,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GOODRA:1",
      "originalSpeciesKey": "GOODRA:1",
      "trainerId": "BEAUTY:Jenn:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Rhyperior": {
    "Hiker Hubert [Slot 3]": {
      "level": 53,
      "ability": "Solid Rock",
      "moves": [
        "Stealth Rock",
        "Earthquake",
        "Stone Edge",
        "Heat Crash"
      ],
      "nature": "Careful",
      "item": "Passho Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 0
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 217,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RHYPERIOR:0",
      "originalSpeciesKey": "RHYPERIOR:0",
      "trainerId": "HIKER:Hubert:0",
      "slot": 3,
      "doubles": false
    },
    "Hiker Justin [Slot 2]": {
      "level": 68,
      "ability": "Solid Rock",
      "moves": [
        "Earthquake",
        "Stone Edge",
        "Ice Punch"
      ],
      "nature": "Adamant",
      "item": "Weakness Policy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 246,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RHYPERIOR:0",
      "originalSpeciesKey": "RHYPERIOR:0",
      "trainerId": "HIKER:Justin:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Aggron": {
    "Gym Leader Byron #1 [Slot 1]": {
      "level": 55,
      "ability": "Sturdy",
      "moves": [
        "Stealth Rock",
        "Heavy Slam",
        "Metal Burst",
        "Stone Edge"
      ],
      "nature": "Brave",
      "item": "Custap Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 218,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AGGRON:0",
      "originalSpeciesKey": "AGGRON:0",
      "trainerId": "LEADER_Byron:Byron:0",
      "slot": 1,
      "doubles": false
    },
    "Gym Leader Byron #2 (DOUBLES) [Slot 1]": {
      "level": 55,
      "ability": "Sturdy",
      "moves": [
        "Stealth Rock",
        "Heavy Slam",
        "Metal Burst",
        "Stone Edge"
      ],
      "nature": "Brave",
      "item": "Custap Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 219,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AGGRON:0",
      "originalSpeciesKey": "AGGRON:0",
      "trainerId": "LEADER_Byron:Byron:1",
      "slot": 1,
      "doubles": true
    }
  },
  "Excadrill": {
    "Gym Leader Byron #1 [Slot 2]": {
      "level": 55,
      "ability": "Sand Rush",
      "moves": [
        "Earthquake",
        "Iron Head",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 218,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EXCADRILL:0",
      "originalSpeciesKey": "EXCADRILL:0",
      "trainerId": "LEADER_Byron:Byron:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Byron #2 (DOUBLES) [Slot 2]": {
      "level": 55,
      "ability": "Sand Rush",
      "moves": [
        "High Horsepower",
        "Iron Head",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 219,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EXCADRILL:0",
      "originalSpeciesKey": "EXCADRILL:0",
      "trainerId": "LEADER_Byron:Byron:1",
      "slot": 2,
      "doubles": true
    },
    "Hiker Tim [Slot 3]": {
      "level": 65,
      "ability": "Sand Force",
      "moves": [
        "Earthquake",
        "Iron Head",
        "Rock Slide"
      ],
      "nature": "Adamant",
      "item": "Air Balloon",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 236,
      "gender": "F",
      "shiny": false,
      "speciesKey": "EXCADRILL:0",
      "originalSpeciesKey": "EXCADRILL:0",
      "trainerId": "HIKER:Tim:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Iron Treads": {
    "Gym Leader Byron #1 [Slot 3]": {
      "level": 55,
      "ability": "Quark Drive",
      "moves": [
        "Iron Head",
        "Earthquake",
        "Ice Spinner"
      ],
      "nature": "Jolly",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 218,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONTREADS:0",
      "originalSpeciesKey": "IRONTREADS:0",
      "trainerId": "LEADER_Byron:Byron:0",
      "slot": 3,
      "doubles": false
    },
    "Gym Leader Byron #2 (DOUBLES) [Slot 3]": {
      "level": 55,
      "ability": "Quark Drive",
      "moves": [
        "Iron Head",
        "High Horsepower",
        "Ice Spinner"
      ],
      "nature": "Jolly",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 219,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONTREADS:0",
      "originalSpeciesKey": "IRONTREADS:0",
      "trainerId": "LEADER_Byron:Byron:1",
      "slot": 3,
      "doubles": true
    }
  },
  "Archaludon": {
    "Gym Leader Byron #1 [Slot 5]": {
      "level": 55,
      "ability": "Stamina",
      "moves": [
        "Flash Cannon",
        "Dragon Pulse",
        "Electro Shot"
      ],
      "nature": "Timid",
      "item": "Power Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 218,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARCHALUDON:0",
      "originalSpeciesKey": "ARCHALUDON:0",
      "trainerId": "LEADER_Byron:Byron:0",
      "slot": 5,
      "doubles": false
    },
    "Gym Leader Byron #2 (DOUBLES) [Slot 5]": {
      "level": 55,
      "ability": "Stamina",
      "moves": [
        "Flash Cannon",
        "Dragon Pulse",
        "Electro Shot"
      ],
      "nature": "Timid",
      "item": "Power Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 219,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARCHALUDON:0",
      "originalSpeciesKey": "ARCHALUDON:0",
      "trainerId": "LEADER_Byron:Byron:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Steelix [Mega Steelix]": {
    "Gym Leader Byron #1 [Slot 6]": {
      "level": 56,
      "ability": "Sand Force",
      "moves": [
        "Heavy Slam",
        "Earthquake",
        "Body Press",
        "Iron Defense"
      ],
      "nature": "Brave",
      "item": "Steelixite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 218,
      "gender": "M",
      "shiny": false,
      "speciesKey": "STEELIX:1",
      "originalSpeciesKey": "STEELIX:0",
      "trainerId": "LEADER_Byron:Byron:0",
      "slot": 6,
      "doubles": false
    },
    "Gym Leader Byron #2 (DOUBLES) [Slot 6]": {
      "level": 56,
      "ability": "Sand Force",
      "moves": [
        "Heavy Slam",
        "High Horsepower",
        "Body Press",
        "Iron Defense"
      ],
      "nature": "Brave",
      "item": "Steelixite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 219,
      "gender": "M",
      "shiny": false,
      "speciesKey": "STEELIX:1",
      "originalSpeciesKey": "STEELIX:0",
      "trainerId": "LEADER_Byron:Byron:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Jumpluff": {
    "Aromalady Adelaide [Slot 2]": {
      "level": 57,
      "ability": "Infiltrator",
      "moves": [
        "Seed Bomb",
        "Acrobatics",
        "Spore",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 220,
      "gender": "M",
      "shiny": false,
      "speciesKey": "JUMPLUFF:0",
      "originalSpeciesKey": "JUMPLUFF:0",
      "trainerId": "AROMALADY:Adelaide:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Vileplume": {
    "Aromalady Adelaide [Slot 3]": {
      "level": 58,
      "ability": "Effect Spore",
      "moves": [
        "Giga Drain",
        "Sludge Bomb",
        "Sleep Powder",
        "Strength Sap"
      ],
      "nature": "Modest",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 220,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VILEPLUME:0",
      "originalSpeciesKey": "VILEPLUME:0",
      "trainerId": "AROMALADY:Adelaide:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Basculegion [Female]": {
    "Tamer Markus [Slot 2]": {
      "level": 57,
      "ability": "Mold Breaker",
      "moves": [
        "Wave Crash",
        "Thrash",
        "Double-Edge",
        "Head Smash"
      ],
      "nature": "Bashful",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 221,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BASCULEGION:1",
      "originalSpeciesKey": "BASCULEGION:1",
      "trainerId": "TAMER:Markus:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Hydreigon": {
    "Tamer Markus [Slot 3]": {
      "level": 57,
      "ability": "Levitate",
      "moves": [
        "Crunch",
        "Scary Face",
        "Dragon Pulse",
        "Aura Sphere"
      ],
      "nature": "Bashful",
      "item": "Chople Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 221,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HYDREIGON:0",
      "originalSpeciesKey": "HYDREIGON:0",
      "trainerId": "TAMER:Markus:0",
      "slot": 3,
      "doubles": false
    },
    "Burglar Gilligan [Slot 2]": {
      "level": 70,
      "ability": "Levitate",
      "moves": [
        "Draco Meteor",
        "Iron Tail",
        "Earthquake",
        "Aqua Tail"
      ],
      "nature": "Naive",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 269,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HYDREIGON:0",
      "originalSpeciesKey": "HYDREIGON:0",
      "trainerId": "BURGLAR:Gilligan:0",
      "slot": 2,
      "doubles": false
    },
    "Pokemonranger F Mell [Slot 3]": {
      "level": 95,
      "ability": "Levitate",
      "moves": [
        "Dark Pulse",
        "Dragon Pulse",
        "Flash Cannon",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 299,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HYDREIGON:0",
      "originalSpeciesKey": "HYDREIGON:0",
      "trainerId": "POKEMONRANGER_F:Mell:0",
      "slot": 3,
      "doubles": false
    },
    "Ace Trainer Kyle & Molly [Slot 2]": {
      "level": 63,
      "ability": "Levitate",
      "moves": [
        "Dark Pulse",
        "Dragon Pulse",
        "Flash Cannon",
        "Heat Wave"
      ],
      "nature": "Timid",
      "item": "Roseli Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 227,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HYDREIGON:0",
      "originalSpeciesKey": "HYDREIGON:0",
      "trainerId": "UTOPIA_DUO:4:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Arcanine [Hisuian]": {
    "Tamer Markus [Slot 4]": {
      "level": 58,
      "ability": "Intimidate",
      "moves": [
        "Crunch",
        "Stone Edge",
        "Close Combat",
        "Flare Blitz"
      ],
      "nature": "Bashful",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 221,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARCANINE:1",
      "originalSpeciesKey": "ARCANINE:1",
      "trainerId": "TAMER:Markus:0",
      "slot": 4,
      "doubles": false
    },
    "Cooltrainer M Lewis [Slot 2]": {
      "level": 94,
      "ability": "Rock Head",
      "moves": [
        "Extreme Speed",
        "Flare Blitz",
        "Head Smash",
        "Close Combat"
      ],
      "nature": "Adamant",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 295,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARCANINE:1",
      "originalSpeciesKey": "ARCANINE:1",
      "trainerId": "COOLTRAINER_M:Lewis:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Braviary": {
    "Birdkeeper Kiyo [Slot 1]": {
      "level": 58,
      "ability": "Defiant",
      "moves": [
        "Crush Claw",
        "Dual Wingbeat",
        "Close Combat",
        "Agility"
      ],
      "nature": "Adamant",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 222,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRAVIARY:0",
      "originalSpeciesKey": "BRAVIARY:0",
      "trainerId": "BIRDKEEPER:Kiyo:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Nikola (DOUBLES) [Slot 2]": {
      "level": 79,
      "ability": "Sheer Force",
      "moves": [
        "Body Slam",
        "Brave Bird",
        "Rock Slide",
        "Zen Headbutt"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 288,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRAVIARY:0",
      "originalSpeciesKey": "BRAVIARY:0",
      "trainerId": "COOLTRAINER_F:Nikola:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Braviary [Hisuian]": {
    "Birdkeeper Kiyo [Slot 2]": {
      "level": 59,
      "ability": "Sheer Force",
      "moves": [
        "Psychic",
        "Air Slash",
        "Heat Wave",
        "Agility"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 222,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BRAVIARY:1",
      "originalSpeciesKey": "BRAVIARY:1",
      "trainerId": "BIRDKEEPER:Kiyo:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Delphox": {
    "Pokemonranger M Derek [Slot 4]": {
      "level": 60,
      "ability": "Magic Guard",
      "moves": [
        "Mystical Fire",
        "Psyshock",
        "Foul Play",
        "Switcheroo"
      ],
      "nature": "Timid",
      "item": "Sticky Barb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 223,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DELPHOX:0",
      "originalSpeciesKey": "DELPHOX:0",
      "trainerId": "POKEMONRANGER_M:Derek:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Magcargo": {
    "Hiker Jared [Slot 1]": {
      "level": 57,
      "ability": "Shell Armor",
      "moves": [
        "Flamethrower",
        "Power Gem",
        "Earth Power",
        "Shell Smash"
      ],
      "nature": "Timid",
      "item": "Red Card",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 224,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAGCARGO:0",
      "originalSpeciesKey": "MAGCARGO:0",
      "trainerId": "HIKER:Jared:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Heracross": {
    "Blackbelt Corey [Slot 3]": {
      "level": 59,
      "ability": "Guts",
      "moves": [
        "Close Combat",
        "Megahorn",
        "Retaliate",
        "Facade"
      ],
      "nature": "Jolly",
      "item": "Flame Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 225,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HERACROSS:0",
      "originalSpeciesKey": "HERACROSS:0",
      "trainerId": "BLACKBELT:Corey:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Ambipom": {
    "Youngster Petey [Slot 1]": {
      "level": 57,
      "ability": "Technician",
      "moves": [
        "Dual Chop",
        "Switcheroo",
        "Last Resort",
        "Tail Slap"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 226,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AMBIPOM:0",
      "originalSpeciesKey": "AMBIPOM:0",
      "trainerId": "YOUNGSTER:Petey:0",
      "slot": 1,
      "doubles": false
    },
    "Galactic M Grunt #14 [Slot 2]": {
      "level": 72,
      "ability": "Technician",
      "moves": [
        "Tail Slap",
        "Fake Out",
        "Low Kick",
        "Covet"
      ],
      "nature": "Jolly",
      "item": "Muscle Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 274,
      "gender": "F",
      "shiny": false,
      "speciesKey": "AMBIPOM:0",
      "originalSpeciesKey": "AMBIPOM:0",
      "trainerId": "GALACTIC_M:Grunt:13",
      "slot": 2,
      "doubles": false
    }
  },
  "Pikachu": {
    "Youngster Petey [Slot 3]": {
      "level": 59,
      "ability": "Static",
      "moves": [
        "Surf",
        "Encore",
        "Extreme Speed",
        "Volt Tackle"
      ],
      "nature": "Hasty",
      "item": "Light Ball",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 226,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PIKACHU:0",
      "originalSpeciesKey": "PIKACHU:11",
      "trainerId": "YOUNGSTER:Petey:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Sceptile [Mega Sceptile]": {
    "Ace Trainer Kyle & Molly [Slot 3]": {
      "level": 63,
      "ability": "Limber",
      "moves": [
        "Leaf Blade",
        "Dragon Claw",
        "Earthquake",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Sceptilite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 227,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SCEPTILE:1",
      "originalSpeciesKey": "SCEPTILE:0",
      "trainerId": "UTOPIA_DUO:4:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Dragapult": {
    "Psychic F Summer [Slot 1]": {
      "level": 63,
      "ability": "Cursed Body",
      "moves": [
        "Dragon Breath",
        "Hex",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Timid",
      "item": "Light Clay",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 234,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAGAPULT:0",
      "originalSpeciesKey": "DRAGAPULT:0",
      "trainerId": "PSYCHIC_F:Summer:0",
      "slot": 1,
      "doubles": false
    },
    "Gym Leader Blaine #1 [Slot 1]": {
      "level": 72,
      "ability": "Clear Body",
      "moves": [
        "Sucker Punch",
        "Dragon Darts",
        "Shadow Ball",
        "Fire Blast"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 270,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAGAPULT:0",
      "originalSpeciesKey": "DRAGAPULT:0",
      "trainerId": "LEADER_Blaine:Blaine:0",
      "slot": 1,
      "doubles": false
    },
    "Gym Leader Blaine #2 (DOUBLES) [Slot 1]": {
      "level": 72,
      "ability": "Clear Body",
      "moves": [
        "Dragon Darts",
        "Shadow Ball",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Naive",
      "item": "Light Clay",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 271,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAGAPULT:0",
      "originalSpeciesKey": "DRAGAPULT:0",
      "trainerId": "LEADER_Blaine:Blaine:1",
      "slot": 1,
      "doubles": true
    },
    "Ace Trainer Kyle & Molly [Slot 4]": {
      "level": 62,
      "ability": "Clear Body",
      "moves": [
        "Dragon Darts",
        "Acrobatics",
        "Dragon Dance"
      ],
      "nature": "Jolly",
      "item": "Flying Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 227,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DRAGAPULT:0",
      "originalSpeciesKey": "DRAGAPULT:0",
      "trainerId": "UTOPIA_DUO:4:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Noivern": {
    "Burglar Rocko [Slot 2]": {
      "level": 70,
      "ability": "Infiltrator",
      "moves": [
        "Air Slash",
        "Dragon Pulse",
        "Flamethrower",
        "Tailwind"
      ],
      "nature": "Timid",
      "item": "Fire Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 265,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NOIVERN:0",
      "originalSpeciesKey": "NOIVERN:0",
      "trainerId": "BURGLAR:Rocko:0",
      "slot": 2,
      "doubles": false
    },
    "Ace Trainer Kyle & Molly [Slot 1]": {
      "level": 62,
      "ability": "Infiltrator",
      "moves": [
        "Air Slash",
        "Dragon Pulse",
        "Heat Wave",
        "Dragon Cheer"
      ],
      "nature": "Timid",
      "item": "Covert Cloak",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 227,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NOIVERN:0",
      "originalSpeciesKey": "NOIVERN:0",
      "trainerId": "UTOPIA_DUO:4:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Sandy Shocks": {
    "Galacticboss Cyrus #1 [Slot 2]": {
      "level": 61,
      "ability": "Protosynthesis",
      "moves": [
        "Discharge",
        "Earth Power",
        "Flash Cannon",
        "Iron Defense"
      ],
      "nature": "Bold",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 229,
      "gender": "",
      "shiny": false,
      "speciesKey": "SANDYSHOCKS:0",
      "originalSpeciesKey": "SANDYSHOCKS:0",
      "trainerId": "GALACTICBOSS:Cyrus:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Dracovish": {
    "Galacticboss Cyrus #1 [Slot 4]": {
      "level": 61,
      "ability": "Strong Jaw",
      "moves": [
        "Dragon Rush",
        "Fishious Rend",
        "Psychic Fangs",
        "Crunch"
      ],
      "nature": "Jolly",
      "item": "Salac Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 229,
      "gender": "",
      "shiny": false,
      "speciesKey": "DRACOVISH:0",
      "originalSpeciesKey": "DRACOVISH:0",
      "trainerId": "GALACTICBOSS:Cyrus:0",
      "slot": 4,
      "doubles": false
    },
    "Galacticboss Cyrus #2 [Slot 4]": {
      "level": 76,
      "ability": "Strong Jaw",
      "moves": [
        "Dragon Rush",
        "Fishious Rend",
        "Psychic Fangs",
        "Crunch"
      ],
      "nature": "Adamant",
      "item": "Salac Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 230,
      "gender": "",
      "shiny": false,
      "speciesKey": "DRACOVISH:0",
      "originalSpeciesKey": "DRACOVISH:0",
      "trainerId": "GALACTICBOSS:Cyrus:1",
      "slot": 4,
      "doubles": false
    }
  },
  "Moltres [Galarian]": {
    "Galacticboss Cyrus #1 [Slot 5]": {
      "level": 61,
      "ability": "Berserk",
      "moves": [
        "Fiery Wrath",
        "Hurricane",
        "Agility"
      ],
      "nature": "Timid",
      "item": "Iapapa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 229,
      "gender": "",
      "shiny": false,
      "speciesKey": "MOLTRES:1",
      "originalSpeciesKey": "MOLTRES:1",
      "trainerId": "GALACTICBOSS:Cyrus:0",
      "slot": 5,
      "doubles": false
    },
    "Galacticboss Cyrus #2 [Slot 5]": {
      "level": 76,
      "ability": "Berserk",
      "moves": [
        "Fiery Wrath",
        "Hurricane",
        "Tailwind"
      ],
      "nature": "Timid",
      "item": "Iapapa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 230,
      "gender": "",
      "shiny": false,
      "speciesKey": "MOLTRES:1",
      "originalSpeciesKey": "MOLTRES:1",
      "trainerId": "GALACTICBOSS:Cyrus:1",
      "slot": 5,
      "doubles": false
    }
  },
  "Delphox [Mega Delphox]": {
    "Galacticboss Cyrus #1 [Slot 6]": {
      "level": 62,
      "ability": "Levitate",
      "moves": [
        "Burn Up",
        "Psyshock",
        "Dazzling Gleam"
      ],
      "nature": "Timid",
      "item": "Delphoxite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 229,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DELPHOX:1",
      "originalSpeciesKey": "DELPHOX:0",
      "trainerId": "GALACTICBOSS:Cyrus:0",
      "slot": 6,
      "doubles": false
    },
    "Galacticboss Cyrus #2 [Slot 6]": {
      "level": 77,
      "ability": "Levitate",
      "moves": [
        "Burn Up",
        "Psyshock",
        "Dazzling Gleam"
      ],
      "nature": "Timid",
      "item": "Delphoxite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 230,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DELPHOX:1",
      "originalSpeciesKey": "DELPHOX:0",
      "trainerId": "GALACTICBOSS:Cyrus:1",
      "slot": 6,
      "doubles": false
    }
  },
  "Raging Bolt": {
    "Galacticboss Cyrus #2 [Slot 2]": {
      "level": 76,
      "ability": "Protosynthesis",
      "moves": [
        "Thunderclap",
        "Thunderbolt",
        "Dragon Pulse"
      ],
      "nature": "Timid",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 230,
      "gender": "",
      "shiny": false,
      "speciesKey": "RAGINGBOLT:0",
      "originalSpeciesKey": "RAGINGBOLT:0",
      "trainerId": "GALACTICBOSS:Cyrus:1",
      "slot": 2,
      "doubles": false
    }
  },
  "Iron Hands": {
    "Galacticboss Cyrus #3 [Slot 1]": {
      "level": 77,
      "ability": "Quark Drive",
      "moves": [
        "Drain Punch",
        "Supercell Slam",
        "Ice Punch",
        "Stomping Tantrum"
      ],
      "nature": "Adamant",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 231,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONHANDS:0",
      "originalSpeciesKey": "IRONHANDS:0",
      "trainerId": "GALACTICBOSS:Cyrus:2",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Bruno #1 [Slot 3]": {
      "level": 99,
      "ability": "Quark Drive",
      "moves": [
        "Drain Punch",
        "Thunder Punch",
        "Ice Punch"
      ],
      "nature": "Adamant",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 312,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONHANDS:0",
      "originalSpeciesKey": "IRONHANDS:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:0",
      "slot": 3,
      "doubles": false
    },
    "Elite Four Bruno #2 (DOUBLES) [Slot 3]": {
      "level": 99,
      "ability": "Quark Drive",
      "moves": [
        "Drain Punch",
        "Thunder Punch",
        "Ice Punch"
      ],
      "nature": "Adamant",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 313,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONHANDS:0",
      "originalSpeciesKey": "IRONHANDS:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:1",
      "slot": 3,
      "doubles": true
    }
  },
  "Melmetal": {
    "Galacticboss Cyrus #3 [Slot 3]": {
      "level": 78,
      "ability": "Iron Fist",
      "moves": [
        "Iron Head",
        "Thunder Punch",
        "Ice Punch",
        "Body Press"
      ],
      "nature": "Careful",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 231,
      "gender": "",
      "shiny": false,
      "speciesKey": "MELMETAL:0",
      "originalSpeciesKey": "MELMETAL:0",
      "trainerId": "GALACTICBOSS:Cyrus:2",
      "slot": 3,
      "doubles": false
    }
  },
  "Leavanny": {
    "Pokemaniac Boone [Slot 1]": {
      "level": 62,
      "ability": "Overcoat",
      "moves": [
        "X-Scissor",
        "Wild Charge",
        "Leaf Blade",
        "Grass Whistle"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 232,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LEAVANNY:0",
      "originalSpeciesKey": "LEAVANNY:0",
      "trainerId": "POKEMANIAC:Boone:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Stoutland": {
    "Pokemaniac Boone [Slot 3]": {
      "level": 64,
      "ability": "Sand Rush",
      "moves": [
        "Retaliate",
        "Strength",
        "Play Rough",
        "Thunder Fang"
      ],
      "nature": "Adamant",
      "item": "Silk Scarf",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 232,
      "gender": "M",
      "shiny": false,
      "speciesKey": "STOUTLAND:0",
      "originalSpeciesKey": "STOUTLAND:0",
      "trainerId": "POKEMANIAC:Boone:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer M Nicolas [Slot 3]": {
      "level": 96,
      "ability": "Sand Rush",
      "moves": [
        "Strength",
        "Retaliate",
        "Close Combat",
        "Play Rough"
      ],
      "nature": "Adamant",
      "item": "Silk Scarf",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 309,
      "gender": "M",
      "shiny": false,
      "speciesKey": "STOUTLAND:0",
      "originalSpeciesKey": "STOUTLAND:0",
      "trainerId": "COOLTRAINER_M:Nicolas:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Mandibuzz": {
    "Hiker Ray [Slot 1]": {
      "level": 63,
      "ability": "Overcoat",
      "moves": [
        "Double-Edge",
        "Brave Bird",
        "Tailwind",
        "Hurricane"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 233,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MANDIBUZZ:0",
      "originalSpeciesKey": "MANDIBUZZ:0",
      "trainerId": "HIKER:Ray:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Alakazam": {
    "Psychic M Sheldon [Slot 3]": {
      "level": 65,
      "ability": "Magic Guard",
      "moves": [
        "Psychic",
        "Aura Sphere",
        "Shadow Ball"
      ],
      "nature": "Timid",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 237,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ALAKAZAM:0",
      "originalSpeciesKey": "ALAKAZAM:0",
      "trainerId": "PSYCHIC_M:Sheldon:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Grimmsnarl": {
    "Gym Leader Giovanni #2 (DOUBLES) [Slot 1]": {
      "level": 81,
      "ability": "Prankster",
      "moves": [
        "Spirit Break",
        "Light Screen",
        "Reflect",
        "Swagger"
      ],
      "nature": "Naive",
      "item": "Light Clay",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 292,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRIMMSNARL:0",
      "originalSpeciesKey": "GRIMMSNARL:0",
      "trainerId": "LEADER_Giovanni:Giovanni:1",
      "slot": 1,
      "doubles": true
    },
    "Ace Trainer Wesley (DOUBLES) [Slot 5]": {
      "level": 68,
      "ability": "Prankster",
      "moves": [
        "Fake Out",
        "Foul Play",
        "Swagger [SWAGGER]",
        "Thunder Wave"
      ],
      "nature": "Impish",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 239,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRIMMSNARL:0",
      "originalSpeciesKey": "GRIMMSNARL:0",
      "trainerId": "COOLTRAINER_M:Wesley:0",
      "slot": 5,
      "doubles": true
    }
  },
  "Aerodactyl [Mega Aerodactyl]": {
    "Ace Trainer Wesley (DOUBLES) [Slot 6]": {
      "level": 69,
      "ability": "Tough Claws",
      "moves": [
        "Stone Edge",
        "Dual Wingbeat",
        "Thunder Fang",
        "Hone Claws"
      ],
      "nature": "Jolly",
      "item": "Aerodactylite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 239,
      "gender": "M",
      "shiny": false,
      "speciesKey": "AERODACTYL:1",
      "originalSpeciesKey": "AERODACTYL:0",
      "trainerId": "COOLTRAINER_M:Wesley:0",
      "slot": 6,
      "doubles": true
    }
  },
  "Flygon": {
    "Rocker Leroy [Slot 2]": {
      "level": 65,
      "ability": "Levitate",
      "moves": [
        "Scorching Sands",
        "Dragon Claw",
        "Flamethrower",
        "Roost"
      ],
      "nature": "Hasty",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 240,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FLYGON:0",
      "originalSpeciesKey": "FLYGON:0",
      "trainerId": "ROCKER:Leroy:0",
      "slot": 2,
      "doubles": false
    },
    "Supernerd Gabriel [Slot 2]": {
      "level": 70,
      "ability": "Levitate",
      "moves": [
        "Earthquake",
        "Scale Shot",
        "Fire Punch",
        "Dragon Dance"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 264,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FLYGON:0",
      "originalSpeciesKey": "FLYGON:0",
      "trainerId": "SUPERNERD:Gabriel:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Bisharp": {
    "Ruinmaniac Harold [Slot 4]": {
      "level": 67,
      "ability": "Defiant",
      "moves": [
        "Sucker Punch",
        "Iron Head",
        "Poison Jab",
        "Thunder Wave"
      ],
      "nature": "Jolly",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 242,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BISHARP:0",
      "originalSpeciesKey": "BISHARP:0",
      "trainerId": "RUINMANIAC:Harold:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Glimmora": {
    "Ruinmaniac Braid [Slot 2]": {
      "level": 65,
      "ability": "Toxic Debris",
      "moves": [
        "Meteor Beam",
        "Sludge Bomb",
        "Earth Power",
        "Spiky Shield"
      ],
      "nature": "Modest",
      "item": "Power Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 243,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GLIMMORA:0",
      "originalSpeciesKey": "GLIMMORA:0",
      "trainerId": "RUINMANIAC:Braid:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Typhlosion [Hisuian]": {
    "Ruinmaniac Braid [Slot 3]": {
      "level": 66,
      "ability": "Flash Fire",
      "moves": [
        "Lava Plume",
        "Infernal Parade",
        "Shadow Claw",
        "Focus Blast"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 243,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TYPHLOSION:1",
      "originalSpeciesKey": "TYPHLOSION:1",
      "trainerId": "RUINMANIAC:Braid:0",
      "slot": 3,
      "doubles": false
    },
    "Burglar Gilligan [Slot 4]": {
      "level": 71,
      "ability": "Blaze",
      "moves": [
        "Flamethrower",
        "Shadow Ball",
        "Focus Blast",
        "Calm Mind"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 269,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TYPHLOSION:1",
      "originalSpeciesKey": "TYPHLOSION:1",
      "trainerId": "BURGLAR:Gilligan:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Rotom [Wash Rotom]": {
    "Ruinmaniac Braid [Slot 4]": {
      "level": 67,
      "ability": "Levitate",
      "moves": [
        "Volt Switch",
        "Thunderbolt",
        "Hydro Pump",
        "Will-O-Wisp"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 243,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROTOM:2",
      "originalSpeciesKey": "ROTOM:2",
      "trainerId": "RUINMANIAC:Braid:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Cyclizar": {
    "Ruinmaniac Roonie [Slot 2]": {
      "level": 65,
      "ability": "Regenerator",
      "moves": [
        "Quick Attack",
        "Double-Edge",
        "Knock Off",
        "Shed Tail"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 244,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CYCLIZAR:0",
      "originalSpeciesKey": "CYCLIZAR:0",
      "trainerId": "RUINMANIAC:Roonie:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Electivire": {
    "Toni Toni [Slot 3]": {
      "level": 68,
      "ability": "Vital Spirit",
      "moves": [
        "Volt Tackle",
        "Fire Punch",
        "Ice Punch",
        "Earthquake"
      ],
      "nature": "Adamant",
      "item": "Expert Belt",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 245,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ELECTIVIRE:0",
      "originalSpeciesKey": "ELECTIVIRE:0",
      "trainerId": "TONI:Toni:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Entei": {
    "Toni Toni [Slot 4]": {
      "level": 68,
      "ability": "Pressure",
      "moves": [
        "Sacred Fire",
        "Shadow Ball",
        "Scorching Sands"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 245,
      "gender": "",
      "shiny": false,
      "speciesKey": "ENTEI:0",
      "originalSpeciesKey": "ENTEI:0",
      "trainerId": "TONI:Toni:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Blastoise [Mega Blastoise]": {
    "Toni Toni [Slot 6]": {
      "level": 69,
      "ability": "Mega Launcher",
      "moves": [
        "Water Pulse",
        "Flash Cannon",
        "Aura Sphere",
        "Dark Pulse"
      ],
      "nature": "Timid",
      "item": "Blastoisinite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 245,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BLASTOISE:1",
      "originalSpeciesKey": "BLASTOISE:0",
      "trainerId": "TONI:Toni:0",
      "slot": 6,
      "doubles": false
    }
  },
  "Exploud": {
    "Hiker Justin [Slot 1]": {
      "level": 67,
      "ability": "Scrappy",
      "moves": [
        "Hyper Voice",
        "Flamethrower",
        "Focus Blast",
        "Ice Beam"
      ],
      "nature": "Timid",
      "item": "Silk Scarf",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 246,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EXPLOUD:0",
      "originalSpeciesKey": "EXPLOUD:0",
      "trainerId": "HIKER:Justin:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Flareon": {
    "Burglar Addison [Slot 3]": {
      "level": 68,
      "ability": "Guts",
      "moves": [
        "Flare Blitz",
        "Solar Beam",
        "Facade"
      ],
      "nature": "Hasty",
      "item": "Toxic Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 247,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FLAREON:0",
      "originalSpeciesKey": "FLAREON:0",
      "trainerId": "BURGLAR:Addison:0",
      "slot": 3,
      "doubles": false
    },
    "Ace Trainer Chalina (DOUBLES) [Slot 2]": {
      "level": 95,
      "ability": "Drought",
      "moves": [
        "Flare Blitz",
        "Solar Beam",
        "Stomping Tantrum",
        "Iron Tail"
      ],
      "nature": "Hasty",
      "item": "Heat Rock",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 307,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FLAREON:0",
      "originalSpeciesKey": "FLAREON:0",
      "trainerId": "COOLTRAINER_F:Chalina:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Cinderace": {
    "Lass Jeanne [Slot 1]": {
      "level": 66,
      "ability": "Libero",
      "moves": [
        "Pyro Ball",
        "High Jump Kick",
        "Zen Headbutt"
      ],
      "nature": "Jolly",
      "item": "Wide Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 250,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CINDERACE:0",
      "originalSpeciesKey": "CINDERACE:0",
      "trainerId": "LASS:Jeanne:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer M Jazz [Slot 4]": {
      "level": 96,
      "ability": "Libero",
      "moves": [
        "Sucker Punch",
        "Pyro Ball",
        "Gunk Shot",
        "Substitute"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 305,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CINDERACE:0",
      "originalSpeciesKey": "CINDERACE:0",
      "trainerId": "COOLTRAINER_M:Jazz:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Rotom [Heat Rotom]": {
    "Lass Jeanne [Slot 3]": {
      "level": 67,
      "ability": "Levitate",
      "moves": [
        "Overheat",
        "Thunderbolt",
        "Will-O-Wisp",
        "Protect"
      ],
      "nature": "Bold",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 250,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROTOM:1",
      "originalSpeciesKey": "ROTOM:1",
      "trainerId": "LASS:Jeanne:0",
      "slot": 3,
      "doubles": false
    },
    "Supernerd Friedrich [Slot 3]": {
      "level": 70,
      "ability": "Levitate",
      "moves": [
        "Thunderbolt",
        "Overheat",
        "Will-O-Wisp",
        "Thunder Wave"
      ],
      "nature": "Bold",
      "item": "White Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 267,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROTOM:1",
      "originalSpeciesKey": "ROTOM:1",
      "trainerId": "SUPERNERD:Friedrich:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer F Mag [Slot 1]": {
      "level": 95,
      "ability": "Levitate",
      "moves": [
        "Discharge",
        "Overheat",
        "Substitute",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 304,
      "gender": "",
      "shiny": false,
      "speciesKey": "ROTOM:1",
      "originalSpeciesKey": "ROTOM:1",
      "trainerId": "COOLTRAINER_F:Mag:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Blissey": {
    "Pokemonranger M Enzio [Slot 2]": {
      "level": 68,
      "ability": "Serene Grace",
      "moves": [
        "Hyper Voice",
        "Fire Blast",
        "Psychic",
        "Counter"
      ],
      "nature": "Modest",
      "item": "Chople Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 251,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BLISSEY:0",
      "originalSpeciesKey": "BLISSEY:0",
      "trainerId": "POKEMONRANGER_M:Enzio:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Turtonator": {
    "Pokemonranger M Enzio [Slot 5]": {
      "level": 69,
      "ability": "Shell Armor",
      "moves": [
        "Overheat",
        "Heat Crash",
        "Dragon Claw",
        "Shell Smash"
      ],
      "nature": "Hasty",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 251,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TURTONATOR:0",
      "originalSpeciesKey": "TURTONATOR:0",
      "trainerId": "POKEMONRANGER_M:Enzio:0",
      "slot": 5,
      "doubles": false
    },
    "Supernerd Nathan [Slot 4]": {
      "level": 71,
      "ability": "Shell Armor",
      "moves": [
        "Flamethrower",
        "Dragon Pulse",
        "Explosion"
      ],
      "nature": "Modest",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 266,
      "gender": "F",
      "shiny": false,
      "speciesKey": "TURTONATOR:0",
      "originalSpeciesKey": "TURTONATOR:0",
      "trainerId": "SUPERNERD:Nathan:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Armaldo": {
    "Lass Sable [Slot 1]": {
      "level": 67,
      "ability": "Battle Armor",
      "moves": [
        "Stealth Rock",
        "Stone Edge",
        "Leech Life",
        "Earthquake"
      ],
      "nature": "Careful",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 252,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARMALDO:0",
      "originalSpeciesKey": "ARMALDO:0",
      "trainerId": "LASS:Sable:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Victreebel": {
    "Lass Sable [Slot 3]": {
      "level": 68,
      "ability": "Chlorophyll",
      "moves": [
        "Solar Blade",
        "Gunk Shot",
        "Weather Ball"
      ],
      "nature": "Lonely",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 252,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VICTREEBEL:0",
      "originalSpeciesKey": "VICTREEBEL:0",
      "trainerId": "LASS:Sable:0",
      "slot": 3,
      "doubles": false
    },
    "Galactic M Grunt #18 [Slot 3]": {
      "level": 73,
      "ability": "Gluttony",
      "moves": [
        "Leaf Blade",
        "Belch",
        "Poison Jab"
      ],
      "nature": "Lonely",
      "item": "Salac Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 279,
      "gender": "F",
      "shiny": false,
      "speciesKey": "VICTREEBEL:0",
      "originalSpeciesKey": "VICTREEBEL:0",
      "trainerId": "GALACTIC_M:Grunt:18",
      "slot": 3,
      "doubles": false
    }
  },
  "Mr. Mime [Galarian]": {
    "Lady Anja [Slot 1]": {
      "level": 66,
      "ability": "Vital Spirit",
      "moves": [
        "Freeze-Dry",
        "Dazzling Gleam",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 255,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MRMIME:1",
      "originalSpeciesKey": "MRMIME:1",
      "trainerId": "LADY:Anja:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Magmortar": {
    "Lady Anja [Slot 3]": {
      "level": 68,
      "ability": "Flame Body",
      "moves": [
        "Fire Spin",
        "Flamethrower",
        "Scorching Sands",
        "Weather Ball"
      ],
      "nature": "Naive",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 255,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAGMORTAR:0",
      "originalSpeciesKey": "MAGMORTAR:0",
      "trainerId": "LADY:Anja:0",
      "slot": 3,
      "doubles": false
    },
    "Burglar Drago [Slot 4]": {
      "level": 71,
      "ability": "Flame Body",
      "moves": [
        "Flamethrower",
        "Thunderbolt",
        "Scorching Sands",
        "Psychic"
      ],
      "nature": "Timid",
      "item": "Wise Glasses",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 268,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAGMORTAR:0",
      "originalSpeciesKey": "MAGMORTAR:0",
      "trainerId": "BURGLAR:Drago:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Glaceon": {
    "Painter Clara [Slot 1]": {
      "level": 66,
      "ability": "Ice Body",
      "moves": [
        "Ice Beam",
        "Double-Edge",
        "Shadow Ball",
        "Blizzard"
      ],
      "nature": "Serious",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 256,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GLACEON:0",
      "originalSpeciesKey": "GLACEON:0",
      "trainerId": "PAINTER:Clara:0",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Lorelei #1 [Slot 3]": {
      "level": 99,
      "ability": "Ice Body",
      "moves": [
        "Blizzard",
        "Freeze-Dry",
        "Hidden Power"
      ],
      "nature": "Timid",
      "item": "Occa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 30,
        "sd": 31,
        "sp": 30
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 310,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GLACEON:0",
      "originalSpeciesKey": "GLACEON:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:0",
      "slot": 3,
      "doubles": false
    },
    "Elite Four Lorelei #2 (DOUBLES) [Slot 4]": {
      "level": 99,
      "ability": "Ice Body",
      "moves": [
        "Blizzard",
        "Freeze-Dry",
        "Hidden Power"
      ],
      "nature": "Timid",
      "item": "Occa Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 30,
        "sd": 31,
        "sp": 30
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 311,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GLACEON:0",
      "originalSpeciesKey": "GLACEON:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Avalugg": {
    "Painter Clara [Slot 2]": {
      "level": 67,
      "ability": "Ice Body",
      "moves": [
        "Avalanche",
        "Double-Edge",
        "Heavy Slam",
        "Icicle Crash"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 256,
      "gender": "F",
      "shiny": false,
      "speciesKey": "AVALUGG:0",
      "originalSpeciesKey": "AVALUGG:0",
      "trainerId": "PAINTER:Clara:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Eiscue": {
    "Painter Clara [Slot 3]": {
      "level": 67,
      "ability": "Ice Face",
      "moves": [
        "Ice Beam",
        "Icicle Crash",
        "Surf",
        "Blizzard"
      ],
      "nature": "Serious",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 256,
      "gender": "F",
      "shiny": false,
      "speciesKey": "EISCUE:0",
      "originalSpeciesKey": "EISCUE:0",
      "trainerId": "PAINTER:Clara:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Abomasnow": {
    "Gentleman Heath [Slot 1]": {
      "level": 66,
      "ability": "Soundproof",
      "moves": [
        "Blizzard",
        "Giga Drain",
        "Focus Blast",
        "Aurora Veil"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 257,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ABOMASNOW:0",
      "originalSpeciesKey": "ABOMASNOW:0",
      "trainerId": "GENTLEMAN:Heath:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Cetitan": {
    "Cooltrainer F Lumina [Slot 2]": {
      "level": 68,
      "ability": "Slush Rush",
      "moves": [
        "Icicle Crash",
        "Liquidation",
        "Stomping Tantrum",
        "Knock Off"
      ],
      "nature": "Adamant",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 259,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CETITAN:0",
      "originalSpeciesKey": "CETITAN:0",
      "trainerId": "COOLTRAINER_F:Lumina:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Indeedee": {
    "Lady Rosie [Slot 1]": {
      "level": 67,
      "ability": "Psychic Surge",
      "moves": [
        "Expanding Force",
        "Dazzling Gleam",
        "Mystical Fire",
        "Calm Mind"
      ],
      "nature": "Timid",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 260,
      "gender": "M",
      "shiny": false,
      "speciesKey": "INDEEDEE:0",
      "originalSpeciesKey": "INDEEDEE:0",
      "trainerId": "LADY:Rosie:0",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Lucian #1 [Slot 1]": {
      "level": 99,
      "ability": "Inner Focus",
      "moves": [
        "Expanding Force",
        "Dazzling Gleam",
        "Mystical Fire"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 316,
      "gender": "M",
      "shiny": false,
      "speciesKey": "INDEEDEE:0",
      "originalSpeciesKey": "INDEEDEE:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:0",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Lucian #2 (DOUBLES) [Slot 2]": {
      "level": 99,
      "ability": "Inner Focus",
      "moves": [
        "Expanding Force",
        "Dazzling Gleam",
        "Helping Hand"
      ],
      "nature": "Timid",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 317,
      "gender": "M",
      "shiny": false,
      "speciesKey": "INDEEDEE:0",
      "originalSpeciesKey": "INDEEDEE:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:1",
      "slot": 2,
      "doubles": true
    }
  },
  "Poliwrath": {
    "Lady Rosie [Slot 2]": {
      "level": 68,
      "ability": "Water Absorb",
      "moves": [
        "Liquidation",
        "Drain Punch",
        "Ice Punch",
        "Throat Chop"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 260,
      "gender": "F",
      "shiny": false,
      "speciesKey": "POLIWRATH:0",
      "originalSpeciesKey": "POLIWRATH:0",
      "trainerId": "LADY:Rosie:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Primarina": {
    "Gentleman Kendall [Slot 1]": {
      "level": 67,
      "ability": "Liquid Voice",
      "moves": [
        "Hyper Voice",
        "Draining Kiss",
        "Psychic"
      ],
      "nature": "Timid",
      "item": "Throat Spray",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 261,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PRIMARINA:0",
      "originalSpeciesKey": "PRIMARINA:0",
      "trainerId": "GENTLEMAN:Kendall:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Ninetales [Alolan]": {
    "Ace Trainer Stanley (DOUBLES) [Slot 1]": {
      "level": 68,
      "ability": "Snow Warning",
      "moves": [
        "Freeze-Dry",
        "Moonblast",
        "Aurora Veil",
        "Hypnosis"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 262,
      "gender": "M",
      "shiny": false,
      "speciesKey": "NINETALES:1",
      "originalSpeciesKey": "NINETALES:1",
      "trainerId": "COOLTRAINER_M:Stanley:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Arctozolt": {
    "Elite Four Lorelei #1 [Slot 4]": {
      "level": 99,
      "ability": "Slush Rush",
      "moves": [
        "Bolt Beak",
        "Blizzard",
        "Icicle Crash",
        "Stone Edge"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 310,
      "gender": "",
      "shiny": false,
      "speciesKey": "ARCTOZOLT:0",
      "originalSpeciesKey": "ARCTOZOLT:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:0",
      "slot": 4,
      "doubles": false
    },
    "Elite Four Lorelei #2 (DOUBLES) [Slot 1]": {
      "level": 99,
      "ability": "Slush Rush",
      "moves": [
        "Bolt Beak",
        "Blizzard",
        "Icicle Crash",
        "Rock Slide"
      ],
      "nature": "Lonely",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 311,
      "gender": "",
      "shiny": false,
      "speciesKey": "ARCTOZOLT:0",
      "originalSpeciesKey": "ARCTOZOLT:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:1",
      "slot": 1,
      "doubles": true
    },
    "Ace Trainer Stanley (DOUBLES) [Slot 2]": {
      "level": 67,
      "ability": "Slush Rush",
      "moves": [
        "Bolt Beak",
        "Blizzard",
        "Icicle Crash",
        "Low Kick"
      ],
      "nature": "Lonely",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 262,
      "gender": "",
      "shiny": false,
      "speciesKey": "ARCTOZOLT:0",
      "originalSpeciesKey": "ARCTOZOLT:0",
      "trainerId": "COOLTRAINER_M:Stanley:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Arctovish": {
    "Ace Trainer Stanley (DOUBLES) [Slot 4]": {
      "level": 67,
      "ability": "Slush Rush",
      "moves": [
        "Hydro Pump",
        "Blizzard",
        "Freeze-Dry",
        "Ancient Power"
      ],
      "nature": "Modest",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 262,
      "gender": "",
      "shiny": false,
      "speciesKey": "ARCTOVISH:0",
      "originalSpeciesKey": "ARCTOVISH:0",
      "trainerId": "COOLTRAINER_M:Stanley:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Porygon2": {
    "Galactic M Grunt #13 [Slot 1]": {
      "level": 71,
      "ability": "Download",
      "moves": [
        "Tri Attack",
        "Ice Beam",
        "Thunder Wave",
        "Recover"
      ],
      "nature": "Bold",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 273,
      "gender": "",
      "shiny": false,
      "speciesKey": "PORYGON2:0",
      "originalSpeciesKey": "PORYGON2:0",
      "trainerId": "GALACTIC_M:Grunt:12",
      "slot": 1,
      "doubles": false
    },
    "Psychic M Juan [Slot 1]": {
      "level": 95,
      "ability": "Analytic",
      "moves": [
        "Tri Attack",
        "Discharge",
        "Psychic",
        "Foul Play"
      ],
      "nature": "Quiet",
      "item": "Red Card",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 306,
      "gender": "",
      "shiny": false,
      "speciesKey": "PORYGON2:0",
      "originalSpeciesKey": "PORYGON2:0",
      "trainerId": "PSYCHIC_M:Juan:0",
      "slot": 1,
      "doubles": false
    },
    "Ace Trainer Forrest (DOUBLES) [Slot 2]": {
      "level": 67,
      "ability": "Download",
      "moves": [
        "Tri Attack",
        "Thunder",
        "Psychic",
        "Trick Room"
      ],
      "nature": "Quiet",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 263,
      "gender": "",
      "shiny": false,
      "speciesKey": "PORYGON2:0",
      "originalSpeciesKey": "PORYGON2:0",
      "trainerId": "COOLTRAINER_M:Forrest:0",
      "slot": 2,
      "doubles": true
    },
    "Ace Trainer Tibor (DOUBLES) [Slot 2]": {
      "level": 79,
      "ability": "Analytic",
      "moves": [
        "Tri Attack",
        "Blizzard",
        "Thunder",
        "Foul Play"
      ],
      "nature": "Quiet",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 290,
      "gender": "",
      "shiny": false,
      "speciesKey": "PORYGON2:0",
      "originalSpeciesKey": "PORYGON2:0",
      "trainerId": "COOLTRAINER_M:Tibor:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Hatterene": {
    "Ace Trainer Forrest (DOUBLES) [Slot 3]": {
      "level": 67,
      "ability": "Magic Bounce",
      "moves": [
        "Psychic",
        "Dazzling Gleam",
        "Trick Room",
        "Protect"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 263,
      "gender": "F",
      "shiny": false,
      "speciesKey": "HATTERENE:0",
      "originalSpeciesKey": "HATTERENE:0",
      "trainerId": "COOLTRAINER_M:Forrest:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Ninetales": {
    "Supernerd Gabriel [Slot 1]": {
      "level": 69,
      "ability": "Drought",
      "moves": [
        "Flamethrower",
        "Psyshock",
        "Scorching Sands",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "Heat Rock",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 264,
      "gender": "F",
      "shiny": false,
      "speciesKey": "NINETALES:0",
      "originalSpeciesKey": "NINETALES:0",
      "trainerId": "SUPERNERD:Gabriel:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Dragonite": {
    "Supernerd Gabriel [Slot 3]": {
      "level": 70,
      "ability": "Multiscale",
      "moves": [
        "Dragon Rush",
        "Dual Wingbeat",
        "Thunder Wave"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 264,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAGONITE:0",
      "originalSpeciesKey": "DRAGONITE:0",
      "trainerId": "SUPERNERD:Gabriel:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Blaziken": {
    "Supernerd Gabriel [Slot 4]": {
      "level": 71,
      "ability": "Speed Boost",
      "moves": [
        "Flare Blitz",
        "Close Combat",
        "Acrobatics",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Flying Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 264,
      "gender": "F",
      "shiny": false,
      "speciesKey": "BLAZIKEN:0",
      "originalSpeciesKey": "BLAZIKEN:0",
      "trainerId": "SUPERNERD:Gabriel:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Druddigon": {
    "Burglar Rocko [Slot 1]": {
      "level": 69,
      "ability": "Sheer Force",
      "moves": [
        "Dragon Claw",
        "Gunk Shot",
        "Fire Blast"
      ],
      "nature": "Brave",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 265,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DRUDDIGON:0",
      "originalSpeciesKey": "DRUDDIGON:0",
      "trainerId": "BURGLAR:Rocko:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Emboar": {
    "Burglar Rocko [Slot 4]": {
      "level": 71,
      "ability": "Reckless",
      "moves": [
        "Flare Blitz",
        "Head Smash",
        "Double-Edge"
      ],
      "nature": "Jolly",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 265,
      "gender": "M",
      "shiny": false,
      "speciesKey": "EMBOAR:0",
      "originalSpeciesKey": "EMBOAR:0",
      "trainerId": "BURGLAR:Rocko:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Kingdra": {
    "Supernerd Nathan [Slot 1]": {
      "level": 69,
      "ability": "Sniper",
      "moves": [
        "Dragon Pulse",
        "Liquidation",
        "Octazooka",
        "Focus Energy"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 266,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KINGDRA:0",
      "originalSpeciesKey": "KINGDRA:0",
      "trainerId": "SUPERNERD:Nathan:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Pyroar": {
    "Supernerd Nathan [Slot 3]": {
      "level": 70,
      "ability": "Unnerve",
      "moves": [
        "Fire Blast",
        "Hyper Voice",
        "Fire Spin",
        "Yawn"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 266,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PYROAR:0",
      "originalSpeciesKey": "PYROAR:0",
      "trainerId": "SUPERNERD:Nathan:0",
      "slot": 3,
      "doubles": false
    },
    "Cooltrainer M Jazz [Slot 1]": {
      "level": 95,
      "ability": "Unnerve",
      "moves": [
        "Fire Blast",
        "Hyper Voice",
        "Will-O-Wisp",
        "Endeavor"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 305,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PYROAR:0",
      "originalSpeciesKey": "PYROAR:0",
      "trainerId": "COOLTRAINER_M:Jazz:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Dragalge": {
    "Supernerd Friedrich [Slot 1]": {
      "level": 69,
      "ability": "Adaptability",
      "moves": [
        "Toxic Spikes",
        "Sludge Wave",
        "Dragon Pulse",
        "Scald"
      ],
      "nature": "Modest",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 267,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAGALGE:0",
      "originalSpeciesKey": "DRAGALGE:0",
      "trainerId": "SUPERNERD:Friedrich:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Coalossal": {
    "Supernerd Friedrich [Slot 4]": {
      "level": 71,
      "ability": "Steam Engine",
      "moves": [
        "Power Gem",
        "Burn Up",
        "Earth Power",
        "Will-O-Wisp"
      ],
      "nature": "Modest",
      "item": "Fire Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 267,
      "gender": "M",
      "shiny": false,
      "speciesKey": "COALOSSAL:0",
      "originalSpeciesKey": "COALOSSAL:0",
      "trainerId": "SUPERNERD:Friedrich:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Simisear": {
    "Burglar Drago [Slot 1]": {
      "level": 69,
      "ability": "Blaze",
      "moves": [
        "Fire Blast",
        "Focus Blast",
        "Acrobatics",
        "Substitute"
      ],
      "nature": "Hasty",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 268,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SIMISEAR:0",
      "originalSpeciesKey": "SIMISEAR:0",
      "trainerId": "BURGLAR:Drago:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Gouging Fire": {
    "Gym Leader Blaine #1 [Slot 2]": {
      "level": 72,
      "ability": "Protosynthesis",
      "moves": [
        "Flare Blitz",
        "Dragon Claw",
        "Stomping Tantrum"
      ],
      "nature": "Jolly",
      "item": "Covert Cloak",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 270,
      "gender": "",
      "shiny": false,
      "speciesKey": "GOUGINGFIRE:0",
      "originalSpeciesKey": "GOUGINGFIRE:0",
      "trainerId": "LEADER_Blaine:Blaine:0",
      "slot": 2,
      "doubles": false
    },
    "Gym Leader Blaine #2 (DOUBLES) [Slot 2]": {
      "level": 72,
      "ability": "Protosynthesis",
      "moves": [
        "Flare Blitz",
        "Dragon Claw",
        "Stomping Tantrum"
      ],
      "nature": "Jolly",
      "item": "Covert Cloak",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 271,
      "gender": "",
      "shiny": false,
      "speciesKey": "GOUGINGFIRE:0",
      "originalSpeciesKey": "GOUGINGFIRE:0",
      "trainerId": "LEADER_Blaine:Blaine:1",
      "slot": 2,
      "doubles": true
    }
  },
  "Volcarona": {
    "Gym Leader Blaine #1 [Slot 3]": {
      "level": 72,
      "ability": "Flame Body",
      "moves": [
        "Bug Buzz",
        "Fiery Dance",
        "Giga Drain",
        "Quiver Dance"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 270,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VOLCARONA:0",
      "originalSpeciesKey": "VOLCARONA:0",
      "trainerId": "LEADER_Blaine:Blaine:0",
      "slot": 3,
      "doubles": false
    },
    "Gym Leader Blaine #2 (DOUBLES) [Slot 3]": {
      "level": 72,
      "ability": "Flame Body",
      "moves": [
        "Bug Buzz",
        "Heat Wave",
        "Giga Drain",
        "Quiver Dance"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 271,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VOLCARONA:0",
      "originalSpeciesKey": "VOLCARONA:0",
      "trainerId": "LEADER_Blaine:Blaine:1",
      "slot": 3,
      "doubles": true
    },
    "Cooltrainer M Miguel [Slot 3]": {
      "level": 95,
      "ability": "Flame Body",
      "moves": [
        "Bug Buzz",
        "Fiery Dance",
        "Giga Drain",
        "Quiver Dance"
      ],
      "nature": "Timid",
      "item": "Grass Gem",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 300,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VOLCARONA:0",
      "originalSpeciesKey": "VOLCARONA:0",
      "trainerId": "COOLTRAINER_M:Miguel:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Camerupt [Mega Camerupt]": {
    "Gym Leader Blaine #1 [Slot 6]": {
      "level": 73,
      "ability": "Sheer Force",
      "moves": [
        "Flamethrower",
        "Earth Power",
        "Rock Slide",
        "Substitute"
      ],
      "nature": "Quiet",
      "item": "Cameruptite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 270,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CAMERUPT:1",
      "originalSpeciesKey": "CAMERUPT:0",
      "trainerId": "LEADER_Blaine:Blaine:0",
      "slot": 6,
      "doubles": false
    },
    "Gym Leader Blaine #2 (DOUBLES) [Slot 6]": {
      "level": 73,
      "ability": "Sheer Force",
      "moves": [
        "Flamethrower",
        "Earth Power",
        "Rock Slide",
        "Solar Beam"
      ],
      "nature": "Quiet",
      "item": "Cameruptite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 271,
      "gender": "M",
      "shiny": false,
      "speciesKey": "CAMERUPT:1",
      "originalSpeciesKey": "CAMERUPT:0",
      "trainerId": "LEADER_Blaine:Blaine:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Scolipede": {
    "Galactic M Grunt #12 [Slot 3]": {
      "level": 73,
      "ability": "Speed Boost",
      "moves": [
        "Pin Missile",
        "Rock Slide",
        "Smart Strike",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "King's Rock",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 272,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SCOLIPEDE:0",
      "originalSpeciesKey": "SCOLIPEDE:0",
      "trainerId": "GALACTIC_M:Grunt:11",
      "slot": 3,
      "doubles": false
    }
  },
  "Delibird": {
    "Galactic M Grunt #13 [Slot 4]": {
      "level": 73,
      "ability": "Hustle",
      "moves": [
        "Triple Axel",
        "Dual Wingbeat"
      ],
      "nature": "Jolly",
      "item": "Choice Band",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 273,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DELIBIRD:0",
      "originalSpeciesKey": "DELIBIRD:0",
      "trainerId": "GALACTIC_M:Grunt:12",
      "slot": 4,
      "doubles": false
    }
  },
  "Lickilicky": {
    "Galactic M Grunt #15 [Slot 2]": {
      "level": 72,
      "ability": "Own Tempo",
      "moves": [
        "Double-Edge",
        "Power Whip",
        "Brick Break",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 275,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LICKILICKY:0",
      "originalSpeciesKey": "LICKILICKY:0",
      "trainerId": "GALACTIC_M:Grunt:14",
      "slot": 2,
      "doubles": false
    }
  },
  "Alcremie": {
    "Galactic M Grunt #15 [Slot 4]": {
      "level": 73,
      "ability": "Sweet Veil",
      "moves": [
        "Draining Kiss",
        "Mystical Fire",
        "Acid Armor",
        "Calm Mind"
      ],
      "nature": "Bold",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 275,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ALCREMIE:0",
      "originalSpeciesKey": "ALCREMIE:1",
      "trainerId": "GALACTIC_M:Grunt:14",
      "slot": 4,
      "doubles": false
    }
  },
  "Simisage": {
    "Galactic F Grunt #4 [Slot 3]": {
      "level": 73,
      "ability": "Gluttony",
      "moves": [
        "Leaf Storm",
        "Superpower",
        "Rock Slide",
        "Acrobatics"
      ],
      "nature": "Naive",
      "item": "White Herb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 276,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SIMISAGE:0",
      "originalSpeciesKey": "SIMISAGE:0",
      "trainerId": "GALACTIC_F:Grunt:15",
      "slot": 3,
      "doubles": false
    }
  },
  "Absol": {
    "Galactic M Grunt #17 [Slot 1]": {
      "level": 72,
      "ability": "Super Luck",
      "moves": [
        "Knock Off",
        "Close Combat",
        "Play Rough",
        "Counter"
      ],
      "nature": "Jolly",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 278,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ABSOL:0",
      "originalSpeciesKey": "ABSOL:0",
      "trainerId": "GALACTIC_M:Grunt:17",
      "slot": 1,
      "doubles": false
    },
    "Pokemonranger M Sid [Slot 3]": {
      "level": 95,
      "ability": "Super Luck",
      "moves": [
        "Quick Attack",
        "Night Slash",
        "Play Rough",
        "Stone Edge"
      ],
      "nature": "Jolly",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 297,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ABSOL:0",
      "originalSpeciesKey": "ABSOL:0",
      "trainerId": "POKEMONRANGER_M:Sid:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Raticate": {
    "Galactic M Grunt #17 [Slot 2]": {
      "level": 72,
      "ability": "Guts",
      "moves": [
        "Quick Attack",
        "Facade",
        "Stomping Tantrum",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Flame Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 278,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RATICATE:0",
      "originalSpeciesKey": "RATICATE:0",
      "trainerId": "GALACTIC_M:Grunt:17",
      "slot": 2,
      "doubles": false
    }
  },
  "Kangaskhan": {
    "Galactic M Grunt #18 [Slot 1]": {
      "level": 72,
      "ability": "Inner Focus",
      "moves": [
        "Fake Out",
        "Sucker Punch",
        "Strength",
        "Hammer Arm"
      ],
      "nature": "Hasty",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 279,
      "gender": "F",
      "shiny": false,
      "speciesKey": "KANGASKHAN:0",
      "originalSpeciesKey": "KANGASKHAN:0",
      "trainerId": "GALACTIC_M:Grunt:18",
      "slot": 1,
      "doubles": false
    }
  },
  "Volbeat": {
    "Galactic F Grunt #5 [Slot 1]": {
      "level": 71,
      "ability": "Prankster",
      "moves": [
        "Bug Buzz",
        "Discharge",
        "Baton Pass",
        "Tail Glow"
      ],
      "nature": "Timid",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 281,
      "gender": "M",
      "shiny": false,
      "speciesKey": "VOLBEAT:0",
      "originalSpeciesKey": "VOLBEAT:0",
      "trainerId": "GALACTIC_F:Grunt:20",
      "slot": 1,
      "doubles": false
    }
  },
  "Gallade": {
    "Galactic F Grunt #5 [Slot 3]": {
      "level": 73,
      "ability": "Sharpness",
      "moves": [
        "Shadow Sneak",
        "Psycho Cut",
        "Sacred Sword",
        "Bulk Up"
      ],
      "nature": "Careful",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 281,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GALLADE:0",
      "originalSpeciesKey": "GALLADE:0",
      "trainerId": "GALACTIC_F:Grunt:20",
      "slot": 3,
      "doubles": false
    }
  },
  "Arboliva": {
    "Galactic F Grunt #7 [Slot 1]": {
      "level": 74,
      "ability": "Seed Sower",
      "moves": [
        "Giga Drain",
        "Dazzling Gleam",
        "Light Screen",
        "Reflect"
      ],
      "nature": "Modest",
      "item": "Light Clay",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 283,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ARBOLIVA:0",
      "originalSpeciesKey": "ARBOLIVA:0",
      "trainerId": "GALACTIC_F:Grunt:22",
      "slot": 1,
      "doubles": false
    }
  },
  "Rillaboom": {
    "Galactic F Grunt #7 [Slot 2]": {
      "level": 75,
      "ability": "Overgrow",
      "moves": [
        "Grassy Glide",
        "Drain Punch",
        "High Horsepower",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 283,
      "gender": "M",
      "shiny": false,
      "speciesKey": "RILLABOOM:0",
      "originalSpeciesKey": "RILLABOOM:0",
      "trainerId": "GALACTIC_F:Grunt:22",
      "slot": 2,
      "doubles": false
    },
    "Cooltrainer M Lewis [Slot 1]": {
      "level": 93,
      "ability": "Grassy Surge",
      "moves": [
        "Grassy Glide",
        "Wood Hammer",
        "Drain Punch",
        "Low Sweep"
      ],
      "nature": "Adamant",
      "item": "Assault Vest",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 295,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RILLABOOM:0",
      "originalSpeciesKey": "RILLABOOM:0",
      "trainerId": "COOLTRAINER_M:Lewis:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Tatsugiri [Droopy Form]": {
    "Galactic M Grunt #20 [Slot 3]": {
      "level": 74,
      "ability": "Torrent",
      "moves": [
        "Dragon Pulse",
        "Muddy Water",
        "Whirlpool",
        "Substitute"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 284,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TATSUGIRI:1",
      "originalSpeciesKey": "TATSUGIRI:1",
      "trainerId": "GALACTIC_M:Grunt:23",
      "slot": 3,
      "doubles": false
    }
  },
  "Weezing [Galarian]": {
    "Ace Trainer Rolan (DOUBLES) [Slot 1]": {
      "level": 79,
      "ability": "Neutralizing Gas",
      "moves": [
        "Gunk Shot",
        "Strange Steam",
        "Assurance",
        "Protect"
      ],
      "nature": "Sassy",
      "item": "Air Balloon",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 285,
      "gender": "F",
      "shiny": false,
      "speciesKey": "WEEZING:1",
      "originalSpeciesKey": "WEEZING:1",
      "trainerId": "COOLTRAINER_M:Rolan:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Slaking": {
    "Ace Trainer Rolan (DOUBLES) [Slot 2]": {
      "level": 79,
      "ability": "Truant",
      "moves": [
        "Return",
        "Earthquake",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 285,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SLAKING:0",
      "originalSpeciesKey": "SLAKING:0",
      "trainerId": "COOLTRAINER_M:Rolan:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Staraptor": {
    "Ace Trainer Tavarius (DOUBLES) [Slot 2]": {
      "level": 79,
      "ability": "Intimidate",
      "moves": [
        "Return",
        "Dual Wingbeat",
        "Roost"
      ],
      "nature": "Jolly",
      "item": "Focus Sash",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 286,
      "gender": "M",
      "shiny": false,
      "speciesKey": "STARAPTOR:0",
      "originalSpeciesKey": "STARAPTOR:0",
      "trainerId": "COOLTRAINER_M:Tavarius:0",
      "slot": 2,
      "doubles": true
    }
  },
  "Whimsicott": {
    "Ace Trainer Tavarius (DOUBLES) [Slot 4]": {
      "level": 79,
      "ability": "Prankster",
      "moves": [
        "Dazzling Gleam",
        "Grass Whistle",
        "Encore",
        "Tailwind"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 286,
      "gender": "M",
      "shiny": false,
      "speciesKey": "WHIMSICOTT:0",
      "originalSpeciesKey": "WHIMSICOTT:0",
      "trainerId": "COOLTRAINER_M:Tavarius:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Greedent": {
    "Ace Trainer Tavarius (DOUBLES) [Slot 5]": {
      "level": 80,
      "ability": "Cheek Pouch",
      "moves": [
        "Return",
        "Body Press",
        "Psychic Fangs",
        "Stuff Cheeks"
      ],
      "nature": "Impish",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 286,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GREEDENT:0",
      "originalSpeciesKey": "GREEDENT:0",
      "trainerId": "COOLTRAINER_M:Tavarius:0",
      "slot": 5,
      "doubles": true
    }
  },
  "Gardevoir": {
    "Ace Trainer Colette (DOUBLES) [Slot 1]": {
      "level": 79,
      "ability": "Telepathy",
      "moves": [
        "Psychic",
        "Dazzling Gleam",
        "Mystical Fire",
        "Trick Room"
      ],
      "nature": "Quiet",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 0
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 287,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GARDEVOIR:0",
      "originalSpeciesKey": "GARDEVOIR:0",
      "trainerId": "COOLTRAINER_F:Colette:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Oranguru": {
    "Ace Trainer Colette (DOUBLES) [Slot 3]": {
      "level": 79,
      "ability": "Telepathy",
      "moves": [
        "Psychic",
        "Focus Blast",
        "Shadow Ball",
        "Trick Room"
      ],
      "nature": "Quiet",
      "item": "Colbur Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 287,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ORANGURU:0",
      "originalSpeciesKey": "ORANGURU:0",
      "trainerId": "COOLTRAINER_F:Colette:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Silvally": {
    "Ace Trainer Colette (DOUBLES) [Slot 4]": {
      "level": 80,
      "ability": "RKS System",
      "moves": [
        "Explosion"
      ],
      "nature": "Brave",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 0
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 287,
      "gender": "",
      "shiny": false,
      "speciesKey": "SILVALLY:0",
      "originalSpeciesKey": "SILVALLY:0",
      "trainerId": "COOLTRAINER_F:Colette:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Bouffalant": {
    "Ace Trainer Nikola (DOUBLES) [Slot 1]": {
      "level": 79,
      "ability": "Reckless",
      "moves": [
        "Head Charge",
        "Head Smash",
        "Lash Out"
      ],
      "nature": "Adamant",
      "item": "Custap Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 288,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BOUFFALANT:0",
      "originalSpeciesKey": "BOUFFALANT:0",
      "trainerId": "COOLTRAINER_F:Nikola:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Miltank": {
    "Ace Trainer Niel (DOUBLES) [Slot 3]": {
      "level": 79,
      "ability": "Thick Fat",
      "moves": [
        "Strength",
        "Body Press",
        "Milk Drink",
        "Curse"
      ],
      "nature": "Careful",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 289,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MILTANK:0",
      "originalSpeciesKey": "MILTANK:0",
      "trainerId": "COOLTRAINER_M:Niel:0",
      "slot": 3,
      "doubles": true
    }
  },
  "Delcatty": {
    "Ace Trainer Niel (DOUBLES) [Slot 5]": {
      "level": 80,
      "ability": "Wonder Skin",
      "moves": [
        "Fake Out",
        "Last Resort"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 289,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DELCATTY:0",
      "originalSpeciesKey": "DELCATTY:0",
      "trainerId": "COOLTRAINER_M:Niel:0",
      "slot": 5,
      "doubles": true
    }
  },
  "Zangoose": {
    "Ace Trainer Tibor (DOUBLES) [Slot 4]": {
      "level": 79,
      "ability": "Toxic Boost",
      "moves": [
        "Quick Attack",
        "Body Slam",
        "Close Combat"
      ],
      "nature": "Jolly",
      "item": "Toxic Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 290,
      "gender": "F",
      "shiny": false,
      "speciesKey": "ZANGOOSE:0",
      "originalSpeciesKey": "ZANGOOSE:0",
      "trainerId": "COOLTRAINER_M:Tibor:0",
      "slot": 4,
      "doubles": true
    }
  },
  "Rapidash [Galarian]": {
    "Ace Trainer Tibor (DOUBLES) [Slot 5]": {
      "level": 80,
      "ability": "Pastel Veil",
      "moves": [
        "Zen Headbutt",
        "Play Rough",
        "High Horsepower",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 290,
      "gender": "F",
      "shiny": false,
      "speciesKey": "RAPIDASH:1",
      "originalSpeciesKey": "RAPIDASH:1",
      "trainerId": "COOLTRAINER_M:Tibor:0",
      "slot": 5,
      "doubles": true
    }
  },
  "Tapu Fini": {
    "Gym Leader Giovanni #1 [Slot 1]": {
      "level": 81,
      "ability": "Telepathy",
      "moves": [
        "Surf",
        "Moonblast",
        "Nature's Madness",
        "Calm Mind"
      ],
      "nature": "Timid",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 291,
      "gender": "",
      "shiny": false,
      "speciesKey": "TAPUFINI:0",
      "originalSpeciesKey": "TAPUFINI:0",
      "trainerId": "LEADER_Giovanni:Giovanni:0",
      "slot": 1,
      "doubles": false
    },
    "Gym Leader Giovanni #2 (DOUBLES) [Slot 2]": {
      "level": 81,
      "ability": "Telepathy",
      "moves": [
        "Waterfall",
        "Play Rough",
        "Smart Strike",
        "Ice Punch"
      ],
      "nature": "Jolly",
      "item": "Misty Seed",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 292,
      "gender": "",
      "shiny": false,
      "speciesKey": "TAPUFINI:0",
      "originalSpeciesKey": "TAPUFINI:0",
      "trainerId": "LEADER_Giovanni:Giovanni:1",
      "slot": 2,
      "doubles": true
    }
  },
  "Porygon-Z": {
    "Gym Leader Giovanni #1 [Slot 2]": {
      "level": 81,
      "ability": "Adaptability",
      "moves": [
        "Tri Attack",
        "Thunderbolt",
        "Substitute",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 291,
      "gender": "",
      "shiny": false,
      "speciesKey": "PORYGONZ:0",
      "originalSpeciesKey": "PORYGONZ:0",
      "trainerId": "LEADER_Giovanni:Giovanni:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Maushold": {
    "Gym Leader Giovanni #1 [Slot 3]": {
      "level": 81,
      "ability": "Cheek Pouch",
      "moves": [
        "Population Bomb",
        "Play Rough",
        "Tidy Up"
      ],
      "nature": "Jolly",
      "item": "Ganlon Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 291,
      "gender": "",
      "shiny": false,
      "speciesKey": "MAUSHOLD:0",
      "originalSpeciesKey": "MAUSHOLD:0",
      "trainerId": "LEADER_Giovanni:Giovanni:0",
      "slot": 3,
      "doubles": false
    },
    "Gym Leader Giovanni #2 (DOUBLES) [Slot 3]": {
      "level": 81,
      "ability": "Friend Guard",
      "moves": [
        "Population Bomb",
        "Play Rough",
        "Follow Me"
      ],
      "nature": "Jolly",
      "item": "Ganlon Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 292,
      "gender": "",
      "shiny": false,
      "speciesKey": "MAUSHOLD:0",
      "originalSpeciesKey": "MAUSHOLD:0",
      "trainerId": "LEADER_Giovanni:Giovanni:1",
      "slot": 3,
      "doubles": true
    }
  },
  "Iron Valiant": {
    "Gym Leader Giovanni #1 [Slot 5]": {
      "level": 81,
      "ability": "Quark Drive",
      "moves": [
        "Shadow Sneak",
        "Spirit Break",
        "Close Combat",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 291,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONVALIANT:0",
      "originalSpeciesKey": "IRONVALIANT:0",
      "trainerId": "LEADER_Giovanni:Giovanni:0",
      "slot": 5,
      "doubles": false
    },
    "Gym Leader Giovanni #2 (DOUBLES) [Slot 5]": {
      "level": 81,
      "ability": "Quark Drive",
      "moves": [
        "Shadow Sneak",
        "Spirit Break",
        "Close Combat",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Booster Energy",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 292,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONVALIANT:0",
      "originalSpeciesKey": "IRONVALIANT:0",
      "trainerId": "LEADER_Giovanni:Giovanni:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Pidgeot [Mega Pidgeot]": {
    "Gym Leader Giovanni #1 [Slot 6]": {
      "level": 82,
      "ability": "No Guard",
      "moves": [
        "Hyper Voice",
        "Hurricane",
        "Heat Wave",
        "Hidden Power"
      ],
      "nature": "Timid",
      "item": "Pidgeotite",
      "ivs": {
        "hp": 30,
        "at": 30,
        "df": 30,
        "sa": 30,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 291,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PIDGEOT:1",
      "originalSpeciesKey": "PIDGEOT:0",
      "trainerId": "LEADER_Giovanni:Giovanni:0",
      "slot": 6,
      "doubles": false
    },
    "Gym Leader Giovanni #2 (DOUBLES) [Slot 6]": {
      "level": 82,
      "ability": "No Guard",
      "moves": [
        "Hyper Voice",
        "Hurricane",
        "Heat Wave",
        "Hidden Power"
      ],
      "nature": "Timid",
      "item": "Pidgeotite",
      "ivs": {
        "hp": 30,
        "at": 30,
        "df": 30,
        "sa": 30,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 292,
      "gender": "M",
      "shiny": false,
      "speciesKey": "PIDGEOT:1",
      "originalSpeciesKey": "PIDGEOT:0",
      "trainerId": "LEADER_Giovanni:Giovanni:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Yanmega": {
    "Cooltrainer F Lynette [Slot 1]": {
      "level": 93,
      "ability": "Speed Boost",
      "moves": [
        "Bug Buzz",
        "Air Slash",
        "Hypnosis",
        "Substitute"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 293,
      "gender": "F",
      "shiny": false,
      "speciesKey": "YANMEGA:0",
      "originalSpeciesKey": "YANMEGA:0",
      "trainerId": "COOLTRAINER_F:Lynette:0",
      "slot": 1,
      "doubles": false
    },
    "Cooltrainer M Jazz [Slot 2]": {
      "level": 95,
      "ability": "Compound Eyes",
      "moves": [
        "Bug Buzz",
        "Hurricane",
        "U-turn"
      ],
      "nature": "Timid",
      "item": "Choice Specs",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 305,
      "gender": "M",
      "shiny": false,
      "speciesKey": "YANMEGA:0",
      "originalSpeciesKey": "YANMEGA:0",
      "trainerId": "COOLTRAINER_M:Jazz:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Pinsir [Mega Pinsir]": {
    "Cooltrainer F Lynette [Slot 4]": {
      "level": 95,
      "ability": "Aerilate",
      "moves": [
        "Quick Attack",
        "X-Scissor",
        "Body Slam",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Pinsirite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 293,
      "gender": "F",
      "shiny": false,
      "speciesKey": "PINSIR:1",
      "originalSpeciesKey": "PINSIR:0",
      "trainerId": "COOLTRAINER_F:Lynette:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Golem": {
    "Cooltrainer F Kumiko [Slot 1]": {
      "level": 93,
      "ability": "Sturdy",
      "moves": [
        "Stealth Rock",
        "Stone Edge",
        "Earthquake",
        "Explosion"
      ],
      "nature": "Adamant",
      "item": "Custap Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 294,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GOLEM:0",
      "originalSpeciesKey": "GOLEM:0",
      "trainerId": "COOLTRAINER_F:Kumiko:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Garganacl": {
    "Cooltrainer F Kumiko [Slot 4]": {
      "level": 94,
      "ability": "Purifying Salt",
      "moves": [
        "Salt Cure",
        "Stone Edge",
        "Body Press",
        "Iron Defense"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 294,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GARGANACL:0",
      "originalSpeciesKey": "GARGANACL:0",
      "trainerId": "COOLTRAINER_F:Kumiko:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Ampharos [Mega Ampharos]": {
    "Cooltrainer F Kumiko [Slot 5]": {
      "level": 95,
      "ability": "Mold Breaker",
      "moves": [
        "Thunderbolt",
        "Dragon Pulse",
        "Focus Blast",
        "Agility"
      ],
      "nature": "Timid",
      "item": "Ampharosite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 294,
      "gender": "F",
      "shiny": false,
      "speciesKey": "AMPHAROS:1",
      "originalSpeciesKey": "AMPHAROS:0",
      "trainerId": "COOLTRAINER_F:Kumiko:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Dragonite [Mega Dragonite]": {
    "Cooltrainer M Lewis [Slot 4]": {
      "level": 95,
      "ability": "Multiscale",
      "moves": [
        "Extreme Speed",
        "Dragon Pulse",
        "Hurricane",
        "Earthquake"
      ],
      "nature": "Naive",
      "item": "Dragoninite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 295,
      "gender": "F",
      "shiny": false,
      "speciesKey": "DRAGONITE:1",
      "originalSpeciesKey": "DRAGONITE:0",
      "trainerId": "COOLTRAINER_M:Lewis:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Murkrow": {
    "Cooltrainer M Matt [Slot 1]": {
      "level": 94,
      "ability": "Prankster",
      "moves": [
        "Foul Play",
        "Dual Wingbeat",
        "Tailwind"
      ],
      "nature": "Bold",
      "item": "Eviolite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 296,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MURKROW:0",
      "originalSpeciesKey": "MURKROW:0",
      "trainerId": "COOLTRAINER_M:Matt:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Drapion": {
    "Cooltrainer M Matt [Slot 3]": {
      "level": 95,
      "ability": "Sniper",
      "moves": [
        "Cross Poison",
        "Night Slash",
        "Aqua Tail",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 296,
      "gender": "M",
      "shiny": false,
      "speciesKey": "DRAPION:0",
      "originalSpeciesKey": "DRAPION:0",
      "trainerId": "COOLTRAINER_M:Matt:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Feraligatr [Mega Feraligatr]": {
    "Cooltrainer M Matt [Slot 5]": {
      "level": 96,
      "ability": "Dragonize",
      "moves": [
        "Aqua Jet",
        "Waterfall",
        "Double-Edge",
        "Ice Fang"
      ],
      "nature": "Jolly",
      "item": "Feraligite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 296,
      "gender": "M",
      "shiny": false,
      "speciesKey": "FERALIGATR:1",
      "originalSpeciesKey": "FERALIGATR:0",
      "trainerId": "COOLTRAINER_M:Matt:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Honchkrow": {
    "Pokemonranger M Sid [Slot 2]": {
      "level": 95,
      "ability": "Super Luck",
      "moves": [
        "Sucker Punch",
        "Night Slash",
        "Drill Peck",
        "Endeavor"
      ],
      "nature": "Jolly",
      "item": "Scope Lens",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 297,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HONCHKROW:0",
      "originalSpeciesKey": "HONCHKROW:0",
      "trainerId": "POKEMONRANGER_M:Sid:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Slowbro [Mega Slowbro]": {
    "Pokemonranger M Sid [Slot 4]": {
      "level": 96,
      "ability": "Shell Armor",
      "moves": [
        "Surf",
        "Psychic",
        "Calm Mind",
        "Slack Off"
      ],
      "nature": "Calm",
      "item": "Slowbronite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 297,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SLOWBRO:2",
      "originalSpeciesKey": "SLOWBRO:0",
      "trainerId": "POKEMONRANGER_M:Sid:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Zoroark [Hisuian]": {
    "Cooltrainer M Wes [Slot 4]": {
      "level": 95,
      "ability": "Illusion",
      "moves": [
        "Hyper Voice",
        "Shadow Ball",
        "Grass Knot",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 298,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ZOROARK:1",
      "originalSpeciesKey": "ZOROARK:1",
      "trainerId": "COOLTRAINER_M:Wes:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Heracross [Mega Heracross]": {
    "Cooltrainer M Wes [Slot 5]": {
      "level": 96,
      "ability": "Skill Link",
      "moves": [
        "Pin Missile",
        "Arm Thrust",
        "Bullet Seed",
        "Substitute"
      ],
      "nature": "Jolly",
      "item": "Heracronite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 298,
      "gender": "M",
      "shiny": false,
      "speciesKey": "HERACROSS:1",
      "originalSpeciesKey": "HERACROSS:0",
      "trainerId": "COOLTRAINER_M:Wes:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Shuckle": {
    "Pokemonranger F Mell [Slot 1]": {
      "level": 94,
      "ability": "Contrary",
      "moves": [
        "Infestation",
        "Knock Off",
        "Shell Smash",
        "Rest"
      ],
      "nature": "Relaxed",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 299,
      "gender": "F",
      "shiny": false,
      "speciesKey": "SHUCKLE:0",
      "originalSpeciesKey": "SHUCKLE:0",
      "trainerId": "POKEMONRANGER_F:Mell:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Metagross": {
    "Pokemonranger F Mell [Slot 2]": {
      "level": 95,
      "ability": "Clear Body",
      "moves": [
        "Meteor Mash",
        "Psychic Fangs",
        "Earthquake",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 299,
      "gender": "",
      "shiny": false,
      "speciesKey": "METAGROSS:0",
      "originalSpeciesKey": "METAGROSS:0",
      "trainerId": "POKEMONRANGER_F:Mell:0",
      "slot": 2,
      "doubles": false
    }
  },
  "Blaziken [Mega Blaziken]": {
    "Pokemonranger F Mell [Slot 5]": {
      "level": 96,
      "ability": "Inner Focus",
      "moves": [
        "Flare Blitz",
        "Close Combat",
        "Stone Edge",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Blazikenite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 299,
      "gender": "M",
      "shiny": false,
      "speciesKey": "BLAZIKEN:1",
      "originalSpeciesKey": "BLAZIKEN:0",
      "trainerId": "POKEMONRANGER_F:Mell:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Gallade [Mega Gallade]": {
    "Cooltrainer M Miguel [Slot 4]": {
      "level": 96,
      "ability": "Inner Focus",
      "moves": [
        "Psycho Cut",
        "Close Combat",
        "Spirit Break",
        "Knock Off"
      ],
      "nature": "Jolly",
      "item": "Galladite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 300,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GALLADE:1",
      "originalSpeciesKey": "GALLADE:0",
      "trainerId": "COOLTRAINER_M:Miguel:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Politoed": {
    "Cooltrainer F Alize [Slot 1]": {
      "level": 94,
      "ability": "Drizzle",
      "moves": [
        "Hydro Pump",
        "Ice Beam",
        "Focus Blast",
        "Hypnosis"
      ],
      "nature": "Timid",
      "item": "Damp Rock",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 301,
      "gender": "F",
      "shiny": false,
      "speciesKey": "POLITOED:0",
      "originalSpeciesKey": "POLITOED:0",
      "trainerId": "COOLTRAINER_F:Alize:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Swampert [Mega Swampert]": {
    "Cooltrainer F Alize [Slot 5]": {
      "level": 96,
      "ability": "Swift Swim",
      "moves": [
        "Liquidation",
        "Earthquake",
        "Ice Punch",
        "Power-Up Punch"
      ],
      "nature": "Jolly",
      "item": "Swampertite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 301,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SWAMPERT:1",
      "originalSpeciesKey": "SWAMPERT:0",
      "trainerId": "COOLTRAINER_F:Alize:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Annihilape": {
    "Blackbelt Damon [Slot 1]": {
      "level": 94,
      "ability": "Inner Focus",
      "moves": [
        "Drain Punch",
        "Rage Fist",
        "Thunder Punch",
        "Focus Energy"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 302,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ANNIHILAPE:0",
      "originalSpeciesKey": "ANNIHILAPE:0",
      "trainerId": "BLACKBELT:Damon:0",
      "slot": 1,
      "doubles": false
    }
  },
  "Greninja [Mega Greninja]": {
    "Blackbelt Damon [Slot 4]": {
      "level": 96,
      "ability": "Protean",
      "moves": [
        "Surf",
        "Dark Pulse",
        "Extrasensory",
        "Gunk Shot"
      ],
      "nature": "Hasty",
      "item": "Greninjite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 302,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GRENINJA:3",
      "originalSpeciesKey": "GRENINJA:0",
      "trainerId": "BLACKBELT:Damon:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Obstagoon": {
    "Cooltrainer M Hawk [Slot 4]": {
      "level": 96,
      "ability": "Guts",
      "moves": [
        "Knock Off",
        "Close Combat",
        "Facade",
        "Bulk Up"
      ],
      "nature": "Jolly",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 303,
      "gender": "M",
      "shiny": false,
      "speciesKey": "OBSTAGOON:0",
      "originalSpeciesKey": "OBSTAGOON:1",
      "trainerId": "COOLTRAINER_M:Hawk:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Meganium [Mega Meganium]": {
    "Cooltrainer M Hawk [Slot 5]": {
      "level": 97,
      "ability": "Mega Sol",
      "moves": [
        "Solar Beam",
        "Moonblast",
        "Earth Power",
        "Growth"
      ],
      "nature": "Timid",
      "item": "Meganiumite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 303,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MEGANIUM:1",
      "originalSpeciesKey": "MEGANIUM:0",
      "trainerId": "COOLTRAINER_M:Hawk:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Mawile [Mega Mawile]": {
    "Cooltrainer F Mag [Slot 4]": {
      "level": 97,
      "ability": "Huge Power",
      "moves": [
        "Sucker Punch",
        "Iron Head",
        "Play Rough",
        "Swords Dance"
      ],
      "nature": "Adamant",
      "item": "Mawilite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 304,
      "gender": "M",
      "shiny": false,
      "speciesKey": "MAWILE:1",
      "originalSpeciesKey": "MAWILE:0",
      "trainerId": "COOLTRAINER_F:Mag:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Garchomp [Mega Garchomp]": {
    "Cooltrainer M Jazz [Slot 5]": {
      "level": 97,
      "ability": "Sand Force",
      "moves": [
        "Dual Chop",
        "Earthquake",
        "Iron Tail",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Garchompite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 305,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GARCHOMP:1",
      "originalSpeciesKey": "GARCHOMP:0",
      "trainerId": "COOLTRAINER_M:Jazz:0",
      "slot": 5,
      "doubles": false
    },
    "Cynthia Cynthia #1 [Slot 6]": {
      "level": 100,
      "ability": "Sand Force",
      "moves": [
        "Extreme Speed",
        "Dual Chop",
        "Earth Power",
        "Rock Slide"
      ],
      "nature": "Hasty",
      "item": "Garchompite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 318,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GARCHOMP:1",
      "originalSpeciesKey": "GARCHOMP:0",
      "trainerId": "CYNTHIA:Cynthia:0",
      "slot": 6,
      "doubles": false
    },
    "Cynthia Cynthia #2 (DOUBLES) [Slot 6]": {
      "level": 100,
      "ability": "Sand Force",
      "moves": [
        "Extreme Speed",
        "Dual Chop",
        "Earth Power",
        "Rock Slide"
      ],
      "nature": "Hasty",
      "item": "Garchompite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 319,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GARCHOMP:1",
      "originalSpeciesKey": "GARCHOMP:0",
      "trainerId": "CYNTHIA:Cynthia:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Gardevoir [Mega Gardevoir]": {
    "Psychic M Juan [Slot 4]": {
      "level": 97,
      "ability": "Pixilate",
      "moves": [
        "Hyper Voice",
        "Aura Sphere",
        "Mystical Fire",
        "Destiny Bond"
      ],
      "nature": "Timid",
      "item": "Gardevoirite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 306,
      "gender": "M",
      "shiny": false,
      "speciesKey": "GARDEVOIR:1",
      "originalSpeciesKey": "GARDEVOIR:0",
      "trainerId": "PSYCHIC_M:Juan:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Lilligant": {
    "Ace Trainer Chalina (DOUBLES) [Slot 1]": {
      "level": 95,
      "ability": "Chlorophyll",
      "moves": [
        "Giga Drain",
        "Fiery Dance",
        "Sleep Powder",
        "Growth"
      ],
      "nature": "Timid",
      "item": "Lum Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 307,
      "gender": "F",
      "shiny": false,
      "speciesKey": "LILLIGANT:0",
      "originalSpeciesKey": "LILLIGANT:0",
      "trainerId": "COOLTRAINER_F:Chalina:0",
      "slot": 1,
      "doubles": true
    }
  },
  "Charizard [Mega Charizard Y]": {
    "Ace Trainer Chalina (DOUBLES) [Slot 5]": {
      "level": 97,
      "ability": "Drought",
      "moves": [
        "Heat Wave",
        "Air Slash",
        "Solar Beam",
        "Scorching Sands"
      ],
      "nature": "Timid",
      "item": "Charizardite Y",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 307,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CHARIZARD:2",
      "originalSpeciesKey": "CHARIZARD:0",
      "trainerId": "COOLTRAINER_F:Chalina:0",
      "slot": 5,
      "doubles": true
    }
  },
  "Ursaluna": {
    "Pokemonranger M Auron [Slot 3]": {
      "level": 96,
      "ability": "Guts",
      "moves": [
        "Earthquake",
        "Facade",
        "Play Rough",
        "Crunch"
      ],
      "nature": "Adamant",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 308,
      "gender": "F",
      "shiny": false,
      "speciesKey": "URSALUNA:0",
      "originalSpeciesKey": "URSALUNA:0",
      "trainerId": "POKEMONRANGER_M:Auron:0",
      "slot": 3,
      "doubles": false
    }
  },
  "Manectric [Mega Manectric]": {
    "Pokemonranger M Auron [Slot 5]": {
      "level": 97,
      "ability": "Intimidate",
      "moves": [
        "Thunderbolt",
        "Flamethrower",
        "Hidden Power",
        "Double Team"
      ],
      "nature": "Timid",
      "item": "Manectite",
      "ivs": {
        "hp": 30,
        "at": 30,
        "df": 30,
        "sa": 30,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 308,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MANECTRIC:1",
      "originalSpeciesKey": "MANECTRIC:0",
      "trainerId": "POKEMONRANGER_M:Auron:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Dracozolt": {
    "Cooltrainer M Nicolas [Slot 4]": {
      "level": 96,
      "ability": "Sand Rush",
      "moves": [
        "Bolt Beak",
        "Draco Meteor",
        "Dragon Rush",
        "Earthquake"
      ],
      "nature": "Lonely",
      "item": "",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 309,
      "gender": "",
      "shiny": false,
      "speciesKey": "DRACOZOLT:0",
      "originalSpeciesKey": "DRACOZOLT:0",
      "trainerId": "COOLTRAINER_M:Nicolas:0",
      "slot": 4,
      "doubles": false
    }
  },
  "Tyranitar [Mega Tyranitar]": {
    "Cooltrainer M Nicolas [Slot 5]": {
      "level": 97,
      "ability": "Unnerve",
      "moves": [
        "Stone Edge",
        "Crunch",
        "Earthquake",
        "Dragon Dance"
      ],
      "nature": "Jolly",
      "item": "Tyranitarite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 309,
      "gender": "M",
      "shiny": false,
      "speciesKey": "TYRANITAR:1",
      "originalSpeciesKey": "TYRANITAR:0",
      "trainerId": "COOLTRAINER_M:Nicolas:0",
      "slot": 5,
      "doubles": false
    }
  },
  "Cloyster": {
    "Elite Four Lorelei #1 [Slot 1]": {
      "level": 99,
      "ability": "Skill Link",
      "moves": [
        "Ice Shard",
        "Icicle Spear",
        "Rock Blast",
        "Iron Defense"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 310,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLOYSTER:0",
      "originalSpeciesKey": "CLOYSTER:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:0",
      "slot": 1,
      "doubles": false
    },
    "Elite Four Lorelei #2 (DOUBLES) [Slot 2]": {
      "level": 99,
      "ability": "Skill Link",
      "moves": [
        "Ice Shard",
        "Icicle Spear",
        "Rock Blast",
        "Iron Defense"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 311,
      "gender": "F",
      "shiny": false,
      "speciesKey": "CLOYSTER:0",
      "originalSpeciesKey": "CLOYSTER:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:1",
      "slot": 2,
      "doubles": true
    }
  },
  "Iron Bundle": {
    "Elite Four Lorelei #1 [Slot 5]": {
      "level": 99,
      "ability": "Quark Drive",
      "moves": [
        "Blizzard",
        "Hydro Pump"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 310,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONBUNDLE:0",
      "originalSpeciesKey": "IRONBUNDLE:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:0",
      "slot": 5,
      "doubles": false
    },
    "Elite Four Lorelei #2 (DOUBLES) [Slot 5]": {
      "level": 99,
      "ability": "Quark Drive",
      "moves": [
        "Blizzard",
        "Hydro Pump"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 311,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONBUNDLE:0",
      "originalSpeciesKey": "IRONBUNDLE:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Glalie [Mega Glalie]": {
    "Elite Four Lorelei #1 [Slot 6]": {
      "level": 100,
      "ability": "Refrigerate",
      "moves": [
        "Blizzard",
        "Return",
        "Earthquake"
      ],
      "nature": "Hasty",
      "item": "Glalitite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 310,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GLALIE:1",
      "originalSpeciesKey": "GLALIE:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:0",
      "slot": 6,
      "doubles": false
    },
    "Elite Four Lorelei #2 (DOUBLES) [Slot 6]": {
      "level": 100,
      "ability": "Refrigerate",
      "moves": [
        "Blizzard",
        "Return",
        "Protect"
      ],
      "nature": "Hasty",
      "item": "Glalitite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 311,
      "gender": "F",
      "shiny": false,
      "speciesKey": "GLALIE:1",
      "originalSpeciesKey": "GLALIE:0",
      "trainerId": "ELITEFOUR_Lorelei:Lorelei:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Infernape": {
    "Elite Four Bruno #1 [Slot 2]": {
      "level": 99,
      "ability": "Blaze",
      "moves": [
        "Fire Blast",
        "Aura Sphere",
        "Grass Knot",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 312,
      "gender": "M",
      "shiny": false,
      "speciesKey": "INFERNAPE:0",
      "originalSpeciesKey": "INFERNAPE:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:0",
      "slot": 2,
      "doubles": false
    },
    "Elite Four Bruno #2 (DOUBLES) [Slot 1]": {
      "level": 99,
      "ability": "Blaze",
      "moves": [
        "Heat Wave",
        "Aura Sphere",
        "Grass Knot",
        "Nasty Plot"
      ],
      "nature": "Timid",
      "item": "Life Orb",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 313,
      "gender": "M",
      "shiny": false,
      "speciesKey": "INFERNAPE:0",
      "originalSpeciesKey": "INFERNAPE:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:1",
      "slot": 1,
      "doubles": true
    }
  },
  "Kommo-o": {
    "Elite Four Bruno #1 [Slot 5]": {
      "level": 99,
      "ability": "Soundproof",
      "moves": [
        "Clanging Scales",
        "Aura Sphere",
        "Flash Cannon"
      ],
      "nature": "Timid",
      "item": "Throat Spray",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 312,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KOMMOO:0",
      "originalSpeciesKey": "KOMMOO:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:0",
      "slot": 5,
      "doubles": false
    },
    "Elite Four Bruno #2 (DOUBLES) [Slot 5]": {
      "level": 99,
      "ability": "Soundproof",
      "moves": [
        "Clanging Scales",
        "Aura Sphere",
        "Flash Cannon"
      ],
      "nature": "Timid",
      "item": "Throat Spray",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 313,
      "gender": "M",
      "shiny": false,
      "speciesKey": "KOMMOO:0",
      "originalSpeciesKey": "KOMMOO:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Lucario [Mega Lucario]": {
    "Elite Four Bruno #1 [Slot 6]": {
      "level": 100,
      "ability": "Adaptability",
      "moves": [
        "Bullet Punch",
        "Close Combat",
        "Crunch",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Lucarionite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 312,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LUCARIO:1",
      "originalSpeciesKey": "LUCARIO:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:0",
      "slot": 6,
      "doubles": false
    },
    "Elite Four Bruno #2 (DOUBLES) [Slot 6]": {
      "level": 100,
      "ability": "Adaptability",
      "moves": [
        "Bullet Punch",
        "Aura Sphere",
        "Flash Cannon",
        "Dark Pulse"
      ],
      "nature": "Timid",
      "item": "Lucarionite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 313,
      "gender": "M",
      "shiny": false,
      "speciesKey": "LUCARIO:1",
      "originalSpeciesKey": "LUCARIO:0",
      "trainerId": "ELITEFOUR_Bruno:Bruno:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Pheromosa": {
    "Elite Four Aaron #1 [Slot 3]": {
      "level": 99,
      "ability": "Beast Boost",
      "moves": [
        "Bug Buzz",
        "Close Combat",
        "Ice Beam"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 314,
      "gender": "",
      "shiny": false,
      "speciesKey": "PHEROMOSA:0",
      "originalSpeciesKey": "PHEROMOSA:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:0",
      "slot": 3,
      "doubles": false
    },
    "Elite Four Aaron #2 (DOUBLES) [Slot 3]": {
      "level": 99,
      "ability": "Beast Boost",
      "moves": [
        "Bug Buzz",
        "Close Combat",
        "Ice Beam"
      ],
      "nature": "Naive",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 315,
      "gender": "",
      "shiny": false,
      "speciesKey": "PHEROMOSA:0",
      "originalSpeciesKey": "PHEROMOSA:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:1",
      "slot": 3,
      "doubles": true
    }
  },
  "Slither Wing": {
    "Elite Four Aaron #1 [Slot 5]": {
      "level": 99,
      "ability": "Protosynthesis",
      "moves": [
        "Leech Life",
        "Close Combat",
        "Earthquake"
      ],
      "nature": "Jolly",
      "item": "Silver Powder",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 314,
      "gender": "",
      "shiny": false,
      "speciesKey": "SLITHERWING:0",
      "originalSpeciesKey": "SLITHERWING:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:0",
      "slot": 5,
      "doubles": false
    },
    "Elite Four Aaron #2 (DOUBLES) [Slot 5]": {
      "level": 99,
      "ability": "Protosynthesis",
      "moves": [
        "Leech Life",
        "Close Combat",
        "High Horsepower"
      ],
      "nature": "Jolly",
      "item": "Silver Powder",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 315,
      "gender": "",
      "shiny": false,
      "speciesKey": "SLITHERWING:0",
      "originalSpeciesKey": "SLITHERWING:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:1",
      "slot": 5,
      "doubles": true
    }
  },
  "Scizor [Mega Scizor]": {
    "Elite Four Aaron #1 [Slot 6]": {
      "level": 100,
      "ability": "Technician",
      "moves": [
        "Bullet Punch",
        "Close Combat",
        "Knock Off",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Scizorite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 314,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SCIZOR:1",
      "originalSpeciesKey": "SCIZOR:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:0",
      "slot": 6,
      "doubles": false
    },
    "Elite Four Aaron #2 (DOUBLES) [Slot 6]": {
      "level": 100,
      "ability": "Technician",
      "moves": [
        "Bullet Punch",
        "Close Combat",
        "Knock Off",
        "Swords Dance"
      ],
      "nature": "Jolly",
      "item": "Scizorite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 315,
      "gender": "M",
      "shiny": false,
      "speciesKey": "SCIZOR:1",
      "originalSpeciesKey": "SCIZOR:0",
      "trainerId": "ELITEFOUR_Aaron:Aaron:1",
      "slot": 6,
      "doubles": true
    }
  },
  "Iron Crown": {
    "Elite Four Lucian #1 [Slot 3]": {
      "level": 99,
      "ability": "Quark Drive",
      "moves": [
        "Tachyon Cutter",
        "Psyshock",
        "Focus Blast"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 316,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONCROWN:0",
      "originalSpeciesKey": "IRONCROWN:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:0",
      "slot": 3,
      "doubles": false
    },
    "Elite Four Lucian #2 (DOUBLES) [Slot 4]": {
      "level": 99,
      "ability": "Quark Drive",
      "moves": [
        "Tachyon Cutter",
        "Psyshock",
        "Focus Blast"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 317,
      "gender": "",
      "shiny": false,
      "speciesKey": "IRONCROWN:0",
      "originalSpeciesKey": "IRONCROWN:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:1",
      "slot": 4,
      "doubles": true
    }
  },
  "Alakazam [Mega Alakazam]": {
    "Elite Four Lucian #1 [Slot 6]": {
      "level": 100,
      "ability": "Trace",
      "moves": [
        "Psychic",
        "Dazzling Gleam",
        "Shadow Ball",
        "Aura Sphere"
      ],
      "nature": "Timid",
      "item": "Alakazite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 316,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ALAKAZAM:1",
      "originalSpeciesKey": "ALAKAZAM:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:0",
      "slot": 6,
      "doubles": false
    },
    "Elite Four Lucian #2 (DOUBLES) [Slot 1]": {
      "level": 100,
      "ability": "Trace",
      "moves": [
        "Psychic",
        "Dazzling Gleam",
        "Shadow Ball",
        "Aura Sphere"
      ],
      "nature": "Timid",
      "item": "Alakazite",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 317,
      "gender": "M",
      "shiny": false,
      "speciesKey": "ALAKAZAM:1",
      "originalSpeciesKey": "ALAKAZAM:0",
      "trainerId": "ELITEFOUR_Lucian:Lucian:1",
      "slot": 1,
      "doubles": true
    }
  },
  "Milotic": {
    "Cynthia Cynthia #1 [Slot 2]": {
      "level": 100,
      "ability": "Marvel Scale",
      "moves": [
        "Scald",
        "Ice Beam",
        "Alluring Voice",
        "Recover"
      ],
      "nature": "Modest",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 318,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MILOTIC:0",
      "originalSpeciesKey": "MILOTIC:0",
      "trainerId": "CYNTHIA:Cynthia:0",
      "slot": 2,
      "doubles": false
    },
    "Cynthia Cynthia #2 (DOUBLES) [Slot 2]": {
      "level": 100,
      "ability": "Marvel Scale",
      "moves": [
        "Scald",
        "Icy Wind",
        "Alluring Voice",
        "Recover"
      ],
      "nature": "Modest",
      "item": "Leftovers",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 319,
      "gender": "F",
      "shiny": false,
      "speciesKey": "MILOTIC:0",
      "originalSpeciesKey": "MILOTIC:0",
      "trainerId": "CYNTHIA:Cynthia:1",
      "slot": 2,
      "doubles": true
    }
  },
  "Flutter Mane": {
    "Cynthia Cynthia #1 [Slot 3]": {
      "level": 100,
      "ability": "Protosynthesis",
      "moves": [
        "Shadow Ball",
        "Moonblast",
        "Mystical Fire"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 318,
      "gender": "",
      "shiny": false,
      "speciesKey": "FLUTTERMANE:0",
      "originalSpeciesKey": "FLUTTERMANE:0",
      "trainerId": "CYNTHIA:Cynthia:0",
      "slot": 3,
      "doubles": false
    },
    "Cynthia Cynthia #2 (DOUBLES) [Slot 3]": {
      "level": 100,
      "ability": "Protosynthesis",
      "moves": [
        "Shadow Ball",
        "Dazzling Gleam",
        "Mystical Fire"
      ],
      "nature": "Timid",
      "item": "Sitrus Berry",
      "ivs": {
        "hp": 31,
        "at": 31,
        "df": 31,
        "sa": 31,
        "sd": 31,
        "sp": 31
      },
      "evs": {
        "hp": 0,
        "at": 0,
        "df": 0,
        "sa": 0,
        "sd": 0,
        "sp": 0
      },
      "index": 319,
      "gender": "",
      "shiny": false,
      "speciesKey": "FLUTTERMANE:0",
      "originalSpeciesKey": "FLUTTERMANE:0",
      "trainerId": "CYNTHIA:Cynthia:1",
      "slot": 3,
      "doubles": true
    }
  }
};
