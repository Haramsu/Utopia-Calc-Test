
/* UTOPIA_RXDATA_IMPORT_V1: separate, local only */
(function () {
'use strict';

function decode(bytes) {
  var at = 0, objects = [], symbols = [];
  var decoder = new TextDecoder('utf-8');

  function byte() {
    if (at >= bytes.length) throw Error('Unexpected end of save');
    return bytes[at++];
  }

  function fix() {
    var c = byte();
    if (c > 127) c -= 256;
    if (!c) return 0;
    if (c > 4) return c - 5;
    if (c < -4) return c + 5;

    var n = Math.abs(c), v = 0;
    for (var i = 0; i < n; i++) v += byte() * Math.pow(256, i);
    if (c < 0) v -= Math.pow(256, n);
    return v;
  }

  function raw() {
    var n = fix();
    if (n < 0 || n > bytes.length - at) {
      throw Error('Invalid Marshal string length');
    }
    var v = decoder.decode(bytes.subarray(at, at + n));
    at += n;
    return v;
  }

  function next(depth) {
    if (depth > 200) throw Error('Marshal nesting too deep');

    var tag = String.fromCharCode(byte()), count, value, key, i;

    switch (tag) {
      case '0': return null;
      case 'T': return true;
      case 'F': return false;
      case 'i': return fix();

      case 'l': {
        var sign = String.fromCharCode(byte());
        count = fix() * 2;
        if (count < 0 || count > 128) {
          throw Error('Invalid Marshal integer');
        }

        var integer = 0n;
        for (i = 0; i < count; i++) {
          integer += BigInt(byte()) << (8n * BigInt(i));
        }

        value = Number(sign === '-' ? -integer : integer);
        objects.push(value);
        return value;
      }

      case 'f':
        value = Number(raw());
        objects.push(value);
        return value;

      case ':':
        value = raw();
        symbols.push(value);
        return value;

      case ';':
        return symbols[fix()];

      case '"':
        value = raw();
        objects.push(value);
        return value;

      case '@':
        return objects[fix()];

      case '[': {
        count = fix();
        if (count < 0 || count > 1000000) {
          throw Error('Invalid array');
        }

        value = [];
        objects.push(value);

        for (i = 0; i < count; i++) {
          value.push(next(depth + 1));
        }

        return value;
      }

      case '{':
      case '}': {
        count = fix();
        if (count < 0 || count > 1000000) {
          throw Error('Invalid hash');
        }

        value = Object.create(null);
        objects.push(value);

        for (i = 0; i < count; i++) {
          key = next(depth + 1);
          value[String(key)] = next(depth + 1);
        }

        if (tag === '}') next(depth + 1);
        return value;
      }

      case 'o': {
        var name = next(depth + 1);
        count = fix();

        if (count < 0 || count > 10000) {
          throw Error('Invalid Ruby object');
        }

        value = {__class: name};
        objects.push(value);

        for (i = 0; i < count; i++) {
          key = next(depth + 1);
          value[String(key).replace(/^@/, '')] = next(depth + 1);
        }

        return value;
      }

      case 'I': {
        value = next(depth + 1);
        count = fix();

        for (i = 0; i < count; i++) {
          next(depth + 1);
          next(depth + 1);
        }

        return value;
      }

      case 'u': {
        name = next(depth + 1);
        value = {__class: name, __data: raw()};
        objects.push(value);
        return value;
      }

      case 'U': {
        name = next(depth + 1);
        value = {__class: name};
        objects.push(value);
        value.value = next(depth + 1);
        return value;
      }

      case 'S': {
        name = next(depth + 1);
        count = fix();
        value = {__class: name};
        objects.push(value);

        for (i = 0; i < count; i++) {
          key = next(depth + 1);
          value[String(key)] = next(depth + 1);
        }

        return value;
      }

      case 'C':
        next(depth + 1);
        return next(depth + 1);

      case 'e':
        next(depth + 1);
        return next(depth + 1);

      case 'c':
      case 'm':
      case 'M':
        value = raw();
        objects.push(value);
        return value;

      case '/':
        value = raw();
        next(depth + 1);
        objects.push(value);
        return value;

      default:
        throw Error('Unsupported Ruby Marshal type ' + tag);
    }
  }

  if (byte() !== 4 || byte() !== 8) {
    throw Error('Not a supported Ruby Marshal save');
  }

  var data = next(0);

  if (!data || !data.player || !data.storage_system ||
      !Array.isArray(data.player.party) ||
      !Array.isArray(data.storage_system.boxes)) {
    throw Error('Not a Pokémon Essentials v21.1 save');
  }

  return data;
}

function canonical(value) {
  return String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function lookup(list) {
  var result = Object.create(null);

  (Array.isArray(list) ? list : Object.keys(list || {})).forEach(function (name) {
    result[canonical(name)] = name;
  });

  return result;
}

/* UTOPIA_RXDATA_FORM_UPSERT_V6 */
function utopiaRxLookupAbility(id, map) {
  var key = canonical(id);
  if (!key) return '';

  if (map[key]) return map[key];

  var pools = [
    typeof abilities !== 'undefined' ? abilities : null
  ];

  if (calc && calc.ABILITIES) {
    Object.keys(calc.ABILITIES).forEach(function(gen) {
      pools.push(calc.ABILITIES[gen]);
    });
  }

  for (var i = 0; i < pools.length; i++) {
    var pool = pools[i];
    if (!pool) continue;

    var names = Array.isArray(pool)
      ? pool
      : Object.keys(pool);

    for (var j = 0; j < names.length; j++) {
      if (canonical(names[j]) === key) {
        return names[j];
      }
    }
  }

  var options = $('#p1 .ability option');

  for (var k = 0; k < options.length; k++) {
    if (canonical(options[k].value) === key) {
      return options[k].value;
    }
  }

  return '';
}

function utopiaRxFingerprint(p) {
  if (!p) return '';

  return JSON.stringify([
    p.forme || '',
    Number(p.level) || 0,
    p.ivs || {},
    p.moves || [],
    p.nickname || ''
  ]);
}

function convert(save) {
  if (
    typeof UTOPIA_ICON_MAP === 'undefined' ||
    typeof SETDEX_SS === 'undefined' ||
    typeof calc === 'undefined'
  ) {
    throw Error('Calculator data not ready');
  }

  var formMap = Object.create(null);

  Object.keys(UTOPIA_ICON_MAP).forEach(function(name) {
    var info = UTOPIA_ICON_MAP[name];

    if (info && info.speciesKey) {
      formMap[info.speciesKey.toUpperCase()] = name;
    }
  });

  var moveMap = lookup(
    typeof moves !== 'undefined'
      ? moves
      : calc.MOVES[9]
  );

  var abilityMap = lookup(calc.ABILITIES[9]);
  var itemMap = lookup(calc.ITEMS[9]);
  var natureMap = lookup(
    calc.NATURES && calc.NATURES[9]
  );

  var all = [];
  var warnings = [];

  function stat(hash, id) {
    return hash && Number(hash[id]) || 0;
  }

  function pokemon(p, origin) {
    if (
      !p ||
      p.__class !== 'Pokemon' ||
      Number(p.hp) <= 0
    ) {
      return;
    }

    var rawSpecies = canonical(p.species);
    var form = Number(p.form) || 0;

    var species = formMap[
      rawSpecies + ':' + form
    ];

    if (!species) {
      warnings.push(
        origin + ': unknown species/form ' +
        p.species + ':' + form
      );
      return;
    }

    var moveNames = [];

    for (var i = 0; i < (p.moves || []).length; i++) {
      var id = p.moves[i] && p.moves[i].id;
      if (!id) continue;

      var move = moveMap[canonical(id)];

      if (!move) {
        warnings.push(
          origin + ': unknown move ' + id
        );
        return;
      }

      moveNames.push(move);
    }

    var ability = p.ability
      ? utopiaRxLookupAbility(p.ability, abilityMap)
      : '';

    if (p.ability && !ability) {
      warnings.push(
        origin + ': unknown ability ' + p.ability
      );
      return;
    }

    var item = p.item
      ? itemMap[canonical(p.item)]
      : '';

    if (p.item && !item) {
      warnings.push(
        origin + ': unknown item ' + p.item
      );
      return;
    }

    var iv = p.iv || {};
    var ev = p.ev || {};

    var nature = natureMap[canonical(p.nature)] ||
      (p.nature
        ? p.nature.charAt(0) +
          p.nature.slice(1).toLowerCase()
        : 'Serious');

    all.push({
      species: species,
      label: origin,
      data: {
        level: Number(p.level) || 1,
        ability: ability || undefined,
        item: item || undefined,
        forme: species,
        nature: nature,
        ivs: {
          hp: stat(iv, 'HP'),
          at: stat(iv, 'ATTACK'),
          df: stat(iv, 'DEFENSE'),
          sa: stat(iv, 'SPECIAL_ATTACK'),
          sd: stat(iv, 'SPECIAL_DEFENSE'),
          sp: stat(iv, 'SPEED')
        },
        evs: {
          hp: stat(ev, 'HP'),
          at: stat(ev, 'ATTACK'),
          df: stat(ev, 'DEFENSE'),
          sa: stat(ev, 'SPECIAL_ATTACK'),
          sd: stat(ev, 'SPECIAL_DEFENSE'),
          sp: stat(ev, 'SPEED')
        },
        moves: moveNames,
        shiny: p.shiny === true,
        nickname: utopiaRxNickname(p, species),
        gender: Number(p.gender),
        isCustomSet: true,
        rxdataImported: true
      }
    });
  }

  save.player.party.forEach(function(p, i) {
    pokemon(p, 'RxData Party ' + (i + 1));
  });

  save.storage_system.boxes.forEach(function(box, index) {
    if (
      index >= 28 ||
      !box ||
      !Array.isArray(box.pokemon)
    ) {
      return;
    }

    box.pokemon.forEach(function(p, slot) {
      pokemon(
        p,
        'RxData Box ' + (index + 1) +
        ' Slot ' + (slot + 1)
      );
    });
  });

  return {
    all: all,
    warnings: warnings
  };
}

function commit(result) {
  if (!result.all.length) {
    throw Error(
      'No compatible, non-fainted Pokémon found'
    );
  }

  var stored = localStorage.customsets
    ? JSON.parse(localStorage.customsets)
    : {};

  var dexes = [
    SETDEX_SV,
    SETDEX_SS,
    SETDEX_SM,
    SETDEX_XY,
    SETDEX_BW,
    SETDEX_DPP,
    SETDEX_ADV,
    SETDEX_GSC,
    SETDEX_RBY
  ];

  var groups = Object.create(null);
  var pending = [];
  var obsolete = [];

  result.all.forEach(function(p) {
    if (!groups[p.species]) {
      groups[p.species] = [];
    }

    groups[p.species].push(p);
  });

  Object.keys(stored).forEach(function(species) {
    Object.keys(stored[species] || {}).forEach(
      function(label) {
        var data = stored[species][label];

        var imported = groups[
          data && data.forme
        ];

        var incorrectForm =
          data &&
          data.forme &&
          data.forme !== species;

        var legacy =
          /^RxData (?:Party [0-9]+|Box [0-9]+ Slot [0-9]+)(?: [0-9]+)?$/
          .test(label);

        var matches = imported &&
          imported.some(function(p) {
            return utopiaRxFingerprint(p.data) ===
              utopiaRxFingerprint(data);
          });

        if (
          legacy ||
          (
            incorrectForm &&
            matches &&
            /^Custom Set(?: [0-9]+)?$/.test(label)
          )
        ) {
          delete stored[species][label];

          dexes.forEach(function(dex) {
            if (dex[species]) {
              delete dex[species][label];
            }
          });

          obsolete.push(
            species + ' (' + label + ')'
          );
        }
      }
    );
  });

  Object.keys(groups).forEach(function(species) {
    var sets = stored[species] ||
      (stored[species] = {});

    groups[species].forEach(function(p, index) {
      var label = index === 0
        ? 'Custom Set'
        : 'Custom Set ' + (index + 1);

      sets[label] = p.data;

      dexes.forEach(function(dex) {
        if (!dex[species]) {
          dex[species] = {};
        }

        dex[species][label] = p.data;
      });

      pending.push({
        species: species,
        label: label,
        data: p.data
      });
    });
  });

  localStorage.setItem(
    'customsets',
    JSON.stringify(stored)
  );

  obsolete.forEach(function(id) {
    $('.trainer-pok.left-side')
      .filter(function() {
        return this.getAttribute('data-id') === id;
      })
      .remove();
  });

  pending.forEach(function(p) {
    var id = p.species +
      ' (' + p.label + ')';

    var icon = $('.trainer-pok.left-side')
      .filter(function() {
        return this.getAttribute('data-id') === id;
      });

    if (!icon.length) {
      addBoxed({
        name: p.species,
        nameProp: p.label
      });

      icon = $('.trainer-pok.left-side')
        .filter(function() {
          return this.getAttribute('data-id') === id;
        });
    }

    if (
      icon.length &&
      typeof getSrcImgPokemon === 'function'
    ) {
      icon.attr(
        'src',
        getSrcImgPokemon({
          name: p.data.forme,
          shiny: p.data.shiny === true
        })
      );
    }
  });

  $('#importedSetsOptions')
    .css('display', 'inline');

  return pending.length;
}


/* UTOPIA_RXDATA_NICKNAME_TAUROS_V7 */
function utopiaRxNickname(p, species) {
  var name = String(p.name || '').trim();

  if (!name) return '';

  var originalSpecies = String(p.species || '');

  if (
    canonical(name) === canonical(originalSpecies) ||
    canonical(name) === canonical(species)
  ) {
    return '';
  }

  return name;
}

function utopiaRxUpdateDisplay() {
  var selector = $('#p1 .set-selector');

  if (!selector.length) return;

  var selected = String(selector.val() || '');
  var separator = selected.lastIndexOf(' (');

  if (separator < 0 || !selected.endsWith(')')) {
    return;
  }

  var species = selected.slice(0, separator);
  var label = selected.slice(separator + 2, -1);

  var set = SETDEX_SS[species] &&
    SETDEX_SS[species][label];

  if (!set || set.rxdataImported !== true) {
    return;
  }

  var nickname = String(set.nickname || '').trim();

  if (nickname) {
    try {
      var container = selector.select2('container');

      if (container && container.length) {
        container.find('.select2-chosen').text(
          species + ' (' + nickname + ')'
        );
      }
    } catch (error) {
      console.warn('RxData nickname:', error);
    }
  }

  var tauros = {
    'Tauros [Paldean (Combat Breed)]': 'TAUROS_1.png',
    'Tauros [Paldean (Blaze Breed)]': 'TAUROS_2.png',
    'Tauros [Paldean (Aqua Breed)]': 'TAUROS_3.png'
  };

  var sprite = tauros[set.forme];

  if (!sprite) return;

  var icon = document.getElementById('p1mon');

  if (!icon) return;

  icon.src = (
    set.shiny === true
      ? 'img/icons_shiny/'
      : 'img/icons/'
  ) + sprite;
}

function utopiaRxScheduleDisplay() {
  setTimeout(utopiaRxUpdateDisplay, 50);
}

function setup() {
  $(document).on(
    'change.utopiaRxDisplay',
    '#p1 .set-selector',
    utopiaRxScheduleDisplay
  );

  $(document).on(
    'change.utopiaRxDisplay',
    '#p1 .forme',
    utopiaRxScheduleDisplay
  );

  var original = document.getElementById('import');

  if (!original || document.getElementById('import-rxdata')) {
    return;
  }

  var parent = original.parentNode;
  var bar = document.createElement('span');

  bar.id = 'rxdata-import-buttons';
  bar.style.cssText =
    'display:flex;justify-content:center;' +
    'align-items:center;gap:8px;margin-top:6px;';

  parent.insertBefore(bar, original);
  bar.appendChild(original);

  var button = original.cloneNode(false);
  button.id = 'import-rxdata';
  button.textContent = 'Import .rxdata';
  button.type = 'button';

  bar.appendChild(button);

  var input = document.createElement('input');
  input.type = 'file';
  input.accept = '.rxdata';
  input.style.display = 'none';

  parent.appendChild(input);

  var busy = false;

  function handle(file) {
    if (!file || busy) return;

    if (!/\.rxdata$/i.test(file.name)) {
      alert('Please select an .rxdata file.');
      return;
    }

    if (file.size > 32 * 1024 * 1024) {
      alert('Save file exceeds 32 MB.');
      return;
    }

    busy = true;
    button.disabled = true;

    file.arrayBuffer().then(function (buffer) {
      var save = decode(new Uint8Array(buffer));
      var result = convert(save);

      if (result.warnings.length) {
        console.warn(
          'RxData import warnings:',
          result.warnings.join('\n')
        );

        if (!confirm(
          'Skipped Pokémon / data:\n\n' +
          result.warnings.join('\n') +
          '\n\nImport ' +
          result.all.length +
          ' valid Pokémon anyway?'
        )) {
          return;
        }
      }



      var count = commit(result);
      utopiaRxScheduleDisplay();

      alert(count + ' Pokémon imported from .rxdata.');

    }).catch(function (error) {
      console.error('RxData import failed:', error);
      alert('RxData import failed: ' + error.message);

    }).finally(function () {
      busy = false;
      button.disabled = false;
      input.value = '';
    });
  }

  button.addEventListener('click', function () {
    input.click();
  });

  input.addEventListener('change', function () {
    handle(input.files && input.files[0]);
  });

  button.addEventListener('dragover', function (event) {
    event.preventDefault();
  });

  button.addEventListener('drop', function (event) {
    event.preventDefault();
    handle(
      event.dataTransfer && event.dataTransfer.files[0]
    );
  });
}

$(setup);
})();
