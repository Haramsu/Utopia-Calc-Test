"use strict";
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var e_1, _a, e_2, _b;
exports.__esModule = true;

var util_1 = require("../util");
var RBY = [];
var GSC = [
    'Berry Juice',
    'Berry',
    'Berserk Gene',
    'Bitter Berry',
    'Black Belt',
    'Black Glasses',
    'Bright Powder',
    'Burnt Berry',
    'Charcoal',
    'Dragon Fang',
    'Dragon Scale',
    'Fast Ball',
    'Fire Stone',
    'Focus Band',
    'Friend Ball',
    'Gold Berry',
    'Great Ball',
    'Hard Stone',
    'Heavy Ball',
    'Ice Berry',
    'King\'s Rock',
    'Leaf Stone',
    'Leftovers',
    'Level Ball',
    'Light Ball',
    'Love Ball',
    'Lucky Punch',
    'Lure Ball',
    'Magnet',
    'Mail',
    'Master Ball',
    'Metal Coat',
    'Metal Powder',
    'Mint Berry',
    'Miracle Berry',
    'Miracle Seed',
    'Moon Ball',
    'Moon Stone',
    'Mystery Berry',
    'Mystic Water',
    'Never-Melt Ice',
    'Pink Bow',
    'Poison Barb',
    'Poke Ball',
    'Polkadot Bow',
    'PRZ Cure Berry',
    'PSN Cure Berry',
    'Quick Claw',
    'Safari Ball',
    'Scope Lens',
    'Sharp Beak',
    'Silver Powder',
    'Soft Sand',
    'Spell Tag',
    'Sport Ball',
    'Stick',
    'Sun Stone',
    'Thick Club',
    'Thunder Stone',
    'Twisted Spoon',
    'Ultra Ball',
    'Up-Grade',
    'Water Stone',
];
var GSC_ONLY = [
    'Berry',
    'Berserk Gene',
    'Bitter Berry',
    'Burnt Berry',
    'Ice Berry',
    'Mint Berry',
    'Miracle Berry',
    'Mystery Berry',
    'PRZ Cure Berry',
    'Gold Berry',
    'Pink Bow',
    'Polkadot Bow',
    'PSN Cure Berry',
    'Enigma Berry',
];
var ADV = GSC.filter(function (i) { return !GSC_ONLY.includes(i); }).concat([
    'Aguav Berry',
    'Apicot Berry',
    'Aspear Berry',
    'Belue Berry',
    'Bluk Berry',
    'Cheri Berry',
    'Chesto Berry',
    'Choice Band',
    'Claw Fossil',
    'Cornn Berry',
    'Deep Sea Scale',
    'Deep Sea Tooth',
    'Dive Ball',
    'Dome Fossil',
    'Durin Berry',
    'Enigma Berry',
    'Figy Berry',
    'Ganlon Berry',
    'Grepa Berry',
    'Helix Fossil',
    'Hondew Berry',
    'Iapapa Berry',
    'Kelpsy Berry',
    'Lansat Berry',
    'Lax Incense',
    'Leppa Berry',
    'Liechi Berry',
    'Lum Berry',
    'Luxury Ball',
    'Macho Brace',
    'Mago Berry',
    'Magost Berry',
    'Mental Herb',
    'Nanab Berry',
    'Nest Ball',
    'Net Ball',
    'Nomel Berry',
    'Old Amber',
    'Oran Berry',
    'Pamtre Berry',
    'Pecha Berry',
    'Persim Berry',
    'Petaya Berry',
    'Pinap Berry',
    'Pomeg Berry',
    'Premier Ball',
    'Qualot Berry',
    'Rabuta Berry',
    'Rawst Berry',
    'Razz Berry',
    'Repeat Ball',
    'Root Fossil',
    'Salac Berry',
    'Sea Incense',
    'Shell Bell',
    'Silk Scarf',
    'Sitrus Berry',
    'Soul Dew',
    'Spelon Berry',
    'Starf Berry',
    'Tamato Berry',
    'Timer Ball',
    'Watmel Berry',
    'Wepear Berry',
    'White Herb',
    'Wiki Berry',
]);
var DPP = ADV.concat([
    'Adamant Orb',
    'Armor Fossil',
    'Babiri Berry',
    'Big Root',
    'Black Sludge',
    'Charti Berry',
    'Cherish Ball',
    'Chilan Berry',
    'Choice Scarf',
    'Choice Specs',
    'Chople Berry',
    'Coba Berry',
    'Colbur Berry',
    'Custap Berry',
    'Damp Rock',
    'Dawn Stone',
    'Destiny Knot',
    'Draco Plate',
    'Dread Plate',
    'Dubious Disc',
    'Dusk Ball',
    'Dusk Stone',
    'Earth Plate',
    'Electirizer',
    'Expert Belt',
    'Fist Plate',
    'Flame Orb',
    'Flame Plate',
    'Focus Sash',
    'Full Incense',
    'Grip Claw',
    'Griseous Orb',
    'Haban Berry',
    'Heal Ball',
    'Heat Rock',
    'Icicle Plate',
    'Icy Rock',
    'Insect Plate',
    'Iron Ball',
    'Iron Plate',
    'Jaboca Berry',
    'Kasib Berry',
    'Kebia Berry',
    'Lagging Tail',
    'Life Orb',
    'Light Clay',
    'Lustrous Orb',
    'Magmarizer',
    'Meadow Plate',
    'Metronome',
    'Micle Berry',
    'Mind Plate',
    'Muscle Band',
    'Occa Berry',
    'Odd Incense',
    'Oval Stone',
    'Park Ball',
    'Passho Berry',
    'Payapa Berry',
    'Power Anklet',
    'Power Band',
    'Power Belt',
    'Power Bracer',
    'Power Herb',
    'Power Lens',
    'Power Weight',
    'Protector',
    'Quick Ball',
    'Quick Powder',
    'Rare Bone',
    'Razor Claw',
    'Razor Fang',
    'Reaper Cloth',
    'Rindo Berry',
    'Rock Incense',
    'Rose Incense',
    'Rowap Berry',
    'Shed Shell',
    'Shiny Stone',
    'Shuca Berry',
    'Skull Fossil',
    'Sky Plate',
    'Smooth Rock',
    'Splash Plate',
    'Spooky Plate',
    'Sticky Barb',
    'Stone Plate',
    'Tanga Berry',
    'Toxic Orb',
    'Toxic Plate',
    'Wacan Berry',
    'Wave Incense',
    'Wide Lens',
    'Wise Glasses',
    'Yache Berry',
    'Zap Plate',
    'Zoom Lens',
]);
var BW = DPP.concat([
    'Absorb Bulb',
    'Air Balloon',
    'Binding Band',
    'Bug Gem',
    'Burn Drive',
    'Cell Battery',
    'Chill Drive',
    'Cover Fossil',
    'Dark Gem',
    'Douse Drive',
    'Dragon Gem',
    'Dream Ball',
    'Eject Button',
    'Electric Gem',
    'Eviolite',
    'Fighting Gem',
    'Fire Gem',
    'Float Stone',
    'Flying Gem',
    'Ghost Gem',
    'Grass Gem',
    'Ground Gem',
    'Ice Gem',
    'Normal Gem',
    'Plume Fossil',
    'Poison Gem',
    'Prism Scale',
    'Psychic Gem',
    'Red Card',
    'Ring Target',
    'Rock Gem',
    'Rocky Helmet',
    'Shock Drive',
    'Steel Gem',
    'Water Gem',
]);
exports.MEGA_STONES = {
    Absolite: 'Absol',
    Abomasite: 'Abomasnow',
    Aerodactylite: 'Aerodactyl',
    Aggronite: 'Aggron',
    Alakazite: 'Alakazam',
    Altarianite: 'Altaria',
    Ampharosite: 'Ampharos',
    Audinite: 'Audino',
    Banettite: 'Banette',
    Beedrillite: 'Beedrill',
    Blastoisinite: 'Blastoise',
    Blazikenite: 'Blaziken',
    Cameruptite: 'Camerupt',
    'Charizardite X': 'Charizard',
    'Charizardite Y': 'Charizard',
    Crucibellite: 'Crucibelle',
    Diancite: 'Diancie',
    Galladite: 'Gallade',
    Garchompite: 'Garchomp',
    Gardevoirite: 'Gardevoir',
    Gengarite: 'Gengar',
    Glalitite: 'Glalie',
    Gyaradosite: 'Gyarados',
    Heracronite: 'Heracross',
    Houndoominite: 'Houndoom',
    Kangaskhanite: 'Kangaskhan',
    Latiasite: 'Latias',
    Latiosite: 'Latios',
    Lopunnite: 'Lopunny',
    Lucarionite: 'Lucario',
    Manectite: 'Manectric',
    Mawilite: 'Mawile',
    Medichamite: 'Medicham',
    Metagrossite: 'Metagross',
    'Mewtwonite X': 'Mewtwo',
    'Mewtwonite Y': 'Mewtwo',
    Pidgeotite: 'Pidgeot',
    Pinsirite: 'Pinsir',
    Sablenite: 'Sableye',
    Salamencite: 'Salamence',
    Sceptilite: 'Sceptile',
    Scizorite: 'Scizor',
    Sharpedonite: 'Sharpedo',
    Slowbronite: 'Slowbro',
    Steelixite: 'Steelix',
    Swampertite: 'Swampert',
    Tyranitarite: 'Tyranitar',
    Venusaurite: 'Venusaur'
};
var XY = BW.concat(__spreadArray(__spreadArray([], __read(Object.keys(exports.MEGA_STONES)), false), [
    'Assault Vest',
    'Blue Orb',
    'Fairy Gem',
    'Jaw Fossil',
    'Kee Berry',
    'Luminous Moss',
    'Maranga Berry',
    'Pixie Plate',
    'Red Orb',
    'Roseli Berry',
    'Sachet',
    'Safety Goggles',
    'Sail Fossil',
    'Snowball',
    'Weakness Policy',
    'Whipped Dream',
], false).sort());
var SM = XY.filter(function (i) { return i !== 'Old Amber'; }).concat([
    'Adrenaline Orb',
    'Aloraichium Z',
    'Beast Ball',
    'Bottle Cap',
    'Bug Memory',
    'Buginium Z',
    'Dark Memory',
    'Darkinium Z',
    'Decidium Z',
    'Dragon Memory',
    'Dragonium Z',
    'Eevium Z',
    'Electric Memory',
    'Electric Seed',
    'Electrium Z',
    'Fairium Z',
    'Fairy Memory',
    'Fighting Memory',
    'Fightinium Z',
    'Fire Memory',
    'Firium Z',
    'Flying Memory',
    'Flyinium Z',
    'Ghost Memory',
    'Ghostium Z',
    'Gold Bottle Cap',
    'Grass Memory',
    'Grassium Z',
    'Grassy Seed',
    'Ground Memory',
    'Groundium Z',
    'Ice Memory',
    'Ice Stone',
    'Icium Z',
    'Incinium Z',
    'Kommonium Z',
    'Lunalium Z',
    'Lycanium Z',
    'Marshadium Z',
    'Mewnium Z',
    'Mimikium Z',
    'Misty Seed',
    'Normalium Z',
    'Pikanium Z',
    'Pikashunium Z',
    'Poison Memory',
    'Poisonium Z',
    'Primarium Z',
    'Protective Pads',
    'Psychic Memory',
    'Psychic Seed',
    'Psychium Z',
    'Rock Memory',
    'Rockium Z',
    'Snorlium Z',
    'Solganium Z',
    'Steel Memory',
    'Steelium Z',
    'Tapunium Z',
    'Terrain Extender',
    'Ultranecrozium Z',
    'Water Memory',
    'Waterium Z',
]);
var SS = SM.concat([
    'Berry Sweet',
    'Blunder Policy',
    'Chipped Pot',
    'Clover Sweet',
    'Cracked Pot',
    'Eject Pack',
    'Flower Sweet',
    'Fossilized Bird',
    'Fossilized Dino',
    'Fossilized Drake',
    'Fossilized Fish',
    'Galarica Cuff',
    'Galarica Wreath',
    'Heavy-Duty Boots',
    'Leek',
    'Love Sweet',
    'Ribbon Sweet',
    'Room Service',
    'Rusted Shield',
    'Rusted Sword',
    'Star Sweet',
    'Strawberry Sweet',
    'Sweet Apple',
    'Tart Apple',
    'Throat Spray',
]);
for (var i = 0; i < 100; i++) {
    SS.push("TR".concat(i < 10 ? "0".concat(i) : i));
}
SS.push('Utility Umbrella', 'Vile Vial');
SS.push.apply(SS, __spreadArray(__spreadArray([], __read(GSC_ONLY), false), ['Old Amber'], false));
var SV = SS.concat([
    'Adamant Crystal',
    'Auspicious Armor',
    'Ability Shield',
    'Booster Energy',
    'Clear Amulet',
    'Covert Cloak',
    'Loaded Dice',
    'Malicious Armor',
    'Mirror Herb',
    'Punching Glove',
    'Lustrous Globe',
    'Griseous Core',
    'Strange Ball',
]);
var BERRIES = {
    'Aguav Berry': { t: 'Dragon', p: 80 },
    'Apicot Berry': { t: 'Ground', p: 100 },
    'Aspear Berry': { t: 'Ice', p: 80 },
    'Babiri Berry': { t: 'Steel', p: 80 },
    'Belue Berry': { t: 'Electric', p: 100 },
    Berry: { t: 'Poison', p: 80 },
    'Bitter Berry': { t: 'Ground', p: 80 },
    'Bluk Berry': { t: 'Fire', p: 90 },
    'Burnt Berry': { t: 'Ice', p: 80 },
    'Charti Berry': { t: 'Rock', p: 80 },
    'Cheri Berry': { t: 'Fire', p: 80 },
    'Chesto Berry': { t: 'Water', p: 80 },
    'Chilan Berry': { t: 'Normal', p: 80 },
    'Chople Berry': { t: 'Fighting', p: 80 },
    'Coba Berry': { t: 'Flying', p: 80 },
    'Colbur Berry': { t: 'Dark', p: 80 },
    'Cornn Berry': { t: 'Bug', p: 90 },
    'Custap Berry': { t: 'Ghost', p: 100 },
    'Durin Berry': { t: 'Water', p: 100 },
    'Enigma Berry': { t: 'Bug', p: 100 },
    'Figy Berry': { t: 'Bug', p: 80 },
    'Ganlon Berry': { t: 'Ice', p: 100 },
    'Gold Berry': { t: 'Psychic', p: 80 },
    'Grepa Berry': { t: 'Flying', p: 90 },
    'Haban Berry': { t: 'Dragon', p: 80 },
    'Hondew Berry': { t: 'Ground', p: 90 },
    'Iapapa Berry': { t: 'Dark', p: 80 },
    'Ice Berry': { t: 'Grass', p: 80 },
    'Jaboca Berry': { t: 'Dragon', p: 100 },
    'Kasib Berry': { t: 'Ghost', p: 80 },
    'Kebia Berry': { t: 'Poison', p: 80 },
    'Kee Berry': { t: 'Fairy', p: 100 },
    'Kelpsy Berry': { t: 'Fighting', p: 90 },
    'Lansat Berry': { t: 'Flying', p: 100 },
    'Leppa Berry': { t: 'Fighting', p: 80 },
    'Liechi Berry': { t: 'Grass', p: 100 },
    'Lum Berry': { t: 'Flying', p: 80 },
    'Mago Berry': { t: 'Ghost', p: 80 },
    'Magost Berry': { t: 'Rock', p: 90 },
    'Maranga Berry': { t: 'Dark', p: 100 },
    'Micle Berry': { t: 'Rock', p: 100 },
    'Mint Berry': { t: 'Water', p: 80 },
    'Miracle Berry': { t: 'Flying', p: 80 },
    'Mystery Berry': { t: 'Fighting', p: 80 },
    'Nanab Berry': { t: 'Water', p: 90 },
    'Nomel Berry': { t: 'Dragon', p: 90 },
    'Occa Berry': { t: 'Fire', p: 80 },
    'Oran Berry': { t: 'Poison', p: 80 },
    'Pamtre Berry': { t: 'Steel', p: 90 },
    'Passho Berry': { t: 'Water', p: 80 },
    'Payapa Berry': { t: 'Psychic', p: 80 },
    'Pecha Berry': { t: 'Electric', p: 80 },
    'Persim Berry': { t: 'Ground', p: 80 },
    'Petaya Berry': { t: 'Poison', p: 100 },
    'Pinap Berry': { t: 'Grass', p: 90 },
    'Pomeg Berry': { t: 'Ice', p: 90 },
    'PRZ Cure Berry': { t: 'Fire', p: 80 },
    'PSN Cure Berry': { t: 'Electric', p: 80 },
    'Qualot Berry': { t: 'Poison', p: 90 },
    'Rabuta Berry': { t: 'Ghost', p: 90 },
    'Rawst Berry': { t: 'Grass', p: 80 },
    'Razz Berry': { t: 'Steel', p: 80 },
    'Rindo Berry': { t: 'Grass', p: 80 },
    'Roseli Berry': { t: 'Fairy', p: 80 },
    'Rowap Berry': { t: 'Dark', p: 100 },
    'Salac Berry': { t: 'Fighting', p: 100 },
    'Shuca Berry': { t: 'Ground', p: 80 },
    'Sitrus Berry': { t: 'Psychic', p: 80 },
    'Spelon Berry': { t: 'Dark', p: 90 },
    'Starf Berry': { t: 'Psychic', p: 100 },
    'Tamato Berry': { t: 'Psychic', p: 90 },
    'Tanga Berry': { t: 'Bug', p: 80 },
    'Wacan Berry': { t: 'Electric', p: 80 },
    'Watmel Berry': { t: 'Fire', p: 100 },
    'Wepear Berry': { t: 'Electric', p: 90 },
    'Wiki Berry': { t: 'Rock', p: 80 },
    'Yache Berry': { t: 'Ice', p: 80 }
};
exports.ITEMS = [[], RBY, GSC, ADV, DPP, BW, XY, SM, ["Ability Capsule", "Ability Link", "Ability Patch", "Ability Shield", "Ability Urge", "Abomasite", "Absolite", "Absolite Z", "Absorb Bulb", "Adamant Crystal", "Adamant Mint", "Adamant Orb", "Adrenaline Orb", "Aerodactylite", "Aggronite", "Aguav Berry", "Air Balloon", "Air Mail", "Alakazite", "Altarianite", "Ampharosite", "Amulet Coin", "Antidote", "Apicot Berry", "Armor Fossil", "Aspear Berry", "Assault Vest", "Audinite", "Voyage Ticket", "Auspicious Armor", "Awakening", "Babiri Berry", "Balm Mushroom", "Banettite", "Barbaracite", "Baxcalibrite", "Beast Ball", "Beedrillite", "Belue Berry", "Berry Juice", "Berry Sweet", "Bicycle", "Big Bamboo Shoot", "Big Malasada", "Big Mushroom", "Big Nugget", "Big Pearl", "Big Root", "Binding Band", "Black Apricorn", "Black Augurite", "Black Belt", "Black Flute", "Black Glasses", "Black Sludge", "Blank Plate", "Blastoisinite", "Blazikenite", "Bloom Mail", "Blue Apricorn", "Blue Flute", "Blue Orb", "Blue Shard", "Bluk Berry", "Blunder Policy", "Bold Mint", "Booster Energy", "Brave Mint", "Briar's Book", "Brick Mail", "Bright Powder", "Bubble Mail", "Bug Gem", "Bug Memory", "Burn Drive", "Burn Heal", "Calm Mint", "Cameruptite", "Careful Mint", "Casteliacone", "Catching Charm", "Cell Battery", "Chandelurite", "Charcoal", "Charizardite X", "Charizardite Y", "Charti Berry", "Cheri Berry", "Cherish Ball", "Chesnaughtite", "Chesto Berry", "Chilan Berry", "Chill Drive", "Chimechite", "Chipped Pot", "Choice Band", "Choice Scarf", "Choice Specs", "Chople Berry", "Claw Fossil", "Cleanse Tag", "Clear Amulet", "Clefablite", "Clover Sweet", "Coba Berry", "Coin Case", "Colbur Berry", "Comet Shard", "Cornerstone Mask", "Cornn Berry", "Cover Fossil", "Covert Cloak", "Crabominite", "Cracked Pot", "Custap Berry", "Damp Mulch", "Damp Rock", "Dark Gem", "Dark Memory", "Darkranite", "Dave's Key", "Dawn Stone", "Deep Sea Scale", "Deep Sea Tooth", "Delphoxite", "Destiny Knot", "Devon Scope", "Diancite", "Dire Hit", "Dire Hit 2", "Dire Hit 3", "Dive Ball", "DNA Splicers", "DNA Splicers [DNASPLICERSUSED]", "Dome Fossil", "Douse Drive", "Dowsing Machine", "Draco Plate", "Dragalgite", "Dragon Fang", "Dragon Gem", "Dragoninite", "Dragon Memory", "Dragon Scale", "Drampanite", "Dread Plate", "Dream Ball", "Dubious Disc", "Durin Berry", "Dusk Ball", "Dusk Stone", "Earth Plate", "Eelektrossite", "Eject Button", "Eject Pack", "Electirizer", "Electric Gem", "Electric Memory", "Electric Seed", "Elixir", "Emboarite", "Energy Powder", "Energy Root", "Enigma Berry", "Escape Rope", "Ether", "Everstone", "Eviolite", "Excadrite", "Exp. Charm", "Expert Belt", "Exp. Share", "Fairy Feather", "Fairy Gem", "Fairy Memory", "Falinksite", "Fast Ball", "Feather Ball", "Feraligite", "Fighting Gem", "Fighting Memory", "Figy Berry", "Fire Gem", "Fire Memory", "Fire Stone", "Fist Plate", "Flame Mail", "Flame Orb", "Flame Plate", "Float Stone", "Floettite", "Flower Sweet", "Fluffy Tail", "Flying Gem", "Flying Memory", "Focus Band", "Focus Sash", "Fossilized Bird", "Fossilized Dino", "Fossilized Drake", "Fossilized Fish", "Fresh Water", "Friend Ball", "Froslassite", "Full Heal", "Full Incense", "Full Restore", "Galactic Key", "Galarica Cuff", "Galarica Wreath", "Galladite", "Ganlon Berry", "Garchompite", "Garchompite Z", "Gardevoirite", "Gengarite", "Gentle Mint", "Ghost Gem", "Ghost Memory", "Gigaton Ball", "Gimmighoul Coin", "Glalitite", "Glimmoranite", "Golisopite", "Golurkite", "Good Rod", "Gooey Mulch", "Gracidea", "Grass Gem", "Grass Mail", "Grass Memory", "Grassy Seed", "Great Ball", "Green Apricorn", "Green Shard", "Greninjite", "Grepa Berry", "Grip Claw", "Griseous Core", "Griseous Orb", "Ground Gem", "Ground Memory", "Growth Mulch", "Guard Spec.", "Gyaradosite", "Haban Berry", "Hard Stone", "Hasty Mint", "Hawluchanite", "Heal Ball", "Heal Powder", "Hearthflame Mask", "Heart Mail", "Heart Scale", "Heatranite", "Heat Rock", "Heavy Ball", "Heavy-Duty Boots", "Helix Fossil", "Heracronite", "Great Ball [HISUIANGREATBALL]", "Heavy Ball [HISUIANHEAVYBALL]", "Poké Ball", "Ultra Ball", "Hondew Berry", "Honey", "Hopo Berry", "Houndoominite", "Hyper Potion", "Iapapa Berry", "Ice Gem", "Ice Heal", "Ice Memory", "Ice Stone", "Icicle Plate", "Icy Rock", "Impish Mint", "Indigo Disk", "Insect Plate", "Iron Ball", "Iron Plate", "Item Drop", "Itemfinder", "Item Urge", "Jaboca Berry", "Jaw Fossil", "Jet Ball", "Jolly Mint", "Kangaskhanite", "Kasib Berry", "Kebia Berry", "Kee Berry", "Kelpsy Berry", "King's Rock", "Lagging Tail", "Lansat Berry", "Latiasite", "Latiosite", "Lava Cookie", "Lax Incense", "Lax Mint", "Leaden Ball", "Leader's Crest", "Leaf Stone", "Leek", "Leftovers", "Legend Plate", "Lemonade", "Leppa Berry", "Level Ball", "Liechi Berry", "Life Orb", "Light Ball", "Light Clay", "Linking Cord", "Loaded Dice", "Lonely Mint", "Lopunnite", "Love Ball", "Love Sweet", "Lucarionite", "Lucarionite Z", "Luck Incense", "Lucky Egg", "Lucky Punch", "Lum Berry", "Luminous Moss", "Lumiose Galette", "Lure Ball", "Lustrous Globe", "Lustrous Orb", "Luxury Ball", "Magearnite", "Magmarizer", "Magnet", "Mago Berry", "Magost Berry", "Malamarite", "Malicious Armor", "Manectite", "Maranga Berry", "Master Ball", "Masterpiece Teacup", "Mawilite", "Max Elixir", "Max Ether", "Max Honey", "Max Mushrooms", "Max Potion", "Max Repel", "Max Revive", "Meadow Plate", "Medichamite", "Meganiumite", "Mega Ring", "Mental Herb", "Meowsticite", "Metagrossite", "Metal Alloy", "Metal Coat", "Metal Powder", "Meteorite", "Metronome", "Mewtwonite X", "Mewtwonite Y", "Micle Berry", "Mild Mint", "Mind Plate", "Miracle Seed", "Mirror Herb", "Misty Seed", "Modest Mint", "Moomoo Milk", "Moon Ball", "Moon Stone", "Mosaic Mail", "Muscle Band", "Mystic Water", "Mythical Pecha Berry", "Naive Mint", "Nanab Berry", "Naughty Mint", "Nest Ball", "Net Ball", "Never-Melt Ice", "N-Lunarizer", "N-Lunarizer [NLUNARIZERUSED]", "Nomel Berry", "Normal Gem", "N-Solarizer", "N-Solarizer [NSOLARIZERUSED]", "Nugget", "Occa Berry", "Odd Incense", "Odd Keystone", "Old Amber", "Old Gateau", "Old Rod", "Old Sea Map", "Oran Berry", "Origin Ball", "Oval Charm", "Oval Stone", "Pamtre Berry", "Paralyze Heal", "Passho Berry", "Payapa Berry", "Pearl", "Pearl String", "Peat Block", "Pecha Berry", "Persim Berry", "Petaya Berry", "Pewter Crunchies", "Pidgeotite", "Pinap Berry", "Pink Apricorn", "Pink Nectar", "Pinsirite", "Pixie Plate", "Plume Fossil", "Poison Barb", "Poison Gem", "Poison Memory", "Poké Ball [POKEBALL]", "Poké Doll", "Poké Flute", "Pokémon Box Link", "Poké Radar", "Poké Toy", "Pomeg Berry", "Potion", "Power Herb", "PP Max", "PP Up", "Premier Ball", "Pretty Feather", "Prism Scale", "Prison Bottle", "Protective Pads", "Protector", "Psychic Gem", "Psychic Memory", "Psychic Seed", "Punching Glove", "Pure Incense", "Purple Nectar", "Pyroarite", "Qualot Berry", "Quick Ball", "Quick Claw", "Quick Powder", "Quiet Mint", "Rabuta Berry", "Rage Candy Bar", "Raichunite X", "Raichunite Y", "Rare Bone", "Endless Candy", "Rash Mint", "Rawst Berry", "Razor Claw", "Razor Fang", "Razz Berry", "Reaper Cloth", "Red Apricorn", "Red Card", "Red Flute", "Red Nectar", "Red Orb", "Red Shard", "Reins of Unity", "Reins of Unity [REINSOFUNITYUSED]", "Relaxed Mint", "Relic Band", "Relic Copper", "Relic Crown", "Relic Gold", "Relic Silver", "Relic Statue", "Relic Vase", "Repeat Ball", "Repel", "Reset Urge", "Reveal Glass", "Revival Herb", "Revive", "Ribbon Sweet", "Rindo Berry", "Ring Target", "Rock Gem", "Rock Incense", "Rock Memory", "Rocky Helmet", "Room Service", "Root Fossil", "Rose Incense", "Roseli Berry", "Rotom Catalog", "Rotom Phone", "Rowap Berry", "Rusted Shield", "Rusted Sword", "Sablenite", "Sachet", "Sacred Ash", "Safari Ball", "Safety Goggles", "Sail Fossil", "Salac Berry", "Salamencite", "Sassy Mint", "Scarlet Book", "Sceptilite", "Scizorite", "Scolipite", "Scope Lens", "Scovillainite", "Scraftinite", "Scroll of Darkness", "Scroll of Waters", "Sea Incense", "Serious Mint", "Shalour Sable", "Sharp Beak", "Sharpedonite", "Shed Shell", "Shell Bell", "Shiny Charm", "Shiny Stone", "Sparking Quill", "Shoal Salt", "Shoal Shell", "Shock Drive", "Shuca Berry", "Silk Scarf", "Silph Scope", "Silver Powder", "Sitrus Berry", "Skarmorite", "Skull Fossil", "Sky Plate", "Slowbronite", "Slowpoke Tail", "Smoke Ball", "Smooth Rock", "Snowball", "Snow Mail", "Soda Pop", "Soft Sand", "Soothe Bell", "Soot Sack", "Soul Dew", "Space Mail", "Spell Tag", "Spelon Berry", "Splash Plate", "Spooky Plate", "Sport Ball", "Sprayduck", "Sprinklotad", "Squirt Bottle", "Stable Mulch", "Staraptite", "Stardust", "Starf Berry", "Starminite", "Star Piece", "Star Sweet", "Steel Gem", "Steelixite", "Steel Mail", "Steel Memory", "Sticky Barb", "Stone Plate", "Strange Ball", "Strawberry Sweet", "Sun Stone", "Super Potion", "Super Repel", "Super Rod", "Swampertite", "Sweet Apple", "Sweet Heart", "Synchro Machine", "Syrupy Apple", "Tamato Berry", "Tanga Berry", "Tart Apple", "Tatsugirinite", "Teal Mask", "Terrain Extender", "Thick Club", "Throat Spray", "Thunder Stone", "Timer Ball", "Timid Mint", "Tiny Bamboo Shoot", "Tiny Mushroom", "TM01", "TR02", "TM03", "TM04", "TM05", "TM06", "TM07", "TM08", "TM09", "TM10", "TM11", "TM12", "TM13", "TM14", "TM15", "TM16", "TM17", "TM18", "TM19", "TM20", "TM21", "TM22", "TM23", "TM24", "TM25", "TM26", "TM27", "TM28", "TM29", "TM30", "TM31", "TM32", "TM33", "TM34", "TM35", "TM36", "TM37", "TM38", "TM39", "TM40", "TM41", "TM42", "TM43", "TM44", "TM45", "TM46", "TM47", "TM48", "TM49", "TM50", "TM51", "TM52", "TM53", "TM54", "TM55", "TM56", "TM57", "TM58", "TM59", "TM60", "TM61", "TM62", "TM63", "TM64", "TR65", "TM66", "TM67", "TM68", "TM69", "TM70", "TR71", "TM72", "TM73", "TM74", "TM75", "TM76", "TM77", "TM78", "TM79", "TM80", "TR81", "TM82", "TM83", "TM84", "TM85", "TM86", "TM87", "TM88", "TM89", "TM90", "TM91", "TM92", "TM93", "TM97", "Town Map", "Toxic Orb", "Toxic Plate", "Tunnel Mail", "Twisted Spoon", "Tyranitarite", "Ultra Ball [ULTRABALL]", "Unremarkable Teacup", "Upgrade", "Utility Umbrella", "Venusaurite", "Victreebelite", "Violet Book", "Wacan Berry", "Wailmer Pail", "Water Gem", "Water Memory", "Water Stone", "Watmel Berry", "Wave Incense", "Weakness Policy", "Wellspring Mask", "Wepear Berry", "Whipped Dream", "White Apricorn", "White Flute", "White Herb", "Wide Lens", "Wiki Berry", "Wing Ball", "Wise Glasses", "Wishing Piece", "X Accuracy", "X Accuracy 2", "X Accuracy 3", "X Accuracy 6", "X Attack", "X Attack 2", "X Attack 3", "X Attack 6", "X Defense", "X Defense 2", "X Defense 3", "X Defense 6", "X Sp. Atk", "X Sp. Atk 2", "X Sp. Atk 3", "X Sp. Atk 6", "X Sp. Def", "X Sp. Def 2", "X Sp. Def 3", "X Sp. Def 6", "X Speed", "X Speed 2", "X Speed 3", "X Speed 6", "Yache Berry", "Yellow Apricorn", "Yellow Flute", "Yellow Nectar", "Yellow Shard", "Zap Plate", "Zeraorite", "Zoom Lens", "Zygarde Cube", "Zygardite"], SV];
var Items = (function () {
    function Items(gen) {
        this.gen = gen;
    }
    Items.prototype.get = function (id) {
        return ITEMS_BY_ID[this.gen][id];
    };
    Items.prototype[Symbol.iterator] = function () {
        var _a, _b, _c, _i, id;
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    _a = ITEMS_BY_ID[this.gen];
                    _b = [];
                    for (_c in _a)
                        _b.push(_c);
                    _i = 0;
                    _d.label = 1;
                case 1:
                    if (!(_i < _b.length)) return [3, 4];
                    _c = _b[_i];
                    if (!(_c in _a)) return [3, 3];
                    id = _c;
                    return [4, this.get(id)];
                case 2:
                    _d.sent();
                    _d.label = 3;
                case 3:
                    _i++;
                    return [3, 1];
                case 4: return [2];
            }
        });
    };
    return Items;
}());
exports.Items = Items;
var Item = (function () {
    function Item(name, gen) {
        this.kind = 'Item';
        this.id = (0, util_1.toID)(name);
        this.name = name;
        this.megaEvolves = exports.MEGA_STONES[name];
        var berry = BERRIES[name];
        if (berry) {
            this.isBerry = true;
            this.naturalGift = {
                basePower: gen < 6 ? berry.p - 20 : berry.p,
                type: berry.t
            };
        }
    }
    return Item;
}());
var ITEMS_BY_ID = [];
var gen = 0;
try {
    for (var ITEMS_1 = __values(exports.ITEMS), ITEMS_1_1 = ITEMS_1.next(); !ITEMS_1_1.done; ITEMS_1_1 = ITEMS_1.next()) {
        var items = ITEMS_1_1.value;
        var map = {};
        try {
            for (var items_1 = (e_2 = void 0, __values(items)), items_1_1 = items_1.next(); !items_1_1.done; items_1_1 = items_1.next()) {
                var item = items_1_1.value;
                var i = new Item(item, gen);
                map[i.id] = i;
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (items_1_1 && !items_1_1.done && (_b = items_1["return"])) _b.call(items_1);
            }
            finally { if (e_2) throw e_2.error; }
        }
        ITEMS_BY_ID.push(map);
        gen++;
    }
}
catch (e_1_1) { e_1 = { error: e_1_1 }; }
finally {
    try {
        if (ITEMS_1_1 && !ITEMS_1_1.done && (_a = ITEMS_1["return"])) _a.call(ITEMS_1);
    }
    finally { if (e_1) throw e_1.error; }
}
//# sourceMappingURL=items.js.map